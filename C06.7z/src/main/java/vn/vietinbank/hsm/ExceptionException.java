
/**
 * ExceptionException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.0  Built on : May 17, 2011 (04:19:43 IST)
 */

package vn.vietinbank.hsm;

public class ExceptionException extends java.lang.Exception{

    private static final long serialVersionUID = 1596508482995L;
    
    private vn.vietinbank.hsm.HSMServiceStub.ExceptionE faultMessage;

    
        public ExceptionException() {
            super("ExceptionException");
        }

        public ExceptionException(java.lang.String s) {
           super(s);
        }

        public ExceptionException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public ExceptionException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(vn.vietinbank.hsm.HSMServiceStub.ExceptionE msg){
       faultMessage = msg;
    }
    
    public vn.vietinbank.hsm.HSMServiceStub.ExceptionE getFaultMessage(){
       return faultMessage;
    }
}
    
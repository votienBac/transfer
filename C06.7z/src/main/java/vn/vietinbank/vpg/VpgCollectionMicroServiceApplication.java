package vn.vietinbank.vpg;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
//import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
//import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.scheduling.annotation.EnableScheduling;

import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;

@SpringBootApplication
@EnableEurekaClient
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@EnableScheduling
public class VpgCollectionMicroServiceApplication {
	private static final Logger logger = LoggerFactory.getLogger(VpgCollectionMicroServiceApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(VpgCollectionMicroServiceApplication.class, args);
		
		
		CommonUtils.initDataSourceJDBC();
		CommonUtils.initDataSourceJDBCTemplate();
		
		if(CommonUtils.lstMicroServiceParamsEntity == null) {
			CommonUtils.lstMicroServiceParamsEntity = CommonUtils.getVpgMicroServiceParamsByServiceCode(Constants.SERVICE_NAME);
		}
		
		if(CommonUtils.lstMicroServiceParamsEntity != null) {
			 logger.info("Init lstMicroServiceParamsEntity length = " + CommonUtils.lstMicroServiceParamsEntity.size()); 
		 }else if(CommonUtils.lstMicroServiceParamsEntity == null || CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
			 logger.error("Init lstMicroServiceParamsEntity is failed!"); 
			 logger.error("Start is failed!"); 
			 return;
		 }
		
	}


}

package vn.vietinbank.vpg.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties 
@EnableConfigurationProperties
public class AppConfig {    
    private Map<String, String> routeCa;

	public Map<String, String> getRouteCa() {
		return routeCa;
	}

	public void setRouteCa(Map<String, String> routeCa) {
		this.routeCa = routeCa;
	} 
}

package vn.vietinbank.vpg.config;


import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.context.annotation.Configuration;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import vn.vietinbank.vpg.util.ResourceUtils;


@Configuration
public class DataSourceConfig {

    private static HikariConfig config = new HikariConfig();
    private static HikariDataSource ds;

    
    static {
    	
    	
        config.setJdbcUrl(ResourceUtils.getVpgDataSourceUrl());
        config.setUsername(ResourceUtils.getVpgDataSourceUserName());
        config.setPassword(ResourceUtils.getVpgDataSourcePassword());
        
        config.setMinimumIdle(ResourceUtils.getVpgDataSourceHikariMinIdle());
        config.setMaximumPoolSize(ResourceUtils.getVpgDataSourceHikariMaxPoolSize());
        config.setIdleTimeout(ResourceUtils.getVpgDataSourceHikariIdleTimeout());
        config.setPoolName(ResourceUtils.getVpgDataSourceHikariPoolName());
        config.setMaxLifetime(ResourceUtils.getVpgDataSourceHikariMaxLifeTime());
        config.setConnectionTimeout(ResourceUtils.getVpgDataSourceHikariConnectionTimeout());
        
        config.addDataSourceProperty("cachePrepStmts" , ResourceUtils.getVpgDataSourceHikariCachePrepStmts());
        config.addDataSourceProperty("prepStmtCacheSize" , ResourceUtils.getVpgDataSourceHikariPrepStmtCacheSize());
        config.addDataSourceProperty("prepStmtCacheSqlLimit" , ResourceUtils.getVpgDataSourceHikariPrepStmtCacheSqlLimit());
        
        ds = new HikariDataSource(config);
        
    }
    

    public DataSourceConfig() {}

    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }
}
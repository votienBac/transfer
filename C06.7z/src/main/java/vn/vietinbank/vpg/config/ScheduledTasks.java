package vn.vietinbank.vpg.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import vn.vietinbank.vpg.util.ResourceUtils;
import vn.vietinbank.vpg.util.Constants.VPG_SCHEDULE_TASK_TIME;
import vn.vietinbank.vpg.util.CommonUtils;

@Component
public class ScheduledTasks {

	private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);
	
}

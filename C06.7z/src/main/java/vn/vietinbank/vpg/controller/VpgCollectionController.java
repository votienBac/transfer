package vn.vietinbank.vpg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.client.http.HttpHeaders;

import vn.vietinbank.vpg.config.AppConfig;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.account.C06CreateAccountRq;
import vn.vietinbank.vpg.model.account.C06CreateAccountRs;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARq;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARs;
import vn.vietinbank.vpg.model.account.C06RequestHeader;

import vn.vietinbank.vpg.model.inqcust.*;

import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;
import vn.vietinbank.vpg.service.VpgMessageAbstractFactory;
import vn.vietinbank.vpg.service.VpgMessageFactory;
import vn.vietinbank.vpg.service.account.VpgCreateAccountInterface;
import vn.vietinbank.vpg.service.callapi.VpgCallApiPrvImpl;
import vn.vietinbank.vpg.service.error.VpgMessageErrorFactory;
import vn.vietinbank.vpg.service.error.VpgMessageErrorInterface;
import vn.vietinbank.vpg.service.inqcust.VpgInqCustInterface;

import vn.vietinbank.vpg.service.notifystatus.VpgNotifyStatusInterface;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URL;
import java.rmi.RemoteException;
import java.security.cert.CRL;
import java.security.cert.CRLException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLEntry;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.axis2.client.Options;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/api")
public class VpgCollectionController {

	@Autowired
	private AppConfig appConfig;

	private static final Logger logger = LoggerFactory.getLogger(VpgCollectionController.class);

	private String signature = "";
	private int iRetry = 0;
	private int iTimeRetry = 0;

	String strJsonRQ = "";
	String strJsonRS = "";

	BeMessage1310 message1310 = null;
	BeMessage1212 message1212 = null;
	C06CreateAccountRs message1311 = null;
	C06KetQuaXacNhanARs message1312 = null;
	VpgCreateAccountInterface vpgCreateAccountInterface = null;
	JsonNode rootNode = null;

	JsonNode type = null;

	
	String dataSign = "";
	String signed = "";
	boolean bVerify = false;

	VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity = null;
	ConfigParams configParams = null;

	VpgMessageAbstractFactory vpgMessageAbstractFactory = null;

	
	VpgMessageErrorFactory vpgMessageErrorFactory = null;

	VpgMessageErrorInterface vpgMessageErrorInterface;

	VpgInqCustInterface vpgInqCustInterface = null;

	VpgNotifyStatusInterface vpgNotifyStatusInterface = null;

	public VpgCollectionController() {
		
	}

	@GetMapping("/v1/health-check")
	public ResponseEntity<String> healthCheck() {
		return ResponseEntity.status(HttpStatus.OK)
				.body("{\"code\":\"00\",\"message\":\"Health check is OK\"}");

	}

	

	@PostMapping("/{version}/inq-customer")
	public BeMessage1310 inqCustomer(@RequestBody BeMessage1300 messageRQ, @PathVariable String version) {
		try {

			strJsonRQ = ConvertJsonToObject.objectToJson(messageRQ);

			logger.info("Message request from SOA: " + strJsonRQ);

			this.vpgMicroServiceParamsEntity = null;

			if (CommonUtils.lstMicroServiceParamsEntity == null || CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
				try {

					CommonUtils.lstMicroServiceParamsEntity = CommonUtils
							.getVpgMicroServiceParamsByServiceCode(Constants.SERVICE_NAME);

					if (CommonUtils.lstMicroServiceParamsEntity == null
							|| CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
						logger.error("getVpgMicroServiceParamsByServiceCode() is failed!");
					}
					
				} catch (Exception ex) {
					logger.error("getVpgMicroServiceParamsByServiceCode() is failed! Exception = " + ex.getMessage());
				}

			}

			
			for (VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity : CommonUtils.lstMicroServiceParamsEntity) {
				if (vpgMicroServiceParamsEntity.getPROVIDER_ID().equalsIgnoreCase(messageRQ.getHeader().getProviderId())
						&& vpgMicroServiceParamsEntity.getMSG_TYPE().equalsIgnoreCase(VPG_MSG_TYPE.MSG_TYPE_1300)) {
					this.vpgMicroServiceParamsEntity = vpgMicroServiceParamsEntity;
					break;
				}

			}
			
			if (this.vpgMicroServiceParamsEntity == null) {

				logger.error("Can't get config of merchant " + messageRQ.getHeader().getMerchantId() + " and provider "
						+ messageRQ.getHeader().getProviderId());

				logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ));

				vpgMessageErrorFactory = new VpgMessageErrorFactory();

				vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);

				message1310 = (BeMessage1310) vpgMessageErrorInterface.getMessageError(messageRQ,
						Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
						Constants.VPG_STATUS_ERR_PROVIDER_ID.CODE, Constants.VPG_STATUS_ERR_PROVIDER_ID.DESC);

				strJsonRS = ConvertJsonToObject.objectToJson(message1310);

				logger.info("Message response for SOA: " + strJsonRS);

				return message1310;
				
			}

			vpgMessageAbstractFactory = VpgMessageFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1300);

			vpgInqCustInterface = (VpgInqCustInterface) vpgMessageAbstractFactory
					.create(this.vpgMicroServiceParamsEntity.getPROVIDER_ID());

			message1310 = vpgInqCustInterface.processMessage(messageRQ, vpgMicroServiceParamsEntity);

			strJsonRS = ConvertJsonToObject.objectToJson(message1310);

			logger.info("Message response for SOA: " + strJsonRS);

			return message1310;

		} catch (Exception e) {
			logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ) + "; Exception: "
					+ e.getMessage());

			vpgMessageErrorFactory = new VpgMessageErrorFactory();

			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);

			message1310 = (BeMessage1310) vpgMessageErrorInterface.getMessageError(messageRQ,
					Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

			strJsonRS = ConvertJsonToObject.objectToJson(message1310);

			logger.info("Message response for SOA: " + strJsonRS);

			return message1310;

		}

	}

	@PostMapping("/{version}/createAccount")
	public C06CreateAccountRs createAccount(@RequestBody C06CreateAccountRq messageRQ,
			@RequestHeader Map<String, String> mapValues, @PathVariable String version) {
		try {

			logger.info("Message request from partner: " + mapValues);
			this.vpgMicroServiceParamsEntity = null;

			if (CommonUtils.lstMicroServiceParamsEntity == null || CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
				try {

					CommonUtils.lstMicroServiceParamsEntity = CommonUtils
							.getVpgMicroServiceParamsByServiceCode(Constants.SERVICE_NAME);

					if (CommonUtils.lstMicroServiceParamsEntity == null
							|| CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
						logger.error("getVpgMicroServiceParamsByServiceCode() is failed!");
					}

					
				} catch (Exception ex) {
					logger.error("getVpgMicroServiceParamsByServiceCode() is failed! Exception = " + ex.getMessage());
				}

			}
			this.vpgMicroServiceParamsEntity = vpgMicroServiceParamsEntity;
			
			for (VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity : CommonUtils.lstMicroServiceParamsEntity) {
				if (vpgMicroServiceParamsEntity.getPROVIDER_ID().equalsIgnoreCase("841")
						&& vpgMicroServiceParamsEntity.getMSG_TYPE().equalsIgnoreCase(VPG_MSG_TYPE.MSG_TYPE_1301)) {
					this.vpgMicroServiceParamsEntity = vpgMicroServiceParamsEntity;
					break;
				}

			}

			
			if (this.vpgMicroServiceParamsEntity == null) {

				logger.error("Can't get config of merchant ");

				logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ));

				vpgMessageErrorFactory = new VpgMessageErrorFactory();

				vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1117);

				message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
						Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
						Constants.VPG_STATUS_ERR_PROVIDER_ID.CODE, Constants.VPG_STATUS_ERR_PROVIDER_ID.DESC);

				strJsonRS = ConvertJsonToObject.objectToJson(message1311);

				logger.info("Message response for partner: " + strJsonRS);

				return message1311;

			
			}
			String client_id = CommonUtils.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(),
					"client_id");
			String secret = CommonUtils.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(), "secret");
			boolean checkheaderclient = false;
			boolean checkheadersecret = false;
			for (Map.Entry<String, String> entry : mapValues.entrySet()) {
				String k = entry.getKey();
				String v = entry.getValue();
				if (k.equals("x-ibm-client-secret")) {

					if (!v.equals(secret)) {
						logger.error("Sai gia tri header x-ibm-client-secret : " + v);

						vpgMessageErrorFactory = new VpgMessageErrorFactory();

						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1311);

						message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
								Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

						strJsonRS = ConvertJsonToObject.objectToJson(message1311);

						logger.info("Message response for partner: " + strJsonRS);

						return message1311;
					}
					checkheadersecret = true;
				}
				if (k.equals("x-ibm-client-id")) {

					if (!v.equals(client_id)) {
						logger.error("Sai gia tri header x-ibm-client-id  : " + v);

						vpgMessageErrorFactory = new VpgMessageErrorFactory();

						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1311);

						message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
								Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

						strJsonRS = ConvertJsonToObject.objectToJson(message1311);

						logger.info("Message response for partner: " + strJsonRS);

						return message1311;
					}
					checkheaderclient = true;

				}

			}
			if (!(checkheaderclient && checkheadersecret)) {

				logger.error("khong truyen gia tri header  : ");

				vpgMessageErrorFactory = new VpgMessageErrorFactory();

				vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1311);

				message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
						Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
						Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

				strJsonRS = ConvertJsonToObject.objectToJson(message1311);

				logger.info("Message response for partner: " + strJsonRS);

				return message1311;

			}
			strJsonRQ = ConvertJsonToObject.objectToJson(messageRQ);

			logger.info("Message request from partner: " + strJsonRQ);

			vpgMessageAbstractFactory = VpgMessageFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1301);

			vpgCreateAccountInterface = (VpgCreateAccountInterface) vpgMessageAbstractFactory
					.create(this.vpgMicroServiceParamsEntity.getPROVIDER_ID());

			message1311 = vpgCreateAccountInterface.processMessage(messageRQ, vpgMicroServiceParamsEntity);

			strJsonRS = ConvertJsonToObject.objectToJson(message1311);

			logger.info("Message response for XES: " + strJsonRS);

			return message1311;

		} catch (Exception e) {
			logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ) + "; Exception: "
					+ e.getMessage());

			vpgMessageErrorFactory = new VpgMessageErrorFactory();

			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1117);

			message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
					Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

			strJsonRS = ConvertJsonToObject.objectToJson(message1311);

			logger.info("Message response for SOA: " + strJsonRS);

			return message1311;

		}

	}

	@PostMapping("/{version}/ketquaxacnhananh")
	public C06KetQuaXacNhanARs ketquaxacnhananh(@RequestBody C06KetQuaXacNhanARq messageRQ,
			@RequestHeader Map<String, String> mapValues, @PathVariable String version) {
		try {

			logger.info("Message request from partner ketquaxacnhananh: " + mapValues);
			boolean checkheaderclient = false;
			boolean checkheadersecret = false;
			this.vpgMicroServiceParamsEntity = null;

			if (CommonUtils.lstMicroServiceParamsEntity == null || CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
				try {

					CommonUtils.lstMicroServiceParamsEntity = CommonUtils
							.getVpgMicroServiceParamsByServiceCode(Constants.SERVICE_NAME);

					if (CommonUtils.lstMicroServiceParamsEntity == null
							|| CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
						logger.error("getVpgMicroServiceParamsByServiceCode() is failed!");
					}

					
				} catch (Exception ex) {
					logger.error("getVpgMicroServiceParamsByServiceCode() is failed! Exception = " + ex.getMessage());
				}

			}
			this.vpgMicroServiceParamsEntity = vpgMicroServiceParamsEntity;
			
			for (VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity : CommonUtils.lstMicroServiceParamsEntity) {
				if (vpgMicroServiceParamsEntity.getPROVIDER_ID().equalsIgnoreCase("841")
						&& vpgMicroServiceParamsEntity.getMSG_TYPE().equalsIgnoreCase(VPG_MSG_TYPE.MSG_TYPE_1302)) {
					this.vpgMicroServiceParamsEntity = vpgMicroServiceParamsEntity;
					break;
				}

			}

			
			if (this.vpgMicroServiceParamsEntity == null) {

				logger.error("Can't get config of merchant ");

				logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ));

				vpgMessageErrorFactory = new VpgMessageErrorFactory();

				vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1117);

				message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
						Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
						Constants.VPG_STATUS_ERR_PROVIDER_ID.CODE, Constants.VPG_STATUS_ERR_PROVIDER_ID.DESC);

				strJsonRS = ConvertJsonToObject.objectToJson(message1311);

				logger.info("Message response for partner: " + strJsonRS);

				return message1312;

			
			}
			String client_id = CommonUtils.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(),
					"client_id");
			String secret = CommonUtils.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(), "secret");
			
			for (Map.Entry<String, String> entry : mapValues.entrySet()) {
				String k = entry.getKey();
				String v = entry.getValue();
				if (k.equals("x-ibm-client-secret")) {

					if (!v.equals(secret)) {
						logger.error("Sai gia tri header x-ibm-client-secret : " + v);

						vpgMessageErrorFactory = new VpgMessageErrorFactory();

						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);

						message1312 = (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(messageRQ,
								Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

						strJsonRS = ConvertJsonToObject.objectToJson(message1312);

						logger.info("Message response for partner: " + strJsonRS);

						return message1312;
					}
					checkheadersecret = true;
				}
				if (k.equals("x-ibm-client-id")) {

					if (!v.equals(client_id)) {
						logger.error("Sai gia tri header x-ibm-client-id  : " + v);

						vpgMessageErrorFactory = new VpgMessageErrorFactory();

						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);

						message1312 = (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(messageRQ,
								Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

						strJsonRS = ConvertJsonToObject.objectToJson(message1312);

						logger.info("Message response for partner: " + strJsonRS);

						return message1312;
					}
					checkheaderclient = true;

				}

			}
			if (!(checkheaderclient && checkheadersecret)) {

				logger.error("khong truyen gia tri header  : ");

				vpgMessageErrorFactory = new VpgMessageErrorFactory();

				vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);

				message1312 = (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(messageRQ,
						Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
						Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

				strJsonRS = ConvertJsonToObject.objectToJson(message1311);

				logger.info("Message response for partner: " + strJsonRS);

				return message1312;

			}
			strJsonRQ = ConvertJsonToObject.objectToJson(messageRQ);

			logger.info("Message request from partner: " + strJsonRQ);

		
			vpgMessageAbstractFactory = VpgMessageFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1302);

			vpgCreateAccountInterface = (VpgCreateAccountInterface) vpgMessageAbstractFactory
					.create(this.vpgMicroServiceParamsEntity.getPROVIDER_ID());

			message1312 = vpgCreateAccountInterface.ketquaxacnhananh(messageRQ, vpgMicroServiceParamsEntity);

			strJsonRS = ConvertJsonToObject.objectToJson(message1312);

			logger.info("Message response for XES: " + strJsonRS);

			return message1312;

		} catch (Exception e) {
			logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ) + "; Exception: "
					+ e.getMessage());

			vpgMessageErrorFactory = new VpgMessageErrorFactory();

			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1117);

			message1311 = (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(messageRQ,
					Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

			strJsonRS = ConvertJsonToObject.objectToJson(message1311);

			logger.info("Message response for SOA: " + strJsonRS);

			return message1312;

		}

	}

	@PostMapping("/{version}/notify-status")
	public BeMessage1212 notifyStatus(@RequestBody BeMessage1202 messageRQ, @PathVariable String version) {
		try {
			strJsonRQ = ConvertJsonToObject.objectToJson(messageRQ);

			logger.info("Message request from SOA: " + strJsonRQ);

			this.vpgMicroServiceParamsEntity = null;

			if (CommonUtils.lstMicroServiceParamsEntity == null || CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
				try {

					CommonUtils.lstMicroServiceParamsEntity = CommonUtils
							.getVpgMicroServiceParamsByServiceCode(Constants.SERVICE_NAME);

					if (CommonUtils.lstMicroServiceParamsEntity == null
							|| CommonUtils.lstMicroServiceParamsEntity.size() < 1) {
						logger.error("getVpgMicroServiceParamsByServiceCode() is failed!");
					}

					
				} catch (Exception ex) {
					logger.error("getVpgMicroServiceParamsByServiceCode() is failed! Exception = " + ex.getMessage());
				}

			}

			
			for (VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity : CommonUtils.lstMicroServiceParamsEntity) {
				if (vpgMicroServiceParamsEntity.getPROVIDER_ID().equalsIgnoreCase(messageRQ.getHeader().getProviderId())
						&& vpgMicroServiceParamsEntity.getMSG_TYPE().equalsIgnoreCase(VPG_MSG_TYPE.MSG_TYPE_1202)) {
					this.vpgMicroServiceParamsEntity = vpgMicroServiceParamsEntity;
					break;
				}

			}
			
			if (this.vpgMicroServiceParamsEntity == null) {

				logger.error("Can't get config of merchant " + messageRQ.getHeader().getMerchantId() + " and provider "
						+ messageRQ.getHeader().getProviderId());

				logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ));

				vpgMessageErrorFactory = new VpgMessageErrorFactory();

				vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);

				message1212 = (BeMessage1212) vpgMessageErrorInterface.getMessageError(messageRQ,
						Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
						Constants.VPG_STATUS_ERR_PROVIDER_ID.CODE, Constants.VPG_STATUS_ERR_PROVIDER_ID.DESC);

				strJsonRS = ConvertJsonToObject.objectToJson(message1212);

				logger.info("Message response for SOA: " + strJsonRS);

				return message1212;

				
			}
			

			vpgMessageAbstractFactory = VpgMessageFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1202);

			vpgNotifyStatusInterface = (VpgNotifyStatusInterface) vpgMessageAbstractFactory
					.create(this.vpgMicroServiceParamsEntity.getPROVIDER_ID());

			message1212 = vpgNotifyStatusInterface.processMessage(messageRQ, vpgMicroServiceParamsEntity);

			strJsonRS = ConvertJsonToObject.objectToJson(message1212);

			logger.info("Message response for SOA: " + strJsonRS);

			return message1212;

		} catch (Exception e) {
			logger.error("Message request: " + ConvertJsonToObject.objectToJson(messageRQ) + "; Exception: "
					+ e.getMessage());

			vpgMessageErrorFactory = new VpgMessageErrorFactory();

			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);

			message1212 = (BeMessage1212) vpgMessageErrorInterface.getMessageError(messageRQ,
					Constants.PRV_STATUS_ERR_GENERAL.CODE, Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE, Constants.VPG_STATUS_ERR_GENERAL.DESC);

			strJsonRS = ConvertJsonToObject.objectToJson(message1212);

			logger.info("Message response for SOA: " + strJsonRS);

			return message1212;

		}

	}

}
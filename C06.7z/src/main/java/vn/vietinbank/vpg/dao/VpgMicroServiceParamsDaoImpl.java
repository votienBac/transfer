package vn.vietinbank.vpg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.zaxxer.hikari.HikariDataSource;

import vn.vietinbank.vpg.config.DataSourceConfig;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.ResourceUtils;


public class VpgMicroServiceParamsDaoImpl implements VpgMicroServiceParamsDaoInterface<VpgMicroServiceParamsEntity> {
	
	private DataSource dataSource = CommonUtils.dataSource;
	
	private JdbcTemplate jdbcTemplate = CommonUtils.jdbcTemplate;
	
	private VpgMicroServiceParamsDaoImpl() {
		
	}
	
	private static class ServiceHelper{
		private static VpgMicroServiceParamsDaoImpl INSTANCE = new VpgMicroServiceParamsDaoImpl();
	}
	
	public static VpgMicroServiceParamsDaoImpl getInstance() {
		return ServiceHelper.INSTANCE;
	}


	@Override
	public List<VpgMicroServiceParamsEntity> getByServiceCode(String serviceCode) {
		String sql = "SELECT * FROM VPG_MICRO_SERVICE_PARAMS WHERE IS_ACTIVE = '1' AND SERVICE_CODE = '" + serviceCode + "' ORDER BY ORDER_NUM ASC";
		
		return jdbcTemplate.query(
	                sql,
	                new VpgMicroServiceParamsRowMapper());
	}


	@Override
	public List<VpgMicroServiceParamsEntity> getAll() {
		String sql = "SELECT * FROM VPG_MICRO_SERVICE_PARAMS WHERE IS_ENABLE = '1' ORDER BY ORDER_NUM ASC";
		
		return jdbcTemplate.query(
	                sql,
	                new VpgMicroServiceParamsRowMapper());
	}

	@Override
	public void updateToken(String id, String providerId, String msgType, String token, String tokenCreate, String tokenExpire,
			String tokenTime) {
		String sql = "";
		
		sql = "UPDATE VPG_MICRO_SERVICE_PARAMS SET URL_TOKEN = ?, URL_TOKEN_CREATE = ?, URL_TOKEN_EXPIRE = ?, URL_TOKEN_TIME = ? WHERE ID = ?";
		Connection conn = null;
		
		try {
			if(ResourceUtils.getVpgDataSourceIsPool().equals("1")) {
				conn = DataSourceConfig.getConnection();
			}else {
				conn = dataSource.getConnection();
			}
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, token);
			ps.setString(2, tokenCreate);
			ps.setString(3, tokenExpire);
			ps.setString(4, tokenTime);
			ps.setString(5, id);
			
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
			
			
		}
		
	}


}

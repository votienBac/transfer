package vn.vietinbank.vpg.dao;

import java.util.List;


public interface VpgMicroServiceParamsDaoInterface<T> {
	
	public List<T> getByServiceCode(String serviceCode);
	
	public List<T> getAll();
	
	void updateToken(String id,String providerId, String msgType, String token, String tokenCreate, String tokenExpire, String tokenTime);
    

}

package vn.vietinbank.vpg.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import vn.vietinbank.vpg.entity.*;


public class VpgMicroServiceParamsRowMapper implements RowMapper<VpgMicroServiceParamsEntity> {

	@Override
	public VpgMicroServiceParamsEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		VpgMicroServiceParamsEntity entity = new VpgMicroServiceParamsEntity();
		
		entity.setID(rs.getLong("ID"));
		entity.setCREATED_DATE(rs.getDate("CREATED_DATE"));
		entity.setLAST_DATE(rs.getDate("LAST_DATE"));
		entity.setGATEWAY_ID(rs.getString("GATEWAY_ID"));
		
		entity.setPROVIDER_ID(rs.getString("PROVIDER_ID"));
		entity.setMERCHANT_ID(rs.getString("MERCHANT_ID"));
		entity.setPRODUCT_CODE(rs.getString("PRODUCT_CODE"));
		entity.setSERVICE_CODE(rs.getString("SERVICE_CODE"));
		entity.setUSERNAME(rs.getString("USERNAME"));
		entity.setPASSWORD(rs.getString("PASSWORD"));
		entity.setTOKEN(rs.getString("TOKEN"));
		entity.setMSG_TYPE(rs.getString("MSG_TYPE"));
		entity.setCHANGE_FORMAT(rs.getString("CHANGE_FORMAT"));
		entity.setIS_ACTIVE(rs.getString("IS_ACTIVE"));
		
		
		entity.setURL_PARTNER(rs.getString("URL_PARTNER"));
		entity.setURL_TIMEOUT(rs.getString("URL_TIMEOUT"));
		entity.setURL_HEADER(rs.getString("URL_HEADER"));
		entity.setURL_USR(rs.getString("URL_USR"));
		entity.setURL_PWD(rs.getString("URL_PWD"));
		entity.setDESCRIPTION(rs.getString("DESCRIPTION"));
		entity.setHSM_ENABLE(rs.getString("HSM_ENABLE"));
		entity.setHSM_APPID(rs.getString("HSM_APPID"));
		entity.setHSM_URL(rs.getString("HSM_URL"));
		entity.setHSM_TIMEOUT(rs.getString("HSM_TIMEOUT"));
		
		entity.setHSM_IP(rs.getString("HSM_IP"));
		entity.setHSM_PORT(rs.getString("HSM_PORT"));
		entity.setHSM_SIGN_ENABLE(rs.getString("HSM_SIGN_ENABLE"));
		entity.setHSM_VERIFY_ENABLE(rs.getString("HSM_VERIFY_ENABLE"));
		entity.setHSM_USR(rs.getString("HSM_USR"));
		entity.setHSM_PWD(rs.getString("HSM_PWD"));
		entity.setHSM_CERT_LABEL(rs.getString("HSM_CERT_LABEL"));
		entity.setHSM_SIGN_METHOD(rs.getString("HSM_SIGN_METHOD"));
		entity.setHSM_SIGN_ALIAS(rs.getString("HSM_SIGN_ALIAS"));
		entity.setHSM_VERIFY_METHOD(rs.getString("HSM_VERIFY_METHOD"));
		
		entity.setHSM_VERIFY_ALIAS(rs.getString("HSM_VERIFY_ALIAS"));
		entity.setHSM_TRANSPORT_REALM(rs.getString("HSM_TRANSPORT_REALM"));
		entity.setHSM_ENCRYPT_ENABLE(rs.getString("HSM_ENCRYPT_ENABLE"));
		entity.setHSM_DECRYPT_ENABLE(rs.getString("HSM_DECRYPT_ENABLE"));
		entity.setHSM_ENCRYPT_METHOD(rs.getString("HSM_ENCRYPT_METHOD"));
		entity.setHSM_ENCRYPT_ALIAS(rs.getString("HSM_ENCRYPT_ALIAS"));
		entity.setHSM_DECRYPT_METHOD(rs.getString("HSM_DECRYPT_METHOD"));
		entity.setHSM_DECRYPT_ALIAS(rs.getString("HSM_DECRYPT_ALIAS"));
		entity.setVPG_SIGN_CRT(rs.getString("VPG_SIGN_CRT"));
		entity.setVPG_SIGN_PRV(rs.getString("VPG_SIGN_PRV"));
		
		entity.setVPG_SIGN_PWD(rs.getString("VPG_SIGN_PWD"));
		entity.setVPG_ENC_CRT(rs.getString("VPG_ENC_CRT"));
		entity.setVPG_ENC_PRV(rs.getString("VPG_ENC_PRV"));
		entity.setVPG_ENC_PWD(rs.getString("VPG_ENC_PWD"));
		entity.setPARTNER_ENC_CRT(rs.getString("PARTNER_ENC_CRT"));
		entity.setPARTNER_SIGN_CRT(rs.getString("PARTNER_SIGN_CRT"));
		entity.setPRESEVE1(rs.getString("PRESEVE1"));
		entity.setPRESEVE2(rs.getString("PRESEVE2"));
		entity.setPRESEVE3(rs.getString("PRESEVE3"));
		entity.setUSR_UPD(rs.getString("USR_UPD"));
		entity.setSTRUCT_RQ(rs.getString("STRUCT_RQ"));
		entity.setSTRUCT_RS(rs.getString("STRUCT_RS"));
		entity.setORDER_NUM(rs.getInt("ORDER_NUM"));
		
		entity.setURL_METHOD(rs.getString("URL_METHOD"));
		entity.setURL_TIMEOUT_SOCKET(rs.getString("URL_TIMEOUT_SOCKET"));
		entity.setURL_ACTION(rs.getString("URL_ACTION"));
		entity.setURL_TOKEN(rs.getString("URL_TOKEN"));
		entity.setURL_TOKEN_CREATE(rs.getString("URL_TOKEN_CREATE"));
		entity.setURL_TOKEN_EXPIRE(rs.getString("URL_TOKEN_EXPIRE"));
		entity.setURL_TOKEN_TIME(rs.getString("URL_TOKEN_TIME"));
		
		entity.setHSM_SIGN_RETRY(rs.getInt("HSM_SIGN_RETRY"));
		entity.setHSM_VERIFY_RETRY(rs.getInt("HSM_VERIFY_RETRY"));
		entity.setHSM_ENCRYPT_RETRY(rs.getInt("HSM_ENCRYPT_RETRY"));
		entity.setHSM_DECRYPT_RETRY(rs.getInt("HSM_DECRYPT_RETRY"));
		entity.setHSM_SIGN_RETRY_TIME(rs.getInt("HSM_SIGN_RETRY_TIME"));
		entity.setHSM_VERIFY_RETRY_TIME(rs.getInt("HSM_VERIFY_RETRY_TIME"));
		entity.setHSM_ENCRYPT_RETRY_TIME(rs.getInt("HSM_ENCRYPT_RETRY_TIME"));
		entity.setHSM_DECRYPT_RETRY_TIME(rs.getInt("HSM_DECRYPT_RETRY_TIME"));
		
		entity.setCONFIG_PARAMS(rs.getString("CONFIG_PARAMS"));
		entity.setCONFIG_RELOAD(rs.getString("CONFIG_RELOAD"));
		
		
		 
        return entity;
		
	}

}

package vn.vietinbank.vpg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariDataSource;

import vn.vietinbank.vpg.config.DataSourceConfig;
import vn.vietinbank.vpg.entity.VpgSystemParamsEntity;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.ResourceUtils;

public class VpgSystemParamsDaoImpl implements VpgSystemParamsDaoInterface<VpgSystemParamsEntity> {

	
	
	private DataSource dataSource = CommonUtils.dataSource;
	
	

	@Override
	public VpgSystemParamsEntity get(String id) {
		
		return null;
	}

	@Override
	public List<VpgSystemParamsEntity> getAll() {
		
		return null;
	}

	@Override
	public void save(VpgSystemParamsEntity t) {
		
	}

	@Override
	public void update(VpgSystemParamsEntity t, String[] params) {
		
	}

	@Override
	public void delete(VpgSystemParamsEntity t) {
		
	}

	@Override
	public VpgSystemParamsEntity getByServiceCodeKey(String serviceCode, String keyName) {
		
		return null;
	}

	@Override
	public Dictionary getByServiceCode(String serviceCode) {
		
		Dictionary dicParams = null;
		
		String sql = "SELECT * FROM VPG_SYSTEM_PARAMS WHERE IS_ACTIVE = '1' AND SERVICE_CODE = ?";
		
		Connection conn = null;
		
		try {
		
			if(ResourceUtils.getVpgDataSourceIsPool().equals("1")) {
				conn = DataSourceConfig.getConnection();
			}else {
				conn = dataSource.getConnection();
			}
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, serviceCode);
			
			ResultSet rs = ps.executeQuery();
			
			dicParams = new Hashtable();
			
			while (rs.next()) {
				
				dicParams.put(rs.getString("PARAM_KEY"), rs.getString("PARAM_VALUE"));
				
			}
			
			rs.close();
			ps.close();
			return dicParams;
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

	

}

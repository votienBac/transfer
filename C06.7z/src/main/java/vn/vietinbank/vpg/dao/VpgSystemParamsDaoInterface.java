package vn.vietinbank.vpg.dao;

import java.util.Dictionary;
import java.util.List;
import java.util.Optional;

public interface VpgSystemParamsDaoInterface<T> {

	Dictionary getByServiceCode(String serviceCode);
	
	T getByServiceCodeKey(String serviceCode, String keyName);
	
	
	T get(String id);
    
    List<T> getAll();
     
    void save(T t);
     
    void update(T t, String[] params);
    
     
    void delete(T t);
	
}

package vn.vietinbank.vpg.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import vn.vietinbank.vpg.entity.*;

public class VpgSystemParamsRowMapper implements RowMapper<VpgSystemParamsEntity> {

	VpgSystemParamsEntity entity = null;
	
	@Override
	public VpgSystemParamsEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		entity = new VpgSystemParamsEntity();
		 
		entity.setId(rs.getLong("ID"));
		
		entity.setCreate_date(rs.getDate("CREATE_DATE"));
				
		entity.setService_code(rs.getString("SERVICE_CODE"));
		
		entity.setIs_active(rs.getString("IS_ACTIVE"));
		
		entity.setParam_type(rs.getString("PARAM_TYPE"));
		
		entity.setParam_key(rs.getString("PARAM_KEY"));
		
		entity.setParam_value(rs.getString("PARAM_VALUE"));
		
		entity.setParam_desc(rs.getString("PARAM_DESC"));
		
		entity.setCreate_user(rs.getInt("CREATE_USER"));
		
		entity.setLast_user(rs.getInt("LAST_USER"));
		
		entity.setLast_date(rs.getDate("LAST_DATE"));
		
		
        return entity;
		
	}

}

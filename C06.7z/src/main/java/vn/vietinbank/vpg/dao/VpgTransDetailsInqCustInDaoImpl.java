package vn.vietinbank.vpg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariDataSource;

import vn.vietinbank.vpg.config.DataSourceConfig;
import vn.vietinbank.vpg.entity.VpgSystemParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransDetailsInqCustInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.ResourceUtils;


public class VpgTransDetailsInqCustInDaoImpl implements VpgTransDetailsInqCustInDaoInterface<VpgTransDetailsInqCustInEntity> {
	
	private DataSource dataSource = CommonUtils.dataSource;
	
	private JdbcTemplate jdbcTemplate = CommonUtils.jdbcTemplate;

	public VpgTransDetailsInqCustInDaoImpl() {
		
	}
	
	@Override
	public List<VpgTransDetailsInqCustInEntity> get(String custCode) {
		String sql = "SELECT * FROM VPG_TRANS_DETAILS_INQ_CUST_IN WHERE customer_code = '" + custCode + "' AND caching = '1' ORDER BY ID DESC";
		
		return jdbcTemplate.query(
	                sql,
	                new VpgTransDetailsInqCustInRowMapper());
	}

	@Override
	public List<VpgTransDetailsInqCustInEntity> getAll() {
		return null;
	}

	@Override
	public void save(VpgTransDetailsInqCustInEntity t) {
		
		String sql = "INSERT INTO VPG_TRANS_DETAILS_INQ_CUST_IN " +
				"(ID,"
				+ "LOG_DATE,"
				
				+ "LOG_ID,"
				+ "HOSTINFO,"
				+ "TRANS_DIRECT,"
				+ "TRANS_TYPE,"
				+ "GATEWAY_ID,"
				+ "SERVICE_CODE,"
				+ "PRODUCT_CODE,"
				+ "PROVIDER_ID,"
				+ "PROCESSING_CODE,"
				+ "PAYMENT_CHANNEL,"
				
				+ "MSG_ID,"
				+ "MSG_TYPE,"
				+ "TRANS_ID,"
				+ "TRANS_TIME,"
				+ "SERVICE_TYPE,"
				+ "PAYMENT_TYPE,"
				+ "PAYMENT_METHOD,"
				+ "CUSTOMER_CODE,"
				+ "CUSTOMER_NAME,"
				+ "CUSTOMER_ACCT,"
				
				+ "BIRTH_DATE,"
				+ "GENDER,"
				+ "ID_CARD_TYPE,"
				+ "ID_CARD,"
				+ "ID_CARD_ISS_DATE,"
				+ "ID_CARD_ISS_PLACE,"
				+ "CUSTOMER_ADDR,"
				+ "CUSTOMER_PHONE, "
				+ "CUSTOMER_IDC,"
				+ "CUSTOMER_STREET,"
				
				+ "AREA_CODE,"
				+ "PROVINCE_CODE,"
				+ "TID,"
				+ "ACCT_NO,"
				+ "EMAIL,"
				+ "STATUS,"
				+ "BILL_ID,"
				+ "BILL_TERM,"
				+ "BILL_DETAILS,"
				+ "AMOUNT,"
				
				+ "AMOUNT_MIN,"
				+ "FEE,"
				+ "VAT,"
				+ "CURRENCY_CODE,"
				+ "PAYMENT_ID,"
				+ "MSG_ORIGIN,"
				+ "MSG_CONVERT,"
				+ "MSG_SIGNED,"
				+ "MSG_ENCRYPED,"
				+ "ERROR_CODE,"
				
				+ "ERROR_DESC,"
				+ "ERROR_CODE_VPG,"
				+ "ERROR_DESC_VPG,"
				+ "STATUS_CODE,"
				+ "STATUS_MESSAGE,"
				+ "IS_RETRY,"
				+ "IS_CACHING,"
				+ "YEAR,"
				+ "MONTH,"
				+ "DAY,"
				
				+ "CLIENT_ID,"
				+ "SESSIONID,"
				+ "LOG_NOTE,"
				+ "ADD_INFO,"
				+ "PRESEVE1,"
				+ "PRESEVE2,"
				+ "PRESEVE3,"
				+ "PROCESS_TIME_DB,"
				+ "PROCESS_TIME_PRV,"
				+ "PROCESS_TIME_CVT,"
				
				+ "PROCESS_TIME,"
				+ "PROCESS_TIME_MQ"
				+ ") "
				
				+ " VALUES (VPG_TRANS_LOG_IN_SEQ.nextval,sysdate,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?"
				+ ")";
		
		Connection conn = null;
		
		try {
			
			
			 if(ResourceUtils.getVpgDataSourceIsPool().equals("1")) {
					conn = DataSourceConfig.getConnection();
				}else {
					conn = dataSource.getConnection();
				}
			
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1,t.getLog_id());
			ps.setString(2,t.getHostinfo());
			ps.setString(3,t.getTrans_direct());
			ps.setString(4,t.getTrans_type());
			ps.setString(5,t.getGateway_id());
			ps.setString(6,t.getService_code());
			ps.setString(7,t.getProduct_code());
			ps.setString(8,t.getProvider_id());
			ps.setString(9,t.getProcessing_code());
			ps.setString(10,t.getPayment_channel());
			
			
			ps.setString(11,t.getMsg_id());
			ps.setString(12,t.getMsg_type());
			ps.setString(13,t.getTrans_id());
			ps.setString(14,t.getTrans_time());
			
			ps.setString(15,t.getService_type());
			ps.setString(16,t.getPayment_type());
			ps.setString(17,t.getPayment_method());
			ps.setString(18,t.getCustomer_code());
			ps.setString(19,t.getCustomer_name());
			ps.setString(20,t.getCustomer_acct());
			ps.setString(21,t.getBirth_date());
			ps.setString(22,t.getGender());
			ps.setString(23,t.getId_card_type());
			ps.setString(24,t.getId_card());
			ps.setString(25,t.getId_card_iss_date());
			ps.setString(26,t.getId_card_iss_place());
			ps.setString(27,t.getCustomer_addr());
			ps.setString(28,t.getCustomer_phone());
			ps.setString(29,t.getCustomer_idc());
			ps.setString(30,t.getCustomer_street());
			ps.setString(31,t.getArea_code());
			ps.setString(32,t.getProvince_code());
			ps.setString(33,t.getTid());
			ps.setString(34,t.getAcct_no());
			ps.setString(35,t.getEmail());
			ps.setString(36,t.getStatus());
			ps.setString(37,t.getBill_id());
			ps.setString(38,t.getBill_term());
			ps.setString(39,t.getBill_details());
			
			ps.setString(40,t.getAmount());
			ps.setString(41,t.getAmount_min());
			ps.setString(42,t.getFee());
			ps.setString(43,t.getVat());
			ps.setString(44,t.getCurrency_code());
			ps.setString(45,t.getPayment_id());
			ps.setString(46,t.getMsg_origin());
			ps.setString(47,t.getMsg_convert());
			ps.setString(48,t.getMsg_signed());
			ps.setString(49,t.getMsg_encrypted());
			ps.setString(50,t.getError_code());
			ps.setString(51,t.getError_desc());
			ps.setString(52,t.getError_code_vpg());
			ps.setString(53,t.getError_desc_vpg());
			ps.setString(54,t.getStatus_code());
			ps.setString(55,t.getStatus_message());
			
			ps.setString(56,t.getIs_retry());
			ps.setString(57,t.getIs_caching());
			
			ps.setInt(58,t.getYear());
			ps.setInt(59,t.getMonth());
			ps.setInt(60,t.getDay());

			ps.setString(61,t.getClient_id());
			
			ps.setString(62,t.getSessionid());
			ps.setString(63,t.getLog_note());
			ps.setString(64,t.getAdd_info());
			ps.setString(65,t.getPreseve1());
			ps.setString(66,t.getPreseve2());
			ps.setString(67,t.getPreseve3());
			ps.setLong(68,t.getPROCESS_TIME_DB());
			ps.setLong(69,t.getPROCESS_TIME_PRV());
			ps.setLong(70,t.getPROCESS_TIME_CVT());
			ps.setLong(71,t.getPROCESS_TIME());
			ps.setLong(72,t.getPROCESS_TIME_MQ());
			
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
	}

	

	

}

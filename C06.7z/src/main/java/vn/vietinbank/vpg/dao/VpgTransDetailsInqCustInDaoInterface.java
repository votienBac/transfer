package vn.vietinbank.vpg.dao;

import java.util.List;


public interface VpgTransDetailsInqCustInDaoInterface<T> {
	
	List<T> get(String custCode);
    
    List<T> getAll();
     
    void save(T t);
    
}

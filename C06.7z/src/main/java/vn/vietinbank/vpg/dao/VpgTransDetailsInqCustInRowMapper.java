package vn.vietinbank.vpg.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import vn.vietinbank.vpg.entity.*;


public class VpgTransDetailsInqCustInRowMapper implements RowMapper<VpgTransDetailsInqCustInEntity> {

	@Override
	public VpgTransDetailsInqCustInEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		VpgTransDetailsInqCustInEntity entity = new VpgTransDetailsInqCustInEntity();
		
		entity.setId(rs.getLong("ID"));
		entity.setLog_date(rs.getDate("log_date"));
		entity.setLog_id(rs.getString("log_id"));
		entity.setLog_id(rs.getString("hostinfo"));
		
		entity.setLog_id(rs.getString("trans_direct"));
		entity.setLog_id(rs.getString("trans_type"));
		entity.setLog_id(rs.getString("gateway_id"));
		entity.setLog_id(rs.getString("service_code"));
		entity.setLog_id(rs.getString("product_code"));
		entity.setLog_id(rs.getString("provider_id"));
		entity.setLog_id(rs.getString("processing_code"));
		entity.setLog_id(rs.getString("payment_channel"));
		entity.setLog_id(rs.getString("msg_id"));
		entity.setLog_id(rs.getString("msg_type"));
		entity.setLog_id(rs.getString("trans_id"));
		
		entity.setLog_id(rs.getString("trans_time"));
		entity.setLog_id(rs.getString("service_type"));
		entity.setLog_id(rs.getString("payment_type"));
		entity.setLog_id(rs.getString("payment_method"));
		entity.setLog_id(rs.getString("customer_code"));
		entity.setLog_id(rs.getString("customer_name"));
		entity.setLog_id(rs.getString("customer_acct"));
		entity.setLog_id(rs.getString("birth_date"));
		entity.setLog_id(rs.getString("gender"));
		entity.setLog_id(rs.getString("id_card_type"));
		
		entity.setLog_id(rs.getString("id_card"));
		entity.setLog_id(rs.getString("id_card_iss_date"));
		entity.setLog_id(rs.getString("id_card_iss_place"));
		entity.setLog_id(rs.getString("customer_addr"));
		entity.setLog_id(rs.getString("customer_phone"));
		entity.setLog_id(rs.getString("customer_idc"));
		entity.setLog_id(rs.getString("customer_street"));
		entity.setLog_id(rs.getString("area_code"));
		entity.setLog_id(rs.getString("province_code"));
		entity.setLog_id(rs.getString("tid"));
		entity.setLog_id(rs.getString("acct_no"));
		entity.setLog_id(rs.getString("email"));
		entity.setLog_id(rs.getString("status"));
		entity.setLog_id(rs.getString("bill_id"));
		entity.setLog_id(rs.getString("bill_term"));
		entity.setLog_id(rs.getString("bill_details"));
		
		entity.setLog_id(rs.getString("amount"));
		entity.setLog_id(rs.getString("amount_min"));
		entity.setLog_id(rs.getString("fee"));
		entity.setLog_id(rs.getString("vat"));
		entity.setLog_id(rs.getString("currency_code"));
		entity.setLog_id(rs.getString("payment_id"));
		entity.setLog_id(rs.getString("msg_origin"));
		entity.setLog_id(rs.getString("msg_convert"));
		entity.setLog_id(rs.getString("msg_signed"));
		entity.setLog_id(rs.getString("msg_encryped"));
		entity.setLog_id(rs.getString("error_code"));
		entity.setLog_id(rs.getString("error_desc"));
		
		entity.setLog_id(rs.getString("error_code_vpg"));
		entity.setLog_id(rs.getString("error_desc_vpg"));
		entity.setLog_id(rs.getString("status_code"));
		entity.setLog_id(rs.getString("status_message"));
		entity.setLog_id(rs.getString("is_retry"));
		entity.setLog_id(rs.getString("is_caching"));
		entity.setLog_id(rs.getString("year"));
		entity.setLog_id(rs.getString("month"));
		entity.setLog_id(rs.getString("day"));
		entity.setLog_id(rs.getString("client_id"));
		
		entity.setLog_id(rs.getString("sessionid"));
		entity.setLog_id(rs.getString("log_note"));
		entity.setLog_id(rs.getString("add_info"));
		entity.setLog_id(rs.getString("preseve1"));
		entity.setLog_id(rs.getString("preseve2"));
		entity.setLog_id(rs.getString("preseve3"));
		entity.setLog_id(rs.getString("process_time_db"));
		entity.setLog_id(rs.getString("process_time_prv"));
		entity.setLog_id(rs.getString("process_time_cvt"));
		entity.setLog_id(rs.getString("process_time"));
		entity.setLog_id(rs.getString("process_time_mq"));
		 
        return entity;
		
	}

}

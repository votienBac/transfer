package vn.vietinbank.vpg.dao;

public interface VpgTransLogInDaoInterface<T> {
    void save(T t);
     
    String getSequence(String sql);
    
}

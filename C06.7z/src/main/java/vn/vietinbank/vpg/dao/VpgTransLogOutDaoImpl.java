package vn.vietinbank.vpg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.zaxxer.hikari.HikariDataSource;

import vn.vietinbank.vpg.config.DataSourceConfig;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.ResourceUtils;


public class VpgTransLogOutDaoImpl implements VpgTransLogOutDaoInterface<VpgTransLogOutEntity> {


	private VpgTransLogOutEntity entity = null;
	
	
	private DataSource dataSource = CommonUtils.dataSource;
	
	private JdbcTemplate jdbcTemplate = CommonUtils.jdbcTemplate;

	public VpgTransLogOutDaoImpl() {
		
	}
	
	@Override
	public void save(VpgTransLogOutEntity t) {
		
		String sql = "INSERT INTO VPG_TRANS_LOG_OUT " +
				"(ID,"
				+ "LOG_DATE,"
				+ "LOG_ID,"
				+ "HOSTINFO,"
				+ "TRANS_DIRECT,"
				+ "TRANS_TYPE,"
				+ "GATEWAY_ID,"
				+ "SERVICE_CODE,"
				+ "PRODUCT_CODE,"
				+ "PROVIDER_ID,"
				+ "PROCESSING_CODE,"
				+ "PAYMENT_CHANNEL,"
				+ "PAYMENT_METHOD,"
				+ "MSG_ID,"
				+ "MSG_TYPE,"
				+ "TRANS_ID,"
				+ "CUSTOMER_CODE,"
				+ "CUSTOMER_NAME,"
				+ "CUSTOMER_ADDR,"
				+ "CUSTOMER_PHONE, "
				+ "CUSTOMER_IDC,"
				+ "CLIENT_ID,"
				+ "PAYMENT_CODE,"
				+ "TRACE_NO,"
				+ "BILL_ID,"
				+ "BILL_TERM,"
				+ "BILL_AMOUNT,"
				+ "BILL_FEE,"
				+ "BILL_VAT,"
				+ "BILL_DETAILS,"
				+ "PAYMENT_ID,"
				+ "MSG_ORIGIN,"
				+ "MSG_CONVERT,"
				+ "MSG_SIGNED,"
				+ "MSG_ENCRYPED,"
				+ "ERROR_CODE,"
				+ "ERROR_DESC,"
				+ "ERROR_CODE_VPG,"
				+ "ERROR_DESC_VPG,"
				+ "IS_RETRY,"
				+ "YEAR,"
				+ "MONTH,"
				+ "DAY,"
				+ "SESSIONID,"
				+ "LOG_NOTE,"
				+ "PRESEVE1,"
				+ "PRESEVE2,"
				+ "PRESEVE3,"
				
				+ "PROCESS_TIME_DB,"
				+ "PROCESS_TIME_PRV,"
				+ "PROCESS_TIME_CVT,"
				+ "PROCESS_TIME,"
				+ "PROCESS_TIME_MQ"
				
				+ ") "
				
				+ " VALUES (VPG_TRANS_LOG_OUT_SEQ.nextval,sysdate,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,"
				+ "?"
				+ ")";
		
		
			
		Connection conn = null;
		
		try {
			
			  if(ResourceUtils.getVpgDataSourceIsPool().equals("1")) {
				conn = DataSourceConfig.getConnection();
			}else {
				conn = dataSource.getConnection();
			}
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1,t.getLog_id());
			ps.setString(2,t.getHostinfo());
			ps.setString(3,t.getTrans_direct());
			ps.setString(4,t.getTrans_type());
			ps.setString(5,t.getGateway_id());
			ps.setString(6,t.getService_code());
			ps.setString(7,t.getProduct_code());
			ps.setString(8,t.getProvider_id());
			ps.setString(9,t.getProcessing_code());
			ps.setString(10,t.getPayment_channel());
			ps.setString(11,t.getPayment_method());
			ps.setString(12,t.getMsg_id());
			ps.setString(13,t.getMsg_type());
			ps.setString(14,t.getTrans_id());
			ps.setString(15,t.getCustomer_code());
			ps.setString(16,t.getCustomer_name());
			ps.setString(17,t.getCustomer_addr());
			ps.setString(18,t.getCustomer_phone());
			ps.setString(19,t.getCustomer_idc());
			ps.setString(20,t.getClient_id());
			ps.setString(21,t.getPayment_code());
			ps.setString(22,t.getTrace_no());
			ps.setString(23,t.getBill_id());
			ps.setString(24,t.getBill_term());
			ps.setString(25,t.getBill_amount());
			ps.setString(26,t.getBill_fee());
			ps.setString(27,t.getBill_vat());
			ps.setString(28,t.getBill_details());
			ps.setString(29,t.getPayment_id());
			ps.setString(30,t.getMsg_origin());
			ps.setString(31,t.getMsg_convert());
			ps.setString(32,t.getMsg_signed());
			ps.setString(33,t.getMsg_encrypted());
			ps.setString(34,t.getError_code());
			ps.setString(35,t.getError_desc());
			ps.setString(36,t.getError_code_vpg());
			ps.setString(37,t.getError_desc_vpg());
			ps.setString(38,t.getIs_retry());
			ps.setInt(39,t.getYear());
			ps.setInt(40,t.getMonth());
			ps.setInt(41,t.getDay());
			ps.setString(42,t.getSessionid());
			ps.setString(43,t.getLog_note());
			ps.setString(44,t.getPreseve1());
			ps.setString(45,t.getPreseve2());
			ps.setString(46,t.getPreseve3());
			ps.setInt(47,t.getPROCESS_TIME_DB());
			ps.setInt(48,t.getPROCESS_TIME_PRV());
			ps.setInt(49,t.getPROCESS_TIME_CVT());
			ps.setInt(50,t.getPROCESS_TIME());
			ps.setInt(51,t.getPROCESS_TIME_MQ());
			
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
				
	}

	@Override
	public String getSequence(String sql) {

		final SqlRowSet sqlRowSet = this.jdbcTemplate.queryForRowSet(sql);
		  sqlRowSet.next();
		  return String.valueOf(sqlRowSet.getLong(1));
		
		
	}
	

}

package vn.vietinbank.vpg.dao;

public interface VpgTransLogOutDaoInterface<T> {
    void save(T t);
     
    String getSequence(String sql);
    
}

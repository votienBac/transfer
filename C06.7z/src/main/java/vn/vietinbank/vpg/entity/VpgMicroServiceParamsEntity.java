package vn.vietinbank.vpg.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "VPG_MICRO_SERVICE_PARAMS", schema = "VPG2")
public class VpgMicroServiceParamsEntity implements java.io.Serializable {

	@Id
	@Column(name = "ID")
	  private long ID;
	
	@Column(name = "CREATED_DATE")
	  private Date CREATED_DATE;
	
	@Column(name = "LAST_DATE")
	  private Date LAST_DATE;
	
	@Column(name = "GATEWAY_ID")
	  private String GATEWAY_ID;
	
	@Column(name = "PROVIDER_ID")
	  private String PROVIDER_ID;
	
	@Column(name = "MERCHANT_ID")
	  private String MERCHANT_ID;
	
	@Column(name = "PRODUCT_CODE")
	  private String PRODUCT_CODE;
	
	@Column(name = "SERVICE_CODE")
	  private String SERVICE_CODE;
	
	@Column(name = "USERNAME")
	  private String USERNAME;
	
	@Column(name = "PASSWORD")
	  private String PASSWORD;
	
	@Column(name = "TOKEN")
	  private String TOKEN;
	@Column(name = "MSG_TYPE")
	  private String MSG_TYPE;
	@Column(name = "CHANGE_FORMAT")
	  private String CHANGE_FORMAT;
	@Column(name = "IS_ACTIVE")
	  private String IS_ACTIVE;
	@Column(name = "URL_PARTNER")
	  private String URL_PARTNER;
	@Column(name = "URL_TIMEOUT")
	  private String URL_TIMEOUT;
	@Column(name = "URL_HEADER")
	  private String URL_HEADER;
	@Column(name = "URL_USR")
	  private String URL_USR;
	@Column(name = "URL_PWD")
	  private String URL_PWD;
	@Column(name = "DESCRIPTION")
	  private String DESCRIPTION;
	@Column(name = "HSM_ENABLE")
	  private String HSM_ENABLE;
	@Column(name = "HSM_APPID")
	  private String HSM_APPID;
	@Column(name = "HSM_URL")
	  private String HSM_URL;
	@Column(name = "HSM_TIMEOUT")
	  private String HSM_TIMEOUT;
	@Column(name = "HSM_IP")
	  private String HSM_IP;
	@Column(name = "HSM_PORT")
	  private String HSM_PORT;
	
	@Column(name = "HSM_SIGN_ENABLE")
	  private String HSM_SIGN_ENABLE;
	@Column(name = "HSM_VERIFY_ENABLE")
	  private String HSM_VERIFY_ENABLE;
	@Column(name = "HSM_USR")
	  private String HSM_USR;
	@Column(name = "HSM_PWD")
	  private String HSM_PWD;
	@Column(name = "HSM_CERT_LABEL")
	  private String HSM_CERT_LABEL;
	@Column(name = "HSM_SIGN_METHOD")
	  private String HSM_SIGN_METHOD;
	@Column(name = "HSM_SIGN_ALIAS")
	  private String HSM_SIGN_ALIAS;
	@Column(name = "HSM_VERIFY_METHOD")
	  private String HSM_VERIFY_METHOD;
	@Column(name = "HSM_VERIFY_ALIAS")
	  private String HSM_VERIFY_ALIAS;
	@Column(name = "HSM_TRANSPORT_REALM")
	  private String HSM_TRANSPORT_REALM;
	
	@Column(name = "HSM_ENCRYPT_ENABLE")
	  private String HSM_ENCRYPT_ENABLE;
	@Column(name = "HSM_DECRYPT_ENABLE")
	  private String HSM_DECRYPT_ENABLE;
	@Column(name = "HSM_ENCRYPT_METHOD")
	  private String HSM_ENCRYPT_METHOD;
	@Column(name = "HSM_ENCRYPT_ALIAS")
	  private String HSM_ENCRYPT_ALIAS;
	@Column(name = "HSM_DECRYPT_METHOD")
	  private String HSM_DECRYPT_METHOD;
	@Column(name = "HSM_DECRYPT_ALIAS")
	  private String HSM_DECRYPT_ALIAS;
	
	@Column(name = "VPG_SIGN_CRT")
	  private String VPG_SIGN_CRT;
	@Column(name = "VPG_SIGN_PRV")
	  private String VPG_SIGN_PRV;
	@Column(name = "VPG_SIGN_PWD")
	  private String VPG_SIGN_PWD;
	@Column(name = "VPG_ENC_CRT")
	  private String VPG_ENC_CRT;
	@Column(name = "VPG_ENC_PRV")
	  private String VPG_ENC_PRV;
	@Column(name = "VPG_ENC_PWD")
	  private String VPG_ENC_PWD;
	
	@Column(name = "PARTNER_ENC_CRT")
	  private String PARTNER_ENC_CRT;
	@Column(name = "PARTNER_SIGN_CRT")
	  private String PARTNER_SIGN_CRT;
	@Column(name = "PRESEVE1")
	  private String PRESEVE1;
	@Column(name = "PRESEVE2")
	  private String PRESEVE2;
	@Column(name = "PRESEVE3")
	  private String PRESEVE3;
	@Column(name = "USR_UPD")
	  private String USR_UPD;
	
	@Column(name = "STRUCT_RQ")
	  private String STRUCT_RQ;
	@Column(name = "STRUCT_RS")
	  private String STRUCT_RS;
	
	@Column(name = "ORDER_NUM")
	  private int ORDER_NUM;
	
	@Column(name = "URL_METHOD")
	private String URL_METHOD;
	
	@Column(name = "URL_TIMEOUT_SOCKET")
	private String URL_TIMEOUT_SOCKET;
	
	@Column(name = "URL_ACTION")
	private String URL_ACTION;
	
	@Column(name = "URL_TOKEN")
	private String URL_TOKEN;
	
	@Column(name = "URL_TOKEN_CREATE")
	private String URL_TOKEN_CREATE;
	
	@Column(name = "URL_TOKEN_EXPIRE")
	private String URL_TOKEN_EXPIRE;
	
	@Column(name = "URL_TOKEN_TIME")
	private String URL_TOKEN_TIME;
	
	@Column(name = "HSM_SIGN_RETRY")
	private int HSM_SIGN_RETRY;
	
	@Column(name = "HSM_VERIFY_RETRY")
	private int HSM_VERIFY_RETRY;
	
	@Column(name = "HSM_ENCRYPT_RETRY")
	private int HSM_ENCRYPT_RETRY;
	
	@Column(name = "HSM_DECRYPT_RETRY")
	private int HSM_DECRYPT_RETRY;
	
	@Column(name = "HSM_SIGN_RETRY_TIME")
	private int HSM_SIGN_RETRY_TIME;
	
	@Column(name = "HSM_VERIFY_RETRY_TIME")
	private int HSM_VERIFY_RETRY_TIME;
	
	@Column(name = "HSM_ENCRYPT_RETRY_TIME")
	private int HSM_ENCRYPT_RETRY_TIME;
	
	@Column(name = "HSM_DECRYPT_RETRY_TIME")
	private int HSM_DECRYPT_RETRY_TIME;
	
	@Column(name = "CONFIG_PARAMS")
	private String CONFIG_PARAMS;
	
	@Column(name = "CONFIG_RELOAD")
	private String CONFIG_RELOAD;
	
	
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public Date getCREATED_DATE() {
		return CREATED_DATE;
	}
	public void setCREATED_DATE(Date cREATED_DATE) {
		CREATED_DATE = cREATED_DATE;
	}
	public Date getLAST_DATE() {
		return LAST_DATE;
	}
	public void setLAST_DATE(Date lAST_DATE) {
		LAST_DATE = lAST_DATE;
	}
	public String getGATEWAY_ID() {
		return GATEWAY_ID;
	}
	public void setGATEWAY_ID(String gATEWAY_ID) {
		GATEWAY_ID = gATEWAY_ID;
	}
	public String getPROVIDER_ID() {
		return PROVIDER_ID;
	}
	public void setPROVIDER_ID(String pROVIDER_ID) {
		PROVIDER_ID = pROVIDER_ID;
	}
	public String getMERCHANT_ID() {
		return MERCHANT_ID;
	}
	public void setMERCHANT_ID(String mERCHANT_ID) {
		MERCHANT_ID = mERCHANT_ID;
	}
	public String getPRODUCT_CODE() {
		return PRODUCT_CODE;
	}
	public void setPRODUCT_CODE(String pRODUCT_CODE) {
		PRODUCT_CODE = pRODUCT_CODE;
	}
	public String getSERVICE_CODE() {
		return SERVICE_CODE;
	}
	public void setSERVICE_CODE(String sERVICE_CODE) {
		SERVICE_CODE = sERVICE_CODE;
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	public String getTOKEN() {
		return TOKEN;
	}
	public void setTOKEN(String tOKEN) {
		TOKEN = tOKEN;
	}
	public String getMSG_TYPE() {
		return MSG_TYPE;
	}
	public void setMSG_TYPE(String mSG_TYPE) {
		MSG_TYPE = mSG_TYPE;
	}
	public String getCHANGE_FORMAT() {
		return CHANGE_FORMAT;
	}
	public void setCHANGE_FORMAT(String cHANGE_FORMAT) {
		CHANGE_FORMAT = cHANGE_FORMAT;
	}
	public String getIS_ACTIVE() {
		return IS_ACTIVE;
	}
	public void setIS_ACTIVE(String iS_ACTIVE) {
		IS_ACTIVE = iS_ACTIVE;
	}
	public String getURL_PARTNER() {
		return URL_PARTNER;
	}
	public void setURL_PARTNER(String uRL_PARTNER) {
		URL_PARTNER = uRL_PARTNER;
	}
	public String getURL_TIMEOUT() {
		return URL_TIMEOUT;
	}
	public void setURL_TIMEOUT(String uRL_TIMEOUT) {
		URL_TIMEOUT = uRL_TIMEOUT;
	}
	public String getURL_HEADER() {
		return URL_HEADER;
	}
	public void setURL_HEADER(String uRL_HEADER) {
		URL_HEADER = uRL_HEADER;
	}
	public String getURL_USR() {
		return URL_USR;
	}
	public void setURL_USR(String uRL_USR) {
		URL_USR = uRL_USR;
	}
	public String getURL_PWD() {
		return URL_PWD;
	}
	public void setURL_PWD(String uRL_PWD) {
		URL_PWD = uRL_PWD;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	public String getHSM_ENABLE() {
		return HSM_ENABLE;
	}
	public void setHSM_ENABLE(String hSM_ENABLE) {
		HSM_ENABLE = hSM_ENABLE;
	}
	public String getHSM_APPID() {
		return HSM_APPID;
	}
	public void setHSM_APPID(String hSM_APPID) {
		HSM_APPID = hSM_APPID;
	}
	public String getHSM_URL() {
		return HSM_URL;
	}
	public void setHSM_URL(String hSM_URL) {
		HSM_URL = hSM_URL;
	}
	public String getHSM_TIMEOUT() {
		return HSM_TIMEOUT;
	}
	public void setHSM_TIMEOUT(String hSM_TIMEOUT) {
		HSM_TIMEOUT = hSM_TIMEOUT;
	}
	public String getHSM_IP() {
		return HSM_IP;
	}
	public void setHSM_IP(String hSM_IP) {
		HSM_IP = hSM_IP;
	}
	public String getHSM_PORT() {
		return HSM_PORT;
	}
	public void setHSM_PORT(String hSM_PORT) {
		HSM_PORT = hSM_PORT;
	}
	public String getHSM_SIGN_ENABLE() {
		return HSM_SIGN_ENABLE;
	}
	public void setHSM_SIGN_ENABLE(String hSM_SIGN_ENABLE) {
		HSM_SIGN_ENABLE = hSM_SIGN_ENABLE;
	}
	public String getHSM_VERIFY_ENABLE() {
		return HSM_VERIFY_ENABLE;
	}
	public void setHSM_VERIFY_ENABLE(String hSM_VERIFY_ENABLE) {
		HSM_VERIFY_ENABLE = hSM_VERIFY_ENABLE;
	}
	public String getHSM_USR() {
		return HSM_USR;
	}
	public void setHSM_USR(String hSM_USR) {
		HSM_USR = hSM_USR;
	}
	public String getHSM_PWD() {
		return HSM_PWD;
	}
	public void setHSM_PWD(String hSM_PWD) {
		HSM_PWD = hSM_PWD;
	}
	public String getHSM_CERT_LABEL() {
		return HSM_CERT_LABEL;
	}
	public void setHSM_CERT_LABEL(String hSM_CERT_LABEL) {
		HSM_CERT_LABEL = hSM_CERT_LABEL;
	}
	public String getHSM_SIGN_METHOD() {
		return HSM_SIGN_METHOD;
	}
	public void setHSM_SIGN_METHOD(String hSM_SIGN_METHOD) {
		HSM_SIGN_METHOD = hSM_SIGN_METHOD;
	}
	public String getHSM_SIGN_ALIAS() {
		return HSM_SIGN_ALIAS;
	}
	public void setHSM_SIGN_ALIAS(String hSM_SIGN_ALIAS) {
		HSM_SIGN_ALIAS = hSM_SIGN_ALIAS;
	}
	public String getHSM_VERIFY_METHOD() {
		return HSM_VERIFY_METHOD;
	}
	public void setHSM_VERIFY_METHOD(String hSM_VERIFY_METHOD) {
		HSM_VERIFY_METHOD = hSM_VERIFY_METHOD;
	}
	public String getHSM_VERIFY_ALIAS() {
		return HSM_VERIFY_ALIAS;
	}
	public void setHSM_VERIFY_ALIAS(String hSM_VERIFY_ALIAS) {
		HSM_VERIFY_ALIAS = hSM_VERIFY_ALIAS;
	}
	public String getHSM_TRANSPORT_REALM() {
		return HSM_TRANSPORT_REALM;
	}
	public void setHSM_TRANSPORT_REALM(String hSM_TRANSPORT_REALM) {
		HSM_TRANSPORT_REALM = hSM_TRANSPORT_REALM;
	}
	public String getHSM_ENCRYPT_ENABLE() {
		return HSM_ENCRYPT_ENABLE;
	}
	public void setHSM_ENCRYPT_ENABLE(String hSM_ENCRYPT_ENABLE) {
		HSM_ENCRYPT_ENABLE = hSM_ENCRYPT_ENABLE;
	}
	public String getHSM_DECRYPT_ENABLE() {
		return HSM_DECRYPT_ENABLE;
	}
	public void setHSM_DECRYPT_ENABLE(String hSM_DECRYPT_ENABLE) {
		HSM_DECRYPT_ENABLE = hSM_DECRYPT_ENABLE;
	}
	public String getHSM_ENCRYPT_METHOD() {
		return HSM_ENCRYPT_METHOD;
	}
	public void setHSM_ENCRYPT_METHOD(String hSM_ENCRYPT_METHOD) {
		HSM_ENCRYPT_METHOD = hSM_ENCRYPT_METHOD;
	}
	public String getHSM_ENCRYPT_ALIAS() {
		return HSM_ENCRYPT_ALIAS;
	}
	public void setHSM_ENCRYPT_ALIAS(String hSM_ENCRYPT_ALIAS) {
		HSM_ENCRYPT_ALIAS = hSM_ENCRYPT_ALIAS;
	}
	public String getHSM_DECRYPT_METHOD() {
		return HSM_DECRYPT_METHOD;
	}
	public void setHSM_DECRYPT_METHOD(String hSM_DECRYPT_METHOD) {
		HSM_DECRYPT_METHOD = hSM_DECRYPT_METHOD;
	}
	public String getHSM_DECRYPT_ALIAS() {
		return HSM_DECRYPT_ALIAS;
	}
	public void setHSM_DECRYPT_ALIAS(String hSM_DECRYPT_ALIAS) {
		HSM_DECRYPT_ALIAS = hSM_DECRYPT_ALIAS;
	}
	public String getVPG_SIGN_CRT() {
		return VPG_SIGN_CRT;
	}
	public void setVPG_SIGN_CRT(String vPG_SIGN_CRT) {
		VPG_SIGN_CRT = vPG_SIGN_CRT;
	}
	public String getVPG_SIGN_PRV() {
		return VPG_SIGN_PRV;
	}
	public void setVPG_SIGN_PRV(String vPG_SIGN_PRV) {
		VPG_SIGN_PRV = vPG_SIGN_PRV;
	}
	public String getVPG_SIGN_PWD() {
		return VPG_SIGN_PWD;
	}
	public void setVPG_SIGN_PWD(String vPG_SIGN_PWD) {
		VPG_SIGN_PWD = vPG_SIGN_PWD;
	}
	public String getVPG_ENC_CRT() {
		return VPG_ENC_CRT;
	}
	public void setVPG_ENC_CRT(String vPG_ENC_CRT) {
		VPG_ENC_CRT = vPG_ENC_CRT;
	}
	public String getVPG_ENC_PRV() {
		return VPG_ENC_PRV;
	}
	public void setVPG_ENC_PRV(String vPG_ENC_PRV) {
		VPG_ENC_PRV = vPG_ENC_PRV;
	}
	public String getVPG_ENC_PWD() {
		return VPG_ENC_PWD;
	}
	public void setVPG_ENC_PWD(String vPG_ENC_PWD) {
		VPG_ENC_PWD = vPG_ENC_PWD;
	}
	public String getPARTNER_ENC_CRT() {
		return PARTNER_ENC_CRT;
	}
	public void setPARTNER_ENC_CRT(String pARTNER_ENC_CRT) {
		PARTNER_ENC_CRT = pARTNER_ENC_CRT;
	}
	public String getPARTNER_SIGN_CRT() {
		return PARTNER_SIGN_CRT;
	}
	public void setPARTNER_SIGN_CRT(String pARTNER_SIGN_CRT) {
		PARTNER_SIGN_CRT = pARTNER_SIGN_CRT;
	}
	public String getPRESEVE1() {
		return PRESEVE1;
	}
	public void setPRESEVE1(String pRESEVE1) {
		PRESEVE1 = pRESEVE1;
	}
	public String getPRESEVE2() {
		return PRESEVE2;
	}
	public void setPRESEVE2(String pRESEVE2) {
		PRESEVE2 = pRESEVE2;
	}
	public String getPRESEVE3() {
		return PRESEVE3;
	}
	public void setPRESEVE3(String pRESEVE3) {
		PRESEVE3 = pRESEVE3;
	}
	public String getUSR_UPD() {
		return USR_UPD;
	}
	public void setUSR_UPD(String uSR_UPD) {
		USR_UPD = uSR_UPD;
	}
	public String getSTRUCT_RQ() {
		return STRUCT_RQ;
	}
	public void setSTRUCT_RQ(String sTRUCT_RQ) {
		STRUCT_RQ = sTRUCT_RQ;
	}
	public String getSTRUCT_RS() {
		return STRUCT_RS;
	}
	public void setSTRUCT_RS(String sTRUCT_RS) {
		STRUCT_RS = sTRUCT_RS;
	}
	public int getORDER_NUM() {
		return ORDER_NUM;
	}
	public void setORDER_NUM(int oRDER_NUM) {
		ORDER_NUM = oRDER_NUM;
	}
	
	public String getURL_METHOD() {
		return URL_METHOD;
	}


	public void setURL_METHOD(String uRL_METHOD) {
		URL_METHOD = uRL_METHOD;
	}


	public String getURL_TIMEOUT_SOCKET() {
		return URL_TIMEOUT_SOCKET;
	}


	public void setURL_TIMEOUT_SOCKET(String uRL_TIMEOUT_SOCKET) {
		URL_TIMEOUT_SOCKET = uRL_TIMEOUT_SOCKET;
	}


	public String getURL_ACTION() {
		return URL_ACTION;
	}


	public void setURL_ACTION(String uRL_ACTION) {
		URL_ACTION = uRL_ACTION;
	}


	public String getURL_TOKEN() {
		return URL_TOKEN;
	}


	public void setURL_TOKEN(String uRL_TOKEN) {
		URL_TOKEN = uRL_TOKEN;
	}


	public String getURL_TOKEN_CREATE() {
		return URL_TOKEN_CREATE;
	}


	public void setURL_TOKEN_CREATE(String uRL_TOKEN_CREATE) {
		URL_TOKEN_CREATE = uRL_TOKEN_CREATE;
	}


	public String getURL_TOKEN_EXPIRE() {
		return URL_TOKEN_EXPIRE;
	}


	public void setURL_TOKEN_EXPIRE(String uRL_TOKEN_EXPIRE) {
		URL_TOKEN_EXPIRE = uRL_TOKEN_EXPIRE;
	}


	public String getURL_TOKEN_TIME() {
		return URL_TOKEN_TIME;
	}


	public void setURL_TOKEN_TIME(String uRL_TOKEN_TIME) {
		URL_TOKEN_TIME = uRL_TOKEN_TIME;
	}
	public int getHSM_SIGN_RETRY() {
		return HSM_SIGN_RETRY;
	}
	public void setHSM_SIGN_RETRY(int hSM_SIGN_RETRY) {
		HSM_SIGN_RETRY = hSM_SIGN_RETRY;
	}
	public int getHSM_VERIFY_RETRY() {
		return HSM_VERIFY_RETRY;
	}
	public void setHSM_VERIFY_RETRY(int hSM_VERIFY_RETRY) {
		HSM_VERIFY_RETRY = hSM_VERIFY_RETRY;
	}
	public int getHSM_ENCRYPT_RETRY() {
		return HSM_ENCRYPT_RETRY;
	}
	public void setHSM_ENCRYPT_RETRY(int hSM_ENCRYPT_RETRY) {
		HSM_ENCRYPT_RETRY = hSM_ENCRYPT_RETRY;
	}
	public int getHSM_DECRYPT_RETRY() {
		return HSM_DECRYPT_RETRY;
	}
	public void setHSM_DECRYPT_RETRY(int hSM_DECRYPT_RETRY) {
		HSM_DECRYPT_RETRY = hSM_DECRYPT_RETRY;
	}
	public int getHSM_SIGN_RETRY_TIME() {
		return HSM_SIGN_RETRY_TIME;
	}
	public void setHSM_SIGN_RETRY_TIME(int hSM_SIGN_RETRY_TIME) {
		HSM_SIGN_RETRY_TIME = hSM_SIGN_RETRY_TIME;
	}
	public int getHSM_VERIFY_RETRY_TIME() {
		return HSM_VERIFY_RETRY_TIME;
	}
	public void setHSM_VERIFY_RETRY_TIME(int hSM_VERIFY_RETRY_TIME) {
		HSM_VERIFY_RETRY_TIME = hSM_VERIFY_RETRY_TIME;
	}
	public int getHSM_ENCRYPT_RETRY_TIME() {
		return HSM_ENCRYPT_RETRY_TIME;
	}
	public void setHSM_ENCRYPT_RETRY_TIME(int hSM_ENCRYPT_RETRY_TIME) {
		HSM_ENCRYPT_RETRY_TIME = hSM_ENCRYPT_RETRY_TIME;
	}
	public int getHSM_DECRYPT_RETRY_TIME() {
		return HSM_DECRYPT_RETRY_TIME;
	}
	public void setHSM_DECRYPT_RETRY_TIME(int hSM_DECRYPT_RETRY_TIME) {
		HSM_DECRYPT_RETRY_TIME = hSM_DECRYPT_RETRY_TIME;
	}
	public String getCONFIG_PARAMS() {
		return CONFIG_PARAMS;
	}
	public void setCONFIG_PARAMS(String cONFIG_PARAMS) {
		CONFIG_PARAMS = cONFIG_PARAMS;
	}
	public String getCONFIG_RELOAD() {
		return CONFIG_RELOAD;
	}
	public void setCONFIG_RELOAD(String cONFIG_RELOAD) {
		CONFIG_RELOAD = cONFIG_RELOAD;
	}

	
	
	  
}
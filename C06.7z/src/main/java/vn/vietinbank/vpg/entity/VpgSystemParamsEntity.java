package vn.vietinbank.vpg.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "VPG_ACH_PARAMS", schema = "VPG2")
public class VpgSystemParamsEntity implements java.io.Serializable {

	@Id
	@Column(name = "ID")
	  private long id;
	
	
	@Column(name = "CREATE_DATE")
	  private Date create_date;
	
	@Column(name = "SERVICE_CODE")
	  private String service_code;
	
	@Column(name = "IS_ACTIVE")
	  private String is_active;
	
	@Column(name = "PARAM_TYPE")
	  private String param_type;
	
	@Column(name = "PARAM_KEY")
	  private String param_key;
	
	@Column(name = "PARAM_VALUE")
	  private String param_value;
	
	@Column(name = "PARAM_DESC")
	  private String param_desc;
	
	@Column(name = "CREATE_USER")
	  private int create_user;
	
	@Column(name = "LAST_USER")
	  private int last_user;
	
	@Column(name = "LAST_DATE")
	  private Date last_date;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getCreate_date() {
		return create_date;
	}

	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}

	public String getService_code() {
		return service_code;
	}

	public void setService_code(String service_code) {
		this.service_code = service_code;
	}

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getParam_type() {
		return param_type;
	}

	public void setParam_type(String param_type) {
		this.param_type = param_type;
	}

	public String getParam_key() {
		return param_key;
	}

	public void setParam_key(String param_key) {
		this.param_key = param_key;
	}

	public String getParam_value() {
		return param_value;
	}

	public void setParam_value(String param_value) {
		this.param_value = param_value;
	}

	public String getParam_desc() {
		return param_desc;
	}

	public void setParam_desc(String param_desc) {
		this.param_desc = param_desc;
	}

	public int getCreate_user() {
		return create_user;
	}

	public void setCreate_user(int create_user) {
		this.create_user = create_user;
	}

	public int getLast_user() {
		return last_user;
	}

	public void setLast_user(int last_user) {
		this.last_user = last_user;
	}

	public Date getLast_date() {
		return last_date;
	}

	public void setLast_date(Date last_date) {
		this.last_date = last_date;
	}
	
	
	  
}
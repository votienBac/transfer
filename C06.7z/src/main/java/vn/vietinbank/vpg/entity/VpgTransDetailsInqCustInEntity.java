package vn.vietinbank.vpg.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "VPG_TRANS_DETAILS_INQ_CUST_IN", schema = "VPG2")
public class VpgTransDetailsInqCustInEntity implements java.io.Serializable {

	@Id
	private Long id;
	@Column(name = "LOG_DATE")
	private Date log_date;
	@Column(name = "LOG_ID")
	private String log_id;
	@Column(name = "HOSTINFO")
	private String hostinfo;
	@Column(name = "TRANS_DIRECT")
	private String trans_direct;
	@Column(name = "TRANS_TYPE")
	private String trans_type;
	//@Column(name = "Name", length = 255, nullable = false)
	@Column(name = "GATEWAY_ID")
	private String gateway_id;
	@Column(name = "SERVICE_CODE")
	private String service_code;
	@Column(name = "PRODUCT_CODE")
	private String product_code;
	@Column(name = "PROVIDER_ID")
	private String provider_id;
	@Column(name = "PROCESSING_CODE")
	private String processing_code;
	@Column(name = "PAYMENT_CHANNEL")
	private String payment_channel;
	
	@Column(name = "MSG_ID")
	private String msg_id;
	@Column(name = "MSG_TYPE")
	private String msg_type;
	@Column(name = "TRANS_ID")
	private String trans_id;
	
	@Column(name = "TRANS_TIME")
	private String trans_time;
	@Column(name = "SERVICE_TYPE")
	private String service_type;
	@Column(name = "PAYMENT_TYPE")
	private String payment_type;
	@Column(name = "PAYMENT_METHOD")
	private String payment_method;
	@Column(name = "CUSTOMER_CODE")
	private String customer_code;
	@Column(name = "CUSTOMER_NAME")
	private String customer_name;
	
	@Column(name = "CUSTOMER_ACCT")
	private String customer_acct;
	@Column(name = "BIRTH_DATE")
	private String birth_date;
	@Column(name = "GENDER")
	private String gender;
	@Column(name = "ID_CARD_TYPE")
	private String id_card_type;
	@Column(name = "ID_CARD")
	private String id_card;
	@Column(name = "ID_CARD_ISS_DATE")
	private String id_card_iss_date;
	@Column(name = "ID_CARD_ISS_PLACE")
	private String id_card_iss_place;
	
	@Column(name = "CUSTOMER_ADDR")
	private String customer_addr;
	@Column(name = "CUSTOMER_PHONE")
	private String customer_phone;
	@Column(name = "CUSTOMER_IDC")
	private String customer_idc;
	
	@Column(name = "CUSTOMER_STREET")
	private String customer_street;
	
	@Column(name = "AREA_CODE")
	private String area_code;
	@Column(name = "PROVINCE_CODE")
	private String province_code;
	@Column(name = "TID")
	private String tid;
	@Column(name = "ACCT_NO")
	private String acct_no;
	@Column(name = "EMAIL")
	private String email;
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "BILL_ID")
	private String bill_id;
	@Column(name = "BILL_TERM")
	private String bill_term;
	@Column(name = "BILL_DETAILS")
	private String bill_details;
	
	@Column(name = "AMOUNT")
	private String amount;
	@Column(name = "AMOUNT_MIN")
	private String amount_min;
	@Column(name = "FEE")
	private String fee;
	@Column(name = "VAT")
	private String vat;
	@Column(name = "CURRENCY_CODE")
	private String currency_code;
	
	@Column(name = "PAYMENT_ID")
	private String payment_id;

	@Column(name = "MSG_ORIGIN")
	private String msg_origin;
	@Column(name = "MSG_CONVERT")
	private String msg_convert;
	@Column(name = "MSG_SIGNED")
	private String msg_signed;
	@Column(name = "MSG_ENCRYPED")
	private String msg_encrypted;
	
	@Column(name = "ERROR_CODE")
	private String error_code;
	@Column(name = "ERROR_DESC")
	private String error_desc;
	@Column(name = "ERROR_CODE_VPG")
	private String error_code_vpg;
	@Column(name = "ERROR_DESC_VPG")
	private String error_desc_vpg;
	
	@Column(name = "STATUS_CODE")
	private String status_code;
	@Column(name = "STATUS_MESSAGE")
	private String status_message;
	
	
	@Column(name = "IS_RETRY")
	private String is_retry;
	
	@Column(name = "IS_CACHING")
	private String is_caching;
	
	@Column(name = "YEAR")
	private int year;
	@Column(name = "MONTH")
	private int month;
	@Column(name = "DAY")
	private int day;

	@Column(name = "CLIENT_ID")
	private String client_id;
	
	
	@Column(name = "SESSIONID")
	private String sessionid;
	@Column(name = "LOG_NOTE")
	private String log_note;
	
	@Column(name = "ADD_INFO")
	private String add_info;
	
	@Column(name = "PRESEVE1")
	private String preseve1;
	@Column(name = "PRESEVE2")
	private String preseve2;
	@Column(name = "PRESEVE3")
	private String preseve3;
	
	
	@Column(name = "PROCESS_TIME_DB")
	private long PROCESS_TIME_DB;
	@Column(name = "PROCESS_TIME_PRV")
	private long PROCESS_TIME_PRV;
	@Column(name = "PROCESS_TIME_CVT")
	private long PROCESS_TIME_CVT;
	@Column(name = "PROCESS_TIME")
	private long PROCESS_TIME;
	@Column(name = "PROCESS_TIME_MQ")
	private long PROCESS_TIME_MQ;
	
	
	@Override
	public String toString() {
		return "VpgTransLogOut [service_code=" + service_code + ", log_date=" + log_date + ", gateway_id=" + gateway_id
				+ ", msg_id=" + msg_id + ", customer_code=" + customer_code + "]";
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Date getLog_date() {
		return log_date;
	}


	public void setLog_date(Date log_date) {
		this.log_date = log_date;
	}


	public String getLog_id() {
		return log_id;
	}


	public void setLog_id(String log_id) {
		this.log_id = log_id;
	}


	public String getHostinfo() {
		return hostinfo;
	}


	public void setHostinfo(String hostinfo) {
		this.hostinfo = hostinfo;
	}


	public String getTrans_direct() {
		return trans_direct;
	}


	public void setTrans_direct(String trans_direct) {
		this.trans_direct = trans_direct;
	}


	public String getTrans_type() {
		return trans_type;
	}


	public void setTrans_type(String trans_type) {
		this.trans_type = trans_type;
	}


	public String getGateway_id() {
		return gateway_id;
	}


	public void setGateway_id(String gateway_id) {
		this.gateway_id = gateway_id;
	}


	public String getService_code() {
		return service_code;
	}


	public void setService_code(String service_code) {
		this.service_code = service_code;
	}


	public String getProduct_code() {
		return product_code;
	}


	public void setProduct_code(String product_code) {
		this.product_code = product_code;
	}


	public String getProvider_id() {
		return provider_id;
	}


	public void setProvider_id(String provider_id) {
		this.provider_id = provider_id;
	}


	public String getProcessing_code() {
		return processing_code;
	}


	public void setProcessing_code(String processing_code) {
		this.processing_code = processing_code;
	}


	public String getPayment_channel() {
		return payment_channel;
	}


	public void setPayment_channel(String payment_channel) {
		this.payment_channel = payment_channel;
	}


	public String getMsg_id() {
		return msg_id;
	}


	public void setMsg_id(String msg_id) {
		this.msg_id = msg_id;
	}


	public String getMsg_type() {
		return msg_type;
	}


	public void setMsg_type(String msg_type) {
		this.msg_type = msg_type;
	}


	public String getTrans_id() {
		return trans_id;
	}


	public void setTrans_id(String trans_id) {
		this.trans_id = trans_id;
	}


	public String getTrans_time() {
		return trans_time;
	}


	public void setTrans_time(String trans_time) {
		this.trans_time = trans_time;
	}


	public String getService_type() {
		return service_type;
	}


	public void setService_type(String service_type) {
		this.service_type = service_type;
	}


	public String getPayment_type() {
		return payment_type;
	}


	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}


	public String getPayment_method() {
		return payment_method;
	}


	public void setPayment_method(String payment_method) {
		this.payment_method = payment_method;
	}


	public String getCustomer_code() {
		return customer_code;
	}


	public void setCustomer_code(String customer_code) {
		this.customer_code = customer_code;
	}


	public String getCustomer_name() {
		return customer_name;
	}


	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}


	public String getCustomer_acct() {
		return customer_acct;
	}


	public void setCustomer_acct(String customer_acct) {
		this.customer_acct = customer_acct;
	}


	public String getBirth_date() {
		return birth_date;
	}


	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getId_card_type() {
		return id_card_type;
	}


	public void setId_card_type(String id_card_type) {
		this.id_card_type = id_card_type;
	}


	public String getId_card() {
		return id_card;
	}


	public void setId_card(String id_card) {
		this.id_card = id_card;
	}


	public String getId_card_iss_date() {
		return id_card_iss_date;
	}


	public void setId_card_iss_date(String id_card_iss_date) {
		this.id_card_iss_date = id_card_iss_date;
	}


	public String getId_card_iss_place() {
		return id_card_iss_place;
	}


	public void setId_card_iss_place(String id_card_iss_place) {
		this.id_card_iss_place = id_card_iss_place;
	}


	public String getCustomer_addr() {
		return customer_addr;
	}


	public void setCustomer_addr(String customer_addr) {
		this.customer_addr = customer_addr;
	}


	public String getCustomer_phone() {
		return customer_phone;
	}


	public void setCustomer_phone(String customer_phone) {
		this.customer_phone = customer_phone;
	}


	public String getCustomer_idc() {
		return customer_idc;
	}


	public void setCustomer_idc(String customer_idc) {
		this.customer_idc = customer_idc;
	}


	public String getCustomer_street() {
		return customer_street;
	}


	public void setCustomer_street(String customer_street) {
		this.customer_street = customer_street;
	}


	public String getArea_code() {
		return area_code;
	}


	public void setArea_code(String area_code) {
		this.area_code = area_code;
	}


	public String getProvince_code() {
		return province_code;
	}


	public void setProvince_code(String province_code) {
		this.province_code = province_code;
	}


	public String getTid() {
		return tid;
	}


	public void setTid(String tid) {
		this.tid = tid;
	}


	public String getAcct_no() {
		return acct_no;
	}


	public void setAcct_no(String acct_no) {
		this.acct_no = acct_no;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getBill_id() {
		return bill_id;
	}


	public void setBill_id(String bill_id) {
		this.bill_id = bill_id;
	}


	public String getBill_term() {
		return bill_term;
	}


	public void setBill_term(String bill_term) {
		this.bill_term = bill_term;
	}


	public String getBill_details() {
		return bill_details;
	}


	public void setBill_details(String bill_details) {
		this.bill_details = bill_details;
	}


	public String getAmount() {
		return amount;
	}


	public void setAmount(String amount) {
		this.amount = amount;
	}


	public String getAmount_min() {
		return amount_min;
	}


	public void setAmount_min(String amount_min) {
		this.amount_min = amount_min;
	}


	public String getFee() {
		return fee;
	}


	public void setFee(String fee) {
		this.fee = fee;
	}


	public String getVat() {
		return vat;
	}


	public void setVat(String vat) {
		this.vat = vat;
	}


	public String getCurrency_code() {
		return currency_code;
	}


	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}


	public String getPayment_id() {
		return payment_id;
	}


	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}


	public String getMsg_origin() {
		return msg_origin;
	}


	public void setMsg_origin(String msg_origin) {
		this.msg_origin = msg_origin;
	}


	public String getMsg_convert() {
		return msg_convert;
	}


	public void setMsg_convert(String msg_convert) {
		this.msg_convert = msg_convert;
	}


	public String getMsg_signed() {
		return msg_signed;
	}


	public void setMsg_signed(String msg_signed) {
		this.msg_signed = msg_signed;
	}


	public String getMsg_encrypted() {
		return msg_encrypted;
	}


	public void setMsg_encrypted(String msg_encrypted) {
		this.msg_encrypted = msg_encrypted;
	}


	public String getError_code() {
		return error_code;
	}


	public void setError_code(String error_code) {
		this.error_code = error_code;
	}


	public String getError_desc() {
		return error_desc;
	}


	public void setError_desc(String error_desc) {
		this.error_desc = error_desc;
	}


	public String getError_code_vpg() {
		return error_code_vpg;
	}


	public void setError_code_vpg(String error_code_vpg) {
		this.error_code_vpg = error_code_vpg;
	}


	public String getError_desc_vpg() {
		return error_desc_vpg;
	}


	public void setError_desc_vpg(String error_desc_vpg) {
		this.error_desc_vpg = error_desc_vpg;
	}


	public String getStatus_code() {
		return status_code;
	}


	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}


	public String getStatus_message() {
		return status_message;
	}


	public void setStatus_message(String status_message) {
		this.status_message = status_message;
	}


	public String getIs_retry() {
		return is_retry;
	}


	public void setIs_retry(String is_retry) {
		this.is_retry = is_retry;
	}


	public String getIs_caching() {
		return is_caching;
	}


	public void setIs_caching(String is_caching) {
		this.is_caching = is_caching;
	}


	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}


	public int getMonth() {
		return month;
	}


	public void setMonth(int month) {
		this.month = month;
	}


	public int getDay() {
		return day;
	}


	public void setDay(int day) {
		this.day = day;
	}


	public String getClient_id() {
		return client_id;
	}


	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}


	public String getSessionid() {
		return sessionid;
	}


	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}


	public String getLog_note() {
		return log_note;
	}


	public void setLog_note(String log_note) {
		this.log_note = log_note;
	}


	public String getAdd_info() {
		return add_info;
	}


	public void setAdd_info(String add_info) {
		this.add_info = add_info;
	}


	public String getPreseve1() {
		return preseve1;
	}


	public void setPreseve1(String preseve1) {
		this.preseve1 = preseve1;
	}


	public String getPreseve2() {
		return preseve2;
	}


	public void setPreseve2(String preseve2) {
		this.preseve2 = preseve2;
	}


	public String getPreseve3() {
		return preseve3;
	}


	public void setPreseve3(String preseve3) {
		this.preseve3 = preseve3;
	}


	public long getPROCESS_TIME_DB() {
		return PROCESS_TIME_DB;
	}


	public void setPROCESS_TIME_DB(long pROCESS_TIME_DB) {
		PROCESS_TIME_DB = pROCESS_TIME_DB;
	}


	public long getPROCESS_TIME_PRV() {
		return PROCESS_TIME_PRV;
	}


	public void setPROCESS_TIME_PRV(long pROCESS_TIME_PRV) {
		PROCESS_TIME_PRV = pROCESS_TIME_PRV;
	}


	public long getPROCESS_TIME_CVT() {
		return PROCESS_TIME_CVT;
	}


	public void setPROCESS_TIME_CVT(long pROCESS_TIME_CVT) {
		PROCESS_TIME_CVT = pROCESS_TIME_CVT;
	}


	public long getPROCESS_TIME() {
		return PROCESS_TIME;
	}


	public void setPROCESS_TIME(long pROCESS_TIME) {
		PROCESS_TIME = pROCESS_TIME;
	}


	public long getPROCESS_TIME_MQ() {
		return PROCESS_TIME_MQ;
	}


	public void setPROCESS_TIME_MQ(long pROCESS_TIME_MQ) {
		PROCESS_TIME_MQ = pROCESS_TIME_MQ;
	}


	


}
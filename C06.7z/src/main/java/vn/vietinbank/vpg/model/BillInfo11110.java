
package vn.vietinbank.vpg.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "custCode",
    "custName",
    "custAddr",
    "custPhone",
    "custEmail",
    "custAcct",
    "bankCode",
    "branchCode",
    "billId",
    "billTerm",
    "amount",
    "amountMin",
    "fee",
    "currencyCode",
    "outPayDate",
    "expireDate",
    "paymentType",
    "priceList",
    "quota",
    "consume",
    "idxStart",
    "idxEnd",
    "vat",
    "raCode",
    "raName",
    "provinceCode",
    "provinceName",
    "areaCode",
    "areaName",
    "taxCode",
    "addinfo"
})
public class BillInfo11110 {

    @JsonProperty("custCode")
    private String custCode;
    @JsonProperty("custName")
    private String custName;
    @JsonProperty("custAddr")
    private String custAddr;
    @JsonProperty("custPhone")
    private String custPhone;
    @JsonProperty("custEmail")
    private String custEmail;
    @JsonProperty("custAcct")
    private String custAcct;
    @JsonProperty("bankCode")
    private String bankCode;
    @JsonProperty("branchCode")
    private String branchCode;
    @JsonProperty("billId")
    private String billId;
    @JsonProperty("billTerm")
    private String billTerm;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("amountMin")
    private String amountMin;
    @JsonProperty("fee")
    private String fee;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("outPayDate")
    private String outPayDate;
    @JsonProperty("expireDate")
    private String expireDate;
    @JsonProperty("paymentType")
    private String paymentType;
    @JsonProperty("priceList")
    private String priceList;
    @JsonProperty("quota")
    private String quota;
    @JsonProperty("consume")
    private String consume;
    @JsonProperty("idxStart")
    private String idxStart;
    @JsonProperty("idxEnd")
    private String idxEnd;
    @JsonProperty("vat")
    private String vat;
    @JsonProperty("raCode")
    private String raCode;
    @JsonProperty("raName")
    private String raName;
    @JsonProperty("provinceCode")
    private String provinceCode;
    @JsonProperty("provinceName")
    private String provinceName;
    @JsonProperty("areaCode")
    private String areaCode;
    @JsonProperty("areaName")
    private String areaName;
    @JsonProperty("taxCode")
    private String taxCode;
    @JsonProperty("addinfo")
    private Object addinfo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("custCode")
    public String getCustCode() {
        return custCode;
    }

    @JsonProperty("custCode")
    public void setCustCode(String custCode) {
        this.custCode = custCode;
    }

    @JsonProperty("custName")
    public String getCustName() {
        return custName;
    }

    @JsonProperty("custName")
    public void setCustName(String custName) {
        this.custName = custName;
    }

    @JsonProperty("custAddr")
    public String getCustAddr() {
        return custAddr;
    }

    @JsonProperty("custAddr")
    public void setCustAddr(String custAddr) {
        this.custAddr = custAddr;
    }

    @JsonProperty("custPhone")
    public String getCustPhone() {
        return custPhone;
    }

    @JsonProperty("custPhone")
    public void setCustPhone(String custPhone) {
        this.custPhone = custPhone;
    }

    @JsonProperty("custEmail")
    public String getCustEmail() {
        return custEmail;
    }

    @JsonProperty("custEmail")
    public void setCustEmail(String custEmail) {
        this.custEmail = custEmail;
    }

    @JsonProperty("custAcct")
    public String getCustAcct() {
        return custAcct;
    }

    @JsonProperty("custAcct")
    public void setCustAcct(String custAcct) {
        this.custAcct = custAcct;
    }

    @JsonProperty("bankCode")
    public String getBankCode() {
        return bankCode;
    }

    @JsonProperty("bankCode")
    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    @JsonProperty("branchCode")
    public String getBranchCode() {
        return branchCode;
    }

    @JsonProperty("branchCode")
    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    @JsonProperty("billId")
    public String getBillId() {
        return billId;
    }

    @JsonProperty("billId")
    public void setBillId(String billId) {
        this.billId = billId;
    }

    @JsonProperty("billTerm")
    public String getBillTerm() {
        return billTerm;
    }

    @JsonProperty("billTerm")
    public void setBillTerm(String billTerm) {
        this.billTerm = billTerm;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @JsonProperty("amountMin")
    public String getAmountMin() {
        return amountMin;
    }

    @JsonProperty("amountMin")
    public void setAmountMin(String amountMin) {
        this.amountMin = amountMin;
    }

    @JsonProperty("fee")
    public String getFee() {
        return fee;
    }

    @JsonProperty("fee")
    public void setFee(String fee) {
        this.fee = fee;
    }

    @JsonProperty("currencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("currencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    @JsonProperty("outPayDate")
    public String getOutPayDate() {
        return outPayDate;
    }

    @JsonProperty("outPayDate")
    public void setOutPayDate(String outPayDate) {
        this.outPayDate = outPayDate;
    }

    @JsonProperty("expireDate")
    public String getExpireDate() {
        return expireDate;
    }

    @JsonProperty("expireDate")
    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    @JsonProperty("paymentType")
    public String getPaymentType() {
        return paymentType;
    }

    @JsonProperty("paymentType")
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @JsonProperty("priceList")
    public String getPriceList() {
        return priceList;
    }

    @JsonProperty("priceList")
    public void setPriceList(String priceList) {
        this.priceList = priceList;
    }

    @JsonProperty("quota")
    public String getQuota() {
        return quota;
    }

    @JsonProperty("quota")
    public void setQuota(String quota) {
        this.quota = quota;
    }

    @JsonProperty("consume")
    public String getConsume() {
        return consume;
    }

    @JsonProperty("consume")
    public void setConsume(String consume) {
        this.consume = consume;
    }

    @JsonProperty("idxStart")
    public String getIdxStart() {
        return idxStart;
    }

    @JsonProperty("idxStart")
    public void setIdxStart(String idxStart) {
        this.idxStart = idxStart;
    }

    @JsonProperty("idxEnd")
    public String getIdxEnd() {
        return idxEnd;
    }

    @JsonProperty("idxEnd")
    public void setIdxEnd(String idxEnd) {
        this.idxEnd = idxEnd;
    }

    @JsonProperty("vat")
    public String getVat() {
        return vat;
    }

    @JsonProperty("vat")
    public void setVat(String vat) {
        this.vat = vat;
    }

    @JsonProperty("raCode")
    public String getRaCode() {
        return raCode;
    }

    @JsonProperty("raCode")
    public void setRaCode(String raCode) {
        this.raCode = raCode;
    }

    @JsonProperty("raName")
    public String getRaName() {
        return raName;
    }

    @JsonProperty("raName")
    public void setRaName(String raName) {
        this.raName = raName;
    }

    @JsonProperty("provinceCode")
    public String getProvinceCode() {
        return provinceCode;
    }

    @JsonProperty("provinceCode")
    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    @JsonProperty("provinceName")
    public String getProvinceName() {
        return provinceName;
    }

    @JsonProperty("provinceName")
    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    @JsonProperty("areaCode")
    public String getAreaCode() {
        return areaCode;
    }

    @JsonProperty("areaCode")
    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    @JsonProperty("areaName")
    public String getAreaName() {
        return areaName;
    }

    @JsonProperty("areaName")
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    @JsonProperty("taxCode")
    public String getTaxCode() {
        return taxCode;
    }

    @JsonProperty("taxCode")
    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    @JsonProperty("addinfo")
    public Object getAddinfo() {
        return addinfo;
    }

    @JsonProperty("addinfo")
    public void setAddinfo(Object addinfo) {
        this.addinfo = addinfo;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

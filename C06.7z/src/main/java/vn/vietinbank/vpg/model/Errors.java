
package vn.vietinbank.vpg.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "errorCode",
    "errorDesc",
    "errorCodeVPG",
    "errorDescVPG"
})
public class Errors {

    @JsonProperty("errorCode")
    private String errorCode;
    @JsonProperty("errorDesc")
    private String errorDesc;
    @JsonProperty("errorCodeVPG")
    private String errorCodeVPG;
    @JsonProperty("errorDescVPG")
    private String errorDescVPG;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("errorCode")
    public String getErrorCode() {
        return errorCode;
    }

    @JsonProperty("errorCode")
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    @JsonProperty("errorDesc")
    public String getErrorDesc() {
        return errorDesc;
    }

    @JsonProperty("errorDesc")
    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }

    @JsonProperty("errorCodeVPG")
    public String getErrorCodeVPG() {
        return errorCodeVPG;
    }

    @JsonProperty("errorCodeVPG")
    public void setErrorCodeVPG(String errorCodeVPG) {
        this.errorCodeVPG = errorCodeVPG;
    }

    @JsonProperty("errorDescVPG")
    public String getErrorDescVPG() {
        return errorDescVPG;
    }

    @JsonProperty("errorDescVPG")
    public void setErrorDescVPG(String errorDescVPG) {
        this.errorDescVPG = errorDescVPG;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

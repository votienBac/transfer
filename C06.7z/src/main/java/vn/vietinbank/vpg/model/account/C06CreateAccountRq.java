package vn.vietinbank.vpg.model.account;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"hoTenCongDan",
"ngayThangNamSinh",
"noiSinh",
"gioiTinh",
"quocTich",
"soDinhDanh",
"ngayCap",
"noiCap",
"soDienThoai",
"diaChiThuongTru",
"maThuongTruTinh",
"maThuongTruHuyen",
"maNoiOHienTaiTinh",
"maNoiOHienTaiHuyen",
"noiOHienTai",
"soCMND",
"diaChiGiaoDich",
"maDiaDiem",
"anhChanDung",
"maGiaoDich"
})
@Generated("jsonschema2pojo")
public class C06CreateAccountRq {

@JsonProperty("hoTenCongDan")
private String hoTenCongDan;
@JsonProperty("ngayThangNamSinh")
private String ngayThangNamSinh;
@JsonProperty("noiSinh")
private String noiSinh;
@JsonProperty("gioiTinh")
private String gioiTinh;
@JsonProperty("quocTich")
private String quocTich;
@JsonProperty("soDinhDanh")
private String soDinhDanh;
@JsonProperty("ngayCap")
private String ngayCap;
@JsonProperty("noiCap")
private String noiCap;
@JsonProperty("soDienThoai")
private String soDienThoai;
@JsonProperty("diaChiThuongTru")
private String diaChiThuongTru;
@JsonProperty("maThuongTruTinh")
private String maThuongTruTinh;
@JsonProperty("maThuongTruHuyen")
private String maThuongTruHuyen;
@JsonProperty("maNoiOHienTaiTinh")
private String maNoiOHienTaiTinh;
@JsonProperty("maNoiOHienTaiHuyen")
private String maNoiOHienTaiHuyen;
@JsonProperty("noiOHienTai")
private String noiOHienTai;
@JsonProperty("soCMND")
private String soCMND;
@JsonProperty("diaChiGiaoDich")
private String diaChiGiaoDich;
@JsonProperty("maDiaDiem")
private String maDiaDiem;
@JsonProperty("anhChanDung")
private String anhChanDung;
@JsonProperty("maGiaoDich")
private String maGiaoDich;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("hoTenCongDan")
public String getHoTenCongDan() {
return hoTenCongDan;
}

@JsonProperty("hoTenCongDan")
public void setHotenCongDan(String hoTenCongDan) {
this.hoTenCongDan = hoTenCongDan;
}

@JsonProperty("ngayThangNamSinh")
public String getNgayThangNamSinh() {
return ngayThangNamSinh;
}

@JsonProperty("ngayThangNamSinh")
public void setNgayThangNamSinh(String ngayThangNamSinh) {
this.ngayThangNamSinh = ngayThangNamSinh;
}

@JsonProperty("noiSinh")
public String getNoiSinh() {
return noiSinh;
}

@JsonProperty("noiSinh")
public void setNoiSinh(String noiSinh) {
this.noiSinh = noiSinh;
}

@JsonProperty("gioiTinh")
public String getGioiTinh() {
return gioiTinh;
}

@JsonProperty("gioiTinh")
public void setGioiTinh(String gioiTinh) {
this.gioiTinh = gioiTinh;
}

@JsonProperty("quocTich")
public String getQuocTich() {
return quocTich;
}

@JsonProperty("quocTich")
public void setQuocTich(String quocTich) {
this.quocTich = quocTich;
}

@JsonProperty("soDinhDanh")
public String getSoDinhDanh() {
return soDinhDanh;
}

@JsonProperty("soDinhDanh")
public void setSoDinhDanh(String soDinhDanh) {
this.soDinhDanh = soDinhDanh;
}

@JsonProperty("ngayCap")
public String getNgayCap() {
return ngayCap;
}

@JsonProperty("ngayCap")
public void setNgayCap(String ngayCap) {
this.ngayCap = ngayCap;
}

@JsonProperty("noiCap")
public String getNoiCap() {
return noiCap;
}

@JsonProperty("noiCap")
public void setNoiCap(String noiCap) {
this.noiCap = noiCap;
}

@JsonProperty("soDienThoai")
public String getSoDienThoai() {
return soDienThoai;
}

@JsonProperty("soDienThoai")
public void setSoDienThoai(String soDienThoai) {
this.soDienThoai = soDienThoai;
}

@JsonProperty("diaChiThuongTru")
public String getDiaChiThuongTru() {
return diaChiThuongTru;
}

@JsonProperty("diaChiThuongTru")
public void setDiaChiThuongTru(String diaChiThuongTru) {
this.diaChiThuongTru = diaChiThuongTru;
}

@JsonProperty("maThuongTruTinh")
public String getMaThuongTruTinh() {
return maThuongTruTinh;
}

@JsonProperty("maThuongTruTinh")
public void setMaThuongTruTinh(String maThuongTruTinh) {
this.maThuongTruTinh = maThuongTruTinh;
}

@JsonProperty("maThuongTruHuyen")
public String getMaThuongTruHuyen() {
return maThuongTruHuyen;
}

@JsonProperty("maThuongTruHuyen")
public void setMaThuongTruHuyen(String maThuongTruHuyen) {
this.maThuongTruHuyen = maThuongTruHuyen;
}

@JsonProperty("maNoiOHienTaiTinh")
public String getMaNoiOHienTaiTinh() {
return maNoiOHienTaiTinh;
}

@JsonProperty("maNoiOHienTaiTinh")
public void setMaNoiOHienTaiTinh(String maNoiOHienTaiTinh) {
this.maNoiOHienTaiTinh = maNoiOHienTaiTinh;
}

@JsonProperty("maNoiOHienTaiHuyen")
public String getMaNoiOHienTaiHuyen() {
return maNoiOHienTaiHuyen;
}

@JsonProperty("maNoiOHienTaiHuyen")
public void setMaNoiOHienTaiHuyen(String maNoiOHienTaiHuyen) {
this.maNoiOHienTaiHuyen = maNoiOHienTaiHuyen;
}

@JsonProperty("noiOHienTai")
public String getNoiOHienTai() {
return noiOHienTai;
}

@JsonProperty("noiOHienTai")
public void setNoiOHienTai(String noiOHienTai) {
this.noiOHienTai = noiOHienTai;
}

@JsonProperty("soCMND")
public String getSoCMND() {
return soCMND;
}

@JsonProperty("soCMND")
public void setSoCMND(String soCMND) {
this.soCMND = soCMND;
}

@JsonProperty("diaChiGiaoDich")
public String getDiaChiGiaoDich() {
return diaChiGiaoDich;
}

@JsonProperty("diaChiGiaoDich")
public void setDiaChiGiaoDich(String diaChiGiaoDich) {
this.diaChiGiaoDich = diaChiGiaoDich;
}

@JsonProperty("maDiaDiem")
public String getMaDiaDiem() {
return maDiaDiem;
}

@JsonProperty("maDiaDiem")
public void setMaDiaDiem(String maDiaDiem) {
this.maDiaDiem = maDiaDiem;
}

@JsonProperty("anhChanDung")
public String getAnhChanDung() {
return anhChanDung;
}

@JsonProperty("anhChanDung")
public void setAnhChanDung(String anhChanDung) {
this.anhChanDung = anhChanDung;
}

@JsonProperty("maGiaoDich")
public String getMaGiaoDich() {
return maGiaoDich;
}

@JsonProperty("maGiaoDich")
public void setMaGiaoDich(String maGiaoDich) {
this.maGiaoDich = maGiaoDich;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
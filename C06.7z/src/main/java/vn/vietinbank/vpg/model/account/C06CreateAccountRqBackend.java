package vn.vietinbank.vpg.model.account;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"maGiaoDich",
"providerId",
"merchantId",
"channel",
"version",
"language",
"clientIP",
"signature",
"mac",
"ngaygioGiaoDich",
"hoTenCongDan",
"ngayThangNamSinh",
"noiSinh",
"gioiTinh",
"quocTich",
"soDinhDanh",
"ngayCap",
"noiCap",
"soDienThoai",
"diaChiThuongTru",
"maThuongTruTinh",
"maThuongTruHuyen",
"noiOHienTai",
"maNoiOHienTaiTinh",
"maNoiOHienTaiHuyen",
"soCMND",
"diaChiGiaoDich",
"maDiaDiem",
"anhChanDung",
"ngayHetHan",
"email"
})
@Generated("jsonschema2pojo")
public class C06CreateAccountRqBackend {

@JsonProperty("maGiaoDich")
private String maGiaoDich;
@JsonProperty("providerId")
private String providerId;
@JsonProperty("merchantId")
private String merchantId;
@JsonProperty("channel")
private String channel;
@JsonProperty("version")
private String version;
@JsonProperty("language")
private String language;
@JsonProperty("clientIP")
private String clientIP;
@JsonProperty("signature")
private String signature;
@JsonProperty("mac")
private String mac;
@JsonProperty("ngaygioGiaoDich")
private String ngaygioGiaoDich;
@JsonProperty("hoTenCongDan")
private String hoTenCongDan;
@JsonProperty("ngayThangNamSinh")
private String ngayThangNamSinh;
@JsonProperty("noiSinh")
private String noiSinh;
@JsonProperty("gioiTinh")
private String gioiTinh;
@JsonProperty("quocTich")
private String quocTich;
@JsonProperty("soDinhDanh")
private String soDinhDanh;
@JsonProperty("ngayCap")
private String ngayCap;
@JsonProperty("noiCap")
private Object noiCap;
@JsonProperty("soDienThoai")
private String soDienThoai;
@JsonProperty("diaChiThuongTru")
private String diaChiThuongTru;
@JsonProperty("maThuongTruTinh")
private String maThuongTruTinh;
@JsonProperty("maThuongTruHuyen")
private String maThuongTruHuyen;
@JsonProperty("noiOHienTai")
private String noiOHienTai;
@JsonProperty("maNoiOHienTaiTinh")
private String maNoiOHienTaiTinh;
@JsonProperty("maNoiOHienTaiHuyen")
private String maNoiOHienTaiHuyen;
@JsonProperty("soCMND")
private Object soCMND;
@JsonProperty("diaChiGiaoDich")
private Object diaChiGiaoDich;
@JsonProperty("maDiaDiem")
private Object maDiaDiem;
@JsonProperty("anhChanDung")
private Object anhChanDung;
@JsonProperty("ngayHetHan")
private Object ngayHetHan;
@JsonProperty("email")
private Object email;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("maGiaoDich")
public String getMaGiaoDich() {
return maGiaoDich;
}

@JsonProperty("maGiaoDich")
public void setMaGiaoDich(String maGiaoDich) {
this.maGiaoDich = maGiaoDich;
}

@JsonProperty("providerId")
public String getProviderId() {
return providerId;
}

@JsonProperty("providerId")
public void setProviderId(String providerId) {
this.providerId = providerId;
}

@JsonProperty("merchantId")
public String getMerchantId() {
return merchantId;
}

@JsonProperty("merchantId")
public void setMerchantId(String merchantId) {
this.merchantId = merchantId;
}

@JsonProperty("channel")
public String getChannel() {
return channel;
}

@JsonProperty("channel")
public void setChannel(String channel) {
this.channel = channel;
}

@JsonProperty("version")
public String getVersion() {
return version;
}

@JsonProperty("version")
public void setVersion(String version) {
this.version = version;
}

@JsonProperty("language")
public String getLanguage() {
return language;
}

@JsonProperty("language")
public void setLanguage(String language) {
this.language = language;
}

@JsonProperty("clientIP")
public String getClientIP() {
return clientIP;
}

@JsonProperty("clientIP")
public void setClientIP(String clientIP) {
this.clientIP = clientIP;
}

@JsonProperty("signature")
public String getSignature() {
return signature;
}

@JsonProperty("signature")
public void setSignature(String signature) {
this.signature = signature;
}

@JsonProperty("mac")
public String getMac() {
return mac;
}

@JsonProperty("mac")
public void setMac(String mac) {
this.mac = mac;
}

@JsonProperty("ngaygioGiaoDich")
public String getNgaygioGiaoDich() {
return ngaygioGiaoDich;
}

@JsonProperty("ngaygioGiaoDich")
public void setNgaygioGiaoDich(String ngaygioGiaoDich) {
this.ngaygioGiaoDich = ngaygioGiaoDich;
}

@JsonProperty("hoTenCongDan")
public String getHoTenCongDan() {
return hoTenCongDan;
}

@JsonProperty("hoTenCongDan")
public void setHoTenCongDan(String hoTenCongDan) {
this.hoTenCongDan = hoTenCongDan;
}

@JsonProperty("ngayThangNamSinh")
public String getNgayThangNamSinh() {
return ngayThangNamSinh;
}

@JsonProperty("ngayThangNamSinh")
public void setNgayThangNamSinh(String ngayThangNamSinh) {
this.ngayThangNamSinh = ngayThangNamSinh;
}

@JsonProperty("noiSinh")
public String getNoiSinh() {
return noiSinh;
}

@JsonProperty("noiSinh")
public void setNoiSinh(String noiSinh) {
this.noiSinh = noiSinh;
}

@JsonProperty("gioiTinh")
public String getGioiTinh() {
return gioiTinh;
}

@JsonProperty("gioiTinh")
public void setGioiTinh(String gioiTinh) {
this.gioiTinh = gioiTinh;
}

@JsonProperty("quocTich")
public String getQuocTich() {
return quocTich;
}

@JsonProperty("quocTich")
public void setQuocTich(String quocTich) {
this.quocTich = quocTich;
}

@JsonProperty("soDinhDanh")
public String getSoDinhDanh() {
return soDinhDanh;
}

@JsonProperty("soDinhDanh")
public void setSoDinhDanh(String soDinhDanh) {
this.soDinhDanh = soDinhDanh;
}

@JsonProperty("ngayCap")
public String getNgayCap() {
return ngayCap;
}

@JsonProperty("ngayCap")
public void setNgayCap(String ngayCap) {
this.ngayCap = ngayCap;
}

@JsonProperty("noiCap")
public Object getNoiCap() {
return noiCap;
}

@JsonProperty("noiCap")
public void setNoiCap(Object noiCap) {
this.noiCap = noiCap;
}

@JsonProperty("soDienThoai")
public String getSoDienThoai() {
return soDienThoai;
}

@JsonProperty("soDienThoai")
public void setSoDienThoai(String soDienThoai) {
this.soDienThoai = soDienThoai;
}

@JsonProperty("diaChiThuongTru")
public String getDiaChiThuongTru() {
return diaChiThuongTru;
}

@JsonProperty("diaChiThuongTru")
public void setDiaChiThuongTru(String diaChiThuongTru) {
this.diaChiThuongTru = diaChiThuongTru;
}

@JsonProperty("maThuongTruTinh")
public String getMaThuongTruTinh() {
return maThuongTruTinh;
}

@JsonProperty("maThuongTruTinh")
public void setMaThuongTruTinh(String maThuongTruTinh) {
this.maThuongTruTinh = maThuongTruTinh;
}

@JsonProperty("maThuongTruHuyen")
public String getMaThuongTruHuyen() {
return maThuongTruHuyen;
}

@JsonProperty("maThuongTruHuyen")
public void setMaThuongTruHuyen(String maThuongTruHuyen) {
this.maThuongTruHuyen = maThuongTruHuyen;
}

@JsonProperty("noiOHienTai")
public String getNoiOHienTai() {
return noiOHienTai;
}

@JsonProperty("noiOHienTai")
public void setNoiOHienTai(String noiOHienTai) {
this.noiOHienTai = noiOHienTai;
}

@JsonProperty("maNoiOHienTaiTinh")
public String getMaNoiOHienTaiTinh() {
return maNoiOHienTaiTinh;
}

@JsonProperty("maNoiOHienTaiTinh")
public void setMaNoiOHienTaiTinh(String maNoiOHienTaiTinh) {
this.maNoiOHienTaiTinh = maNoiOHienTaiTinh;
}

@JsonProperty("maNoiOHienTaiHuyen")
public String getMaNoiOHienTaiHuyen() {
return maNoiOHienTaiHuyen;
}

@JsonProperty("maNoiOHienTaiHuyen")
public void setMaNoiOHienTaiHuyen(String maNoiOHienTaiHuyen) {
this.maNoiOHienTaiHuyen = maNoiOHienTaiHuyen;
}

@JsonProperty("soCMND")
public Object getSoCMND() {
return soCMND;
}

@JsonProperty("soCMND")
public void setSoCMND(Object soCMND) {
this.soCMND = soCMND;
}

@JsonProperty("diaChiGiaoDich")
public Object getDiaChiGiaoDich() {
return diaChiGiaoDich;
}

@JsonProperty("diaChiGiaoDich")
public void setDiaChiGiaoDich(Object diaChiGiaoDich) {
this.diaChiGiaoDich = diaChiGiaoDich;
}

@JsonProperty("maDiaDiem")
public Object getMaDiaDiem() {
return maDiaDiem;
}

@JsonProperty("maDiaDiem")
public void setMaDiaDiem(Object maDiaDiem) {
this.maDiaDiem = maDiaDiem;
}

@JsonProperty("anhChanDung")
public Object getAnhChanDung() {
return anhChanDung;
}

@JsonProperty("anhChanDung")
public void setAnhChanDung(Object anhChanDung) {
this.anhChanDung = anhChanDung;
}

@JsonProperty("ngayHetHan")
public Object getNgayHetHan() {
return ngayHetHan;
}

@JsonProperty("ngayHetHan")
public void setNgayHetHan(Object ngayHetHan) {
this.ngayHetHan = ngayHetHan;
}

@JsonProperty("email")
public Object getEmail() {
return email;
}

@JsonProperty("email")
public void setEmail(Object email) {
this.email = email;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}


package vn.vietinbank.vpg.model.account;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"trangThai",
"moTaLoi"
})
@Generated("jsonschema2pojo")
public class C06CreateAccountRs {

@JsonProperty("trangThai")
private String trangThai;
@JsonProperty("moTaLoi")
private String moTaLoi;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("trangThai")
public String getTrangThai() {
return trangThai;
}

@JsonProperty("trangThai")
public void setTrangThai(String trangThai) {
this.trangThai = trangThai;
}

@JsonProperty("moTaLoi")
public String getMoTaLoi() {
return moTaLoi;
}

@JsonProperty("moTaLoi")
public void setMoTaLoi(String moTaLoi) {
this.moTaLoi = moTaLoi;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
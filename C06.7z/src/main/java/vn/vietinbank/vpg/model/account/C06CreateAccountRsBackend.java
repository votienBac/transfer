package vn.vietinbank.vpg.model.account;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import vn.vietinbank.vpg.model.Status;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"providerId",
"merchantId",
"maGiaoDich",
"signature",
"status",
"trangThai",
"moTaLoi"
})
@Generated("jsonschema2pojo")
public class C06CreateAccountRsBackend {

@JsonProperty("providerId")
private String providerId;
@JsonProperty("merchantId")
private String merchantId;
@JsonProperty("maGiaoDich")
private String maGiaoDich;
@JsonProperty("signature")
private String signature;
@JsonProperty("status")
private Status status;
@JsonProperty("trangThai")
private String trangThai;
@JsonProperty("moTaLoi")
private String moTaLoi;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("providerId")
public String getProviderId() {
return providerId;
}

@JsonProperty("providerId")
public void setProviderId(String providerId) {
this.providerId = providerId;
}

@JsonProperty("merchantId")
public String getMerchantId() {
return merchantId;
}

@JsonProperty("merchantId")
public void setMerchantId(String merchantId) {
this.merchantId = merchantId;
}

@JsonProperty("maGiaoDich")
public String getMaGiaoDich() {
return maGiaoDich;
}

@JsonProperty("maGiaoDich")
public void setMaGiaoDich(String maGiaoDich) {
this.maGiaoDich = maGiaoDich;
}

@JsonProperty("signature")
public String getSignature() {
return signature;
}

@JsonProperty("signature")
public void setSignature(String signature) {
this.signature = signature;
}

@JsonProperty("status")
public Status getStatus() {
return status;
}

@JsonProperty("status")
public void setStatus(Status status) {
this.status = status;
}

@JsonProperty("trangThai")
public String getTrangThai() {
return trangThai;
}

@JsonProperty("trangThai")
public void setTrangThai(String trangThai) {
this.trangThai = trangThai;
}

@JsonProperty("moTaLoi")
public String getMoTaLoi() {
return moTaLoi;
}

@JsonProperty("moTaLoi")
public void setMoTaLoi(String moTaLoi) {
this.moTaLoi = moTaLoi;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
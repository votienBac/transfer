package vn.vietinbank.vpg.model.account;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ngayXacThuc",
"maGiaoDich",
"diemTrungKhop",
"trangThai",
"ngayGioGiaoDich",
"eidTxnCode",
"moTaLoi"
})
@Generated("jsonschema2pojo")
public class C06KetQuaXacNhanARq {

@JsonProperty("ngayXacThuc")
private String ngayXacThuc;
@JsonProperty("maGiaoDich")
private String maGiaoDich;
@JsonProperty("diemTrungKhop")
private Double diemTrungKhop;
@JsonProperty("trangThai")
private Integer trangThai;
@JsonProperty("ngayGioGiaoDich")
private Long ngayGioGiaoDich;
@JsonProperty("eidTxnCode")
private String eidTxnCode;
@JsonProperty("moTaLoi")
private String moTaLoi;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("ngayXacThuc")
public String getNgayXacThuc() {
return ngayXacThuc;
}

@JsonProperty("ngayXacThuc")
public void setNgayXacThuc(String ngayXacThuc) {
this.ngayXacThuc = ngayXacThuc;
}

@JsonProperty("maGiaoDich")
public String getMaGiaoDich() {
return maGiaoDich;
}

@JsonProperty("maGiaoDich")
public void setMaGiaoDich(String maGiaoDich) {
this.maGiaoDich = maGiaoDich;
}

@JsonProperty("diemTrungKhop")
public Double getDiemTrungKhop() {
return diemTrungKhop;
}

@JsonProperty("diemTrungKhop")
public void setDiemTrungKhop(Double diemTrungKhop) {
this.diemTrungKhop = diemTrungKhop;
}

@JsonProperty("trangThai")
public Integer getTrangThai() {
return trangThai;
}

@JsonProperty("trangThai")
public void setTrangThai(Integer trangThai) {
this.trangThai = trangThai;
}

@JsonProperty("ngayGioGiaoDich")
public Long getNgayGioGiaoDich() {
return ngayGioGiaoDich;
}

@JsonProperty("ngayGioGiaoDich")
public void setNgayGioGiaoDich(Long ngayGioGiaoDich) {
this.ngayGioGiaoDich = ngayGioGiaoDich;
}

@JsonProperty("eidTxnCode")
public String getEidTxnCode() {
return eidTxnCode;
}

@JsonProperty("eidTxnCode")
public void setEidTxnCode(String eidTxnCode) {
this.eidTxnCode = eidTxnCode;
}

@JsonProperty("moTaLoi")
public String getMoTaLoi() {
return moTaLoi;
}

@JsonProperty("moTaLoi")
public void setMoTaLoi(String moTaLoi) {
this.moTaLoi = moTaLoi;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
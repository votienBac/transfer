package vn.vietinbank.vpg.model.account;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import vn.vietinbank.vpg.model.Status;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"providerId",
"merchantId",
"transId",
"maGiaoDich",
"signature",
"status",
"trangThai",
"moTaLoi",
"ketQuaDoiSanh"
})
@Generated("jsonschema2pojo")
public class C06KetQuaXacNhanRsBackend {

@JsonProperty("providerId")
private String providerId;
@JsonProperty("merchantId")
private String merchantId;
@JsonProperty("transId")
private String transId;
@JsonProperty("maGiaoDich")
private String maGiaoDich;
@JsonProperty("signature")
private String signature;
@JsonProperty("status")
private Status status;
@JsonProperty("trangThai")
private String trangThai;
@JsonProperty("moTaLoi")
private Object moTaLoi;
@JsonProperty("ketQuaDoiSanh")
private Object ketQuaDoiSanh;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("providerId")
public String getProviderId() {
return providerId;
}

@JsonProperty("providerId")
public void setProviderId(String providerId) {
this.providerId = providerId;
}

@JsonProperty("merchantId")
public String getMerchantId() {
return merchantId;
}

@JsonProperty("merchantId")
public void setMerchantId(String merchantId) {
this.merchantId = merchantId;
}

@JsonProperty("transId")
public String getTransId() {
return transId;
}

@JsonProperty("transId")
public void setTransId(String transId) {
this.transId = transId;
}

@JsonProperty("maGiaoDich")
public String getMaGiaoDich() {
return maGiaoDich;
}

@JsonProperty("maGiaoDich")
public void setMaGiaoDich(String maGiaoDich) {
this.maGiaoDich = maGiaoDich;
}

@JsonProperty("signature")
public String getSignature() {
return signature;
}

@JsonProperty("signature")
public void setSignature(String signature) {
this.signature = signature;
}

@JsonProperty("status")
public Status getStatus() {
return status;
}

@JsonProperty("status")
public void setStatus(Status status) {
this.status = status;
}

@JsonProperty("trangThai")
public String getTrangThai() {
return trangThai;
}

@JsonProperty("trangThai")
public void setTrangThai(String trangThai) {
this.trangThai = trangThai;
}

@JsonProperty("moTaLoi")
public Object getMoTaLoi() {
return moTaLoi;
}

@JsonProperty("moTaLoi")
public void setMoTaLoi(Object moTaLoi) {
this.moTaLoi = moTaLoi;
}

@JsonProperty("ketQuaDoiSanh")
public Object getKetQuaDoiSanh() {
return ketQuaDoiSanh;
}

@JsonProperty("ketQuaDoiSanh")
public void setKetQuaDoiSanh(Object ketQuaDoiSanh) {
this.ketQuaDoiSanh = ketQuaDoiSanh;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
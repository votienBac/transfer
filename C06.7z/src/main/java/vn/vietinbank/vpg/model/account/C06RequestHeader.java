package vn.vietinbank.vpg.model.account;

public class C06RequestHeader {
	private String x_ibm_client_secret ;
	private String x_ibm_client_id ;
	public String getX_ibm_client_secret() {
		return x_ibm_client_secret;
	}
	public void setX_ibm_client_secret(String x_ibm_client_secret) {
		this.x_ibm_client_secret = x_ibm_client_secret;
	}
	public String getX_ibm_client_id() {
		return x_ibm_client_id;
	}
	public void setX_ibm_client_id(String x_ibm_client_id) {
		this.x_ibm_client_id = x_ibm_client_id;
	}


}

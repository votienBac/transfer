
package vn.vietinbank.vpg.model.inqcust;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import vn.vietinbank.vpg.model.Status;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "transId",
    "channelId",
    "transTime",
    "transType",
    "serviceType",
    "paymentType",
    "paymentMethod",
    "custCode",
    "custName",
    "custAcct",
    "amount",
    "currencyCode",
    "birthDate",
    "gender",
    "idCard",
    "idCardType",
    "acctNo",
    "custAddr",
    "phoneNo",
    "email",
    "status",
    "addInfo",
    "url",
    "preseve1",
    "preseve2",
    "preseve3"
})
public class BeRecord1310 {

    @JsonProperty("transId")
    private String transId;
    @JsonProperty("channelId")
    private String channelId;
    @JsonProperty("transTime")
    private String transTime;
    @JsonProperty("transType")
    private String transType;
    @JsonProperty("serviceType")
    private String serviceType;
    @JsonProperty("paymentType")
    private String paymentType;
    @JsonProperty("paymentMethod")
    private String paymentMethod;
    @JsonProperty("custCode")
    private String custCode;
    @JsonProperty("custName")
    private String custName;
    @JsonProperty("custAcct")
    private String custAcct;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("birthDate")
    private String birthDate;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("idCard")
    private String idCard;
    @JsonProperty("idCardType")
    private String idCardType;
    @JsonProperty("acctNo")
    private String acctNo;
    @JsonProperty("custAddr")
    private String custAddr;
    @JsonProperty("phoneNo")
    private String phoneNo;
    @JsonProperty("email")
    private String email;
    @JsonProperty("status")
    private Status status;
    @JsonProperty("addInfo")
    private Object addInfo;
    @JsonProperty("url")
    private String url;
    @JsonProperty("preseve1")
    private String preseve1;
    @JsonProperty("preseve2")
    private String preseve2;
    @JsonProperty("preseve3")
    private String preseve3;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("transId")
    public String getTransId() {
        return transId;
    }

    @JsonProperty("transId")
    public void setTransId(String transId) {
        this.transId = transId;
    }

    @JsonProperty("channelId")
    public String getChannelId() {
        return channelId;
    }

    @JsonProperty("channelId")
    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    @JsonProperty("transTime")
    public String getTransTime() {
        return transTime;
    }

    @JsonProperty("transTime")
    public void setTransTime(String transTime) {
        this.transTime = transTime;
    }

    @JsonProperty("transType")
    public String getTransType() {
        return transType;
    }

    @JsonProperty("transType")
    public void setTransType(String transType) {
        this.transType = transType;
    }

    @JsonProperty("serviceType")
    public String getServiceType() {
        return serviceType;
    }

    @JsonProperty("serviceType")
    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    @JsonProperty("paymentType")
    public String getPaymentType() {
        return paymentType;
    }

    @JsonProperty("paymentType")
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @JsonProperty("paymentMethod")
    public String getPaymentMethod() {
        return paymentMethod;
    }

    @JsonProperty("paymentMethod")
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @JsonProperty("custCode")
    public String getCustCode() {
        return custCode;
    }

    @JsonProperty("custCode")
    public void setCustCode(String custCode) {
        this.custCode = custCode;
    }

    @JsonProperty("custName")
    public String getCustName() {
        return custName;
    }

    @JsonProperty("custName")
    public void setCustName(String custName) {
        this.custName = custName;
    }

    @JsonProperty("custAcct")
    public String getCustAcct() {
        return custAcct;
    }

    @JsonProperty("custAcct")
    public void setCustAcct(String custAcct) {
        this.custAcct = custAcct;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }
    
    @JsonProperty("currencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("currencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
    
    @JsonProperty("birthDate")
    public String getBirthDate() {
        return birthDate;
    }

    @JsonProperty("birthDate")
    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }
    
    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    @JsonProperty("idCard")
    public String getIdCard() {
        return idCard;
    }

    @JsonProperty("idCard")
    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    @JsonProperty("idCardType")
    public String getIdCardType() {
        return idCardType;
    }

    @JsonProperty("idCardType")
    public void setIdCardType(String idCardType) {
        this.idCardType = idCardType;
    }
    
    
    @JsonProperty("acctNo")
    public String getAcctNo() {
        return acctNo;
    }

    @JsonProperty("acctNo")
    public void setAcctNo(String acctNo) {
        this.idCard = idCard;
    }
    @JsonProperty("custAddr")
    public String getCustAddr() {
        return custAddr;
    }

    @JsonProperty("custAddr")
    public void setCustAddr(String custAddr) {
        this.custAddr = custAddr;
    }

    @JsonProperty("phoneNo")
    public String getPhoneNo() {
        return phoneNo;
    }

    @JsonProperty("phoneNo")
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @JsonProperty("addInfo")
    public Object getAddInfo() {
        return addInfo;
    }

    @JsonProperty("addInfo")
    public void setAddInfo(Object addInfo) {
        this.addInfo = addInfo;
    }

    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }
    
    @JsonProperty("preseve1")
    public String getPreseve1() {
        return preseve1;
    }

    @JsonProperty("preseve1")
    public void setPreseve1(String preseve1) {
        this.preseve1 = preseve1;
    }

    @JsonProperty("preseve2")
    public String getPreseve2() {
        return preseve2;
    }

    @JsonProperty("preseve2")
    public void setPreseve2(String preseve2) {
        this.preseve2 = preseve2;
    }

    @JsonProperty("preseve3")
    public String getPreseve3() {
        return preseve3;
    }

    @JsonProperty("preseve3")
    public void setPreseve3(String preseve3) {
        this.preseve3 = preseve3;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

package vn.vietinbank.vpg.model.inqcust;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"maGiaoDich",
"soDinhDanh",
"ngayGioGiaoDich",
"anhChanDungBase64"
})
@Generated("jsonschema2pojo")
public class C06Message1300 {

@JsonProperty("maGiaoDich")
private String maGiaoDich;
@JsonProperty("soDinhDanh")
private String soDinhDanh;
@JsonProperty("ngayGioGiaoDich")
private String ngayGioGiaoDich;
@JsonProperty("anhChanDungBase64")
private String anhChanDungBase64;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("maGiaoDich")
public String getMaGiaoDich() {
return maGiaoDich;
}

@JsonProperty("maGiaoDich")
public void setMaGiaoDich(String maGiaoDich) {
this.maGiaoDich = maGiaoDich;
}

@JsonProperty("soDinhDanh")
public String getSoDinhDanh() {
return soDinhDanh;
}

@JsonProperty("soDinhDanh")
public void setSoDinhDanh(String soDinhDanh) {
this.soDinhDanh = soDinhDanh;
}

@JsonProperty("ngayGioGiaoDich")
public String getNgayGioGiaoDich() {
return ngayGioGiaoDich;
}

@JsonProperty("ngayGioGiaoDich")
public void setNgayGioGiaoDich(String ngayGioGiaoDich) {
this.ngayGioGiaoDich = ngayGioGiaoDich;
}

@JsonProperty("anhChanDungBase64")
public String getAnhChanDungBase64() {
return anhChanDungBase64;
}

@JsonProperty("anhChanDungBase64")
public void setAnhChanDungBase64(String anhChanDungBase64) {
this.anhChanDungBase64 = anhChanDungBase64;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
package vn.vietinbank.vpg.model.inqcust;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"errors",
"records"
})
@Generated("jsonschema2pojo")
public class PrvData1310 {

@JsonProperty("errors")
private PrvErrors1310 errors;
@JsonProperty("records")
private List<PrvRecord1310> records = null;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("errors")
public PrvErrors1310 getErrors() {
return errors;
}

@JsonProperty("errors")
public void setErrors(PrvErrors1310 errors) {
this.errors = errors;
}

@JsonProperty("records")
public List<PrvRecord1310> getRecords() {
return records;
}

@JsonProperty("records")
public void setRecords(List<PrvRecord1310> records) {
this.records = records;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
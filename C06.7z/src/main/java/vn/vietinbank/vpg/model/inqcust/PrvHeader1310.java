package vn.vietinbank.vpg.model.inqcust;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"msgId",
"msgType",
"channelId",
"providerId",
"merchantId",
"productId",
"timestamp",
"recordNum",
"signature"
})
@Generated("jsonschema2pojo")
public class PrvHeader1310 {

@JsonProperty("msgId")
private String msgId;
@JsonProperty("msgType")
private String msgType;
@JsonProperty("channelId")
private String channelId;
@JsonProperty("providerId")
private String providerId;
@JsonProperty("merchantId")
private String merchantId;
@JsonProperty("productId")
private String productId;
@JsonProperty("timestamp")
private String timestamp;
@JsonProperty("recordNum")
private String recordNum;
@JsonProperty("signature")
private String signature;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("msgId")
public String getMsgId() {
return msgId;
}

@JsonProperty("msgId")
public void setMsgId(String msgId) {
this.msgId = msgId;
}

@JsonProperty("msgType")
public String getMsgType() {
return msgType;
}

@JsonProperty("msgType")
public void setMsgType(String msgType) {
this.msgType = msgType;
}

@JsonProperty("channelId")
public String getChannelId() {
return channelId;
}

@JsonProperty("channelId")
public void setChannelId(String channelId) {
this.channelId = channelId;
}

@JsonProperty("providerId")
public String getProviderId() {
return providerId;
}

@JsonProperty("providerId")
public void setProviderId(String providerId) {
this.providerId = providerId;
}

@JsonProperty("merchantId")
public String getMerchantId() {
return merchantId;
}

@JsonProperty("merchantId")
public void setMerchantId(String merchantId) {
this.merchantId = merchantId;
}

@JsonProperty("productId")
public String getProductId() {
return productId;
}

@JsonProperty("productId")
public void setProductId(String productId) {
this.productId = productId;
}

@JsonProperty("timestamp")
public String getTimestamp() {
return timestamp;
}

@JsonProperty("timestamp")
public void setTimestamp(String timestamp) {
this.timestamp = timestamp;
}

@JsonProperty("recordNum")
public String getRecordNum() {
return recordNum;
}

@JsonProperty("recordNum")
public void setRecordNum(String recordNum) {
this.recordNum = recordNum;
}

@JsonProperty("signature")
public String getSignature() {
return signature;
}

@JsonProperty("signature")
public void setSignature(String signature) {
this.signature = signature;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
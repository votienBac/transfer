package vn.vietinbank.vpg.model.inqcust;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"header",
"data"
})
@Generated("jsonschema2pojo")
public class PrvMessage1310 {

@JsonProperty("header")
private PrvHeader1310 header;
@JsonProperty("data")
private PrvData1310 data;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("header")
public PrvHeader1310 getHeader() {
return header;
}

@JsonProperty("header")
public void setHeader(PrvHeader1310 header) {
this.header = header;
}

@JsonProperty("data")
public PrvData1310 getData() {
return data;
}

@JsonProperty("data")
public void setData(PrvData1310 data) {
this.data = data;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}

package vn.vietinbank.vpg.model.inqcust;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"transId",
"channelId",
"transTime",
"transType",
"serviceType",
"paymentType",
"paymentMethod",
"custCode",
"custName",
"custAcct",
"idCard",
"custAddr",
"custStreet",
"phoneNo",
"email",
"areaCode",
"provinceCode",
"tid",
"addInfo",
"preseve1",
"preseve2",
"preseve3"
})
@Generated("jsonschema2pojo")
public class PrvRecord1300 {

@JsonProperty("transId")
private String transId;
@JsonProperty("channelId")
private String channelId;
@JsonProperty("transTime")
private String transTime;
@JsonProperty("transType")
private String transType;
@JsonProperty("serviceType")
private String serviceType;
@JsonProperty("paymentType")
private String paymentType;
@JsonProperty("paymentMethod")
private String paymentMethod;
@JsonProperty("custCode")
private String custCode;
@JsonProperty("custName")
private String custName;
@JsonProperty("custAcct")
private String custAcct;
@JsonProperty("idCard")
private String idCard;
@JsonProperty("custAddr")
private String custAddr;
@JsonProperty("custStreet")
private String custStreet;
@JsonProperty("phoneNo")
private String phoneNo;
@JsonProperty("email")
private String email;
@JsonProperty("areaCode")
private String areaCode;
@JsonProperty("provinceCode")
private String provinceCode;
@JsonProperty("tid")
private String tid;
@JsonProperty("addInfo")
private Object addInfo;
@JsonProperty("preseve1")
private String preseve1;
@JsonProperty("preseve2")
private String preseve2;
@JsonProperty("preseve3")
private String preseve3;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("transId")
public String getTransId() {
return transId;
}

@JsonProperty("transId")
public void setTransId(String transId) {
this.transId = transId;
}

@JsonProperty("channelId")
public String getChannelId() {
return channelId;
}

@JsonProperty("channelId")
public void setChannelId(String channelId) {
this.channelId = channelId;
}

@JsonProperty("transTime")
public String getTransTime() {
return transTime;
}

@JsonProperty("transTime")
public void setTransTime(String transTime) {
this.transTime = transTime;
}

@JsonProperty("transType")
public String getTransType() {
return transType;
}

@JsonProperty("transType")
public void setTransType(String transType) {
this.transType = transType;
}

@JsonProperty("serviceType")
public String getServiceType() {
return serviceType;
}

@JsonProperty("serviceType")
public void setServiceType(String serviceType) {
this.serviceType = serviceType;
}

@JsonProperty("paymentType")
public String getPaymentType() {
return paymentType;
}

@JsonProperty("paymentType")
public void setPaymentType(String paymentType) {
this.paymentType = paymentType;
}

@JsonProperty("paymentMethod")
public String getPaymentMethod() {
return paymentMethod;
}

@JsonProperty("paymentMethod")
public void setPaymentMethod(String paymentMethod) {
this.paymentMethod = paymentMethod;
}

@JsonProperty("custCode")
public String getCustCode() {
return custCode;
}

@JsonProperty("custCode")
public void setCustCode(String custCode) {
this.custCode = custCode;
}

@JsonProperty("custName")
public String getCustName() {
return custName;
}

@JsonProperty("custName")
public void setCustName(String custName) {
this.custName = custName;
}

@JsonProperty("custAcct")
public String getCustAcct() {
return custAcct;
}

@JsonProperty("custAcct")
public void setCustAcct(String custAcct) {
this.custAcct = custAcct;
}

@JsonProperty("idCard")
public String getIdCard() {
return idCard;
}

@JsonProperty("idCard")
public void setIdCard(String idCard) {
this.idCard = idCard;
}

@JsonProperty("custAddr")
public String getCustAddr() {
return custAddr;
}

@JsonProperty("custAddr")
public void setCustAddr(String custAddr) {
this.custAddr = custAddr;
}

@JsonProperty("custStreet")
public String getCustStreet() {
return custStreet;
}

@JsonProperty("custStreet")
public void setCustStreet(String custStreet) {
this.custStreet = custStreet;
}

@JsonProperty("phoneNo")
public String getPhoneNo() {
return phoneNo;
}

@JsonProperty("phoneNo")
public void setPhoneNo(String phoneNo) {
this.phoneNo = phoneNo;
}

@JsonProperty("email")
public String getEmail() {
return email;
}

@JsonProperty("email")
public void setEmail(String email) {
this.email = email;
}

@JsonProperty("areaCode")
public String getAreaCode() {
return areaCode;
}

@JsonProperty("areaCode")
public void setAreaCode(String areaCode) {
this.areaCode = areaCode;
}

@JsonProperty("provinceCode")
public String getProvinceCode() {
return provinceCode;
}

@JsonProperty("provinceCode")
public void setProvinceCode(String provinceCode) {
this.provinceCode = provinceCode;
}

@JsonProperty("tid")
public String getTid() {
return tid;
}

@JsonProperty("tid")
public void setTid(String tid) {
this.tid = tid;
}

@JsonProperty("addInfo")
public Object getAddInfo() {
return addInfo;
}

@JsonProperty("addInfo")
public void setAddInfo(Object addInfo) {
this.addInfo = addInfo;
}

@JsonProperty("preseve1")
public String getPreseve1() {
return preseve1;
}

@JsonProperty("preseve1")
public void setPreseve1(String preseve1) {
this.preseve1 = preseve1;
}

@JsonProperty("preseve2")
public String getPreseve2() {
return preseve2;
}

@JsonProperty("preseve2")
public void setPreseve2(String preseve2) {
this.preseve2 = preseve2;
}

@JsonProperty("preseve3")
public String getPreseve3() {
return preseve3;
}

@JsonProperty("preseve3")
public void setPreseve3(String preseve3) {
this.preseve3 = preseve3;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}

package vn.vietinbank.vpg.model.notifystatus;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"msgId",
"msgType",
"channelId",
"gatewayId",
"providerId",
"merchantId",
"productId",
"timestamp",
"recordNum",
"username",
"password",
"token",
"version",
"language",
"clientIP",
"preseve1",
"preseve2",
"preseve3",
"signature",
"encrypt"
})
@Generated("jsonschema2pojo")
public class BeHeader {

@JsonProperty("msgId")
private String msgId;
@JsonProperty("msgType")
private String msgType;
@JsonProperty("channelId")
private String channelId;
@JsonProperty("gatewayId")
private String gatewayId;
@JsonProperty("providerId")
private String providerId;
@JsonProperty("merchantId")
private String merchantId;
@JsonProperty("productId")
private String productId;
@JsonProperty("timestamp")
private String timestamp;
@JsonProperty("recordNum")
private String recordNum;
@JsonProperty("username")
private String username;
@JsonProperty("password")
private String password;
@JsonProperty("token")
private String token;
@JsonProperty("version")
private String version;
@JsonProperty("language")
private String language;
@JsonProperty("clientIP")
private String clientIP;
@JsonProperty("preseve1")
private String preseve1;
@JsonProperty("preseve2")
private String preseve2;
@JsonProperty("preseve3")
private String preseve3;
@JsonProperty("signature")
private String signature;
@JsonProperty("encrypt")
private String encrypt;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("msgId")
public String getMsgId() {
return msgId;
}

@JsonProperty("msgId")
public void setMsgId(String msgId) {
this.msgId = msgId;
}

@JsonProperty("msgType")
public String getMsgType() {
return msgType;
}

@JsonProperty("msgType")
public void setMsgType(String msgType) {
this.msgType = msgType;
}

@JsonProperty("channelId")
public String getChannelId() {
return channelId;
}

@JsonProperty("channelId")
public void setChannelId(String channelId) {
this.channelId = channelId;
}

@JsonProperty("gatewayId")
public String getGatewayId() {
return gatewayId;
}

@JsonProperty("gatewayId")
public void setGatewayId(String gatewayId) {
this.gatewayId = gatewayId;
}

@JsonProperty("providerId")
public String getProviderId() {
return providerId;
}

@JsonProperty("providerId")
public void setProviderId(String providerId) {
this.providerId = providerId;
}

@JsonProperty("merchantId")
public String getMerchantId() {
return merchantId;
}

@JsonProperty("merchantId")
public void setMerchantId(String merchantId) {
this.merchantId = merchantId;
}

@JsonProperty("productId")
public String getProductId() {
return productId;
}

@JsonProperty("productId")
public void setProductId(String productId) {
this.productId = productId;
}

@JsonProperty("timestamp")
public String getTimestamp() {
return timestamp;
}

@JsonProperty("timestamp")
public void setTimestamp(String timestamp) {
this.timestamp = timestamp;
}

@JsonProperty("recordNum")
public String getRecordNum() {
return recordNum;
}

@JsonProperty("recordNum")
public void setRecordNum(String recordNum) {
this.recordNum = recordNum;
}

@JsonProperty("username")
public String getUsername() {
return username;
}

@JsonProperty("username")
public void setUsername(String username) {
this.username = username;
}

@JsonProperty("password")
public String getPassword() {
return password;
}

@JsonProperty("password")
public void setPassword(String password) {
this.password = password;
}

@JsonProperty("token")
public String getToken() {
return token;
}

@JsonProperty("token")
public void setToken(String token) {
this.token = token;
}

@JsonProperty("version")
public String getVersion() {
return version;
}

@JsonProperty("version")
public void setVersion(String version) {
this.version = version;
}

@JsonProperty("language")
public String getLanguage() {
return language;
}

@JsonProperty("language")
public void setLanguage(String language) {
this.language = language;
}

@JsonProperty("clientIP")
public String getClientIP() {
return clientIP;
}

@JsonProperty("clientIP")
public void setClientIP(String clientIP) {
this.clientIP = clientIP;
}

@JsonProperty("preseve1")
public String getPreseve1() {
return preseve1;
}

@JsonProperty("preseve1")
public void setPreseve1(String preseve1) {
this.preseve1 = preseve1;
}

@JsonProperty("preseve2")
public String getPreseve2() {
return preseve2;
}

@JsonProperty("preseve2")
public void setPreseve2(String preseve2) {
this.preseve2 = preseve2;
}

@JsonProperty("preseve3")
public String getPreseve3() {
return preseve3;
}

@JsonProperty("preseve3")
public void setPreseve3(String preseve3) {
this.preseve3 = preseve3;
}

@JsonProperty("signature")
public String getSignature() {
return signature;
}

@JsonProperty("signature")
public void setSignature(String signature) {
this.signature = signature;
}

@JsonProperty("encrypt")
public String getEncrypt() {
return encrypt;
}

@JsonProperty("encrypt")
public void setEncrypt(String encrypt) {
this.encrypt = encrypt;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}

package vn.vietinbank.vpg.model.notifystatus;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import vn.vietinbank.vpg.model.Header;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"header",
"data"
})
@Generated("jsonschema2pojo")
public class BeMessage1212 {

@JsonProperty("header")
private Header header;
@JsonProperty("data")
private BeData1212 data;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("header")
public Header getHeader() {
return header;
}

@JsonProperty("header")
public void setHeader(Header header) {
this.header = header;
}

@JsonProperty("data")
public BeData1212 getData() {
return data;
}

@JsonProperty("data")
public void setData(BeData1212 data) {
this.data = data;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}

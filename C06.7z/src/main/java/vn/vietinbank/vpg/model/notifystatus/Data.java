package vn.vietinbank.vpg.model.notifystatus;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"soDinhDanh",
"soTaiKhoan",
"maNganHang",
"maAlias",
"soThe"
})
@Generated("jsonschema2pojo")
public class Data {

@JsonProperty("soDinhDanh")
private String soDinhDanh;
@JsonProperty("soTaiKhoan")
private String soTaiKhoan;
@JsonProperty("maNganHang")
private String maNganHang;
@JsonProperty("maAlias")
private String maAlias;
@JsonProperty("soThe")
private String soThe;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("soDinhDanh")
public String getSoDinhDanh() {
return soDinhDanh;
}

@JsonProperty("soDinhDanh")
public void setSoDinhDanh(String soDinhDanh) {
this.soDinhDanh = soDinhDanh;
}

@JsonProperty("soTaiKhoan")
public String getSoTaiKhoan() {
return soTaiKhoan;
}

@JsonProperty("soTaiKhoan")
public void setSoTaiKhoan(String soTaiKhoan) {
this.soTaiKhoan = soTaiKhoan;
}

@JsonProperty("maNganHang")
public String getMaNganHang() {
return maNganHang;
}

@JsonProperty("maNganHang")
public void setMaNganHang(String maNganHang) {
this.maNganHang = maNganHang;
}

@JsonProperty("maAlias")
public String getMaAlias() {
return maAlias;
}

@JsonProperty("maAlias")
public void setMaAlias(String maAlias) {
this.maAlias = maAlias;
}

@JsonProperty("soThe")
public String getSoThe() {
return soThe;
}

@JsonProperty("soThe")
public void setSoThe(String soThe) {
this.soThe = soThe;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
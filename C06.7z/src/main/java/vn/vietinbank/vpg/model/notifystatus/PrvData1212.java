package vn.vietinbank.vpg.model.notifystatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"errors",
"records"
})
@Generated("jsonschema2pojo")
public class PrvData1212 {

@JsonProperty("errors")
private PrvErrors errors;
@JsonProperty("records")
private List<PrvRecord1212> records = null;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("errors")
public PrvErrors getErrors() {
return errors;
}

@JsonProperty("errors")
public void setErrors(PrvErrors errors) {
this.errors = errors;
}

@JsonProperty("records")
public List<PrvRecord1212> getRecords() {
return records;
}

@JsonProperty("records")
public void setRecords(List<PrvRecord1212> records) {
this.records = records;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
package vn.vietinbank.vpg.model.notifystatus;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"transId",
"originalId",
"channelId",
"transTime",
"transType",
"serviceType",
"sendBankId",
"sendBranchId",
"sendAcctId",
"sendAcctName",
"recvBankId",
"recvBranchId",
"recvAcctId",
"recvAcctName",
"status",
"maker",
"checker",
"custCode",
"custName",
"custAcct",
"idCard",
"phoneNo",
"email",
"term",
"interest",
"amount",
"fee",
"vat",
"addInfo",
"preseve1",
"preseve2",
"preseve3"
})
@Generated("jsonschema2pojo")
public class PrvRecord1202 {

@JsonProperty("transId")
private String transId;
@JsonProperty("originalId")
private String originalId;
@JsonProperty("channelId")
private String channelId;
@JsonProperty("transTime")
private String transTime;
@JsonProperty("transType")
private String transType;
@JsonProperty("serviceType")
private String serviceType;
@JsonProperty("sendBankId")
private String sendBankId;
@JsonProperty("sendBranchId")
private String sendBranchId;
@JsonProperty("sendAcctId")
private String sendAcctId;
@JsonProperty("sendAcctName")
private String sendAcctName;
@JsonProperty("recvBankId")
private String recvBankId;
@JsonProperty("recvBranchId")
private String recvBranchId;
@JsonProperty("recvAcctId")
private String recvAcctId;
@JsonProperty("recvAcctName")
private String recvAcctName;
@JsonProperty("status")
private PrvStatus status;
@JsonProperty("maker")
private PrvMaker maker;
@JsonProperty("checker")
private PrvChecker checker;
@JsonProperty("custCode")
private String custCode;
@JsonProperty("custName")
private String custName;
@JsonProperty("custAcct")
private String custAcct;
@JsonProperty("idCard")
private String idCard;
@JsonProperty("phoneNo")
private String phoneNo;
@JsonProperty("email")
private String email;
@JsonProperty("term")
private String term;
@JsonProperty("interest")
private String interest;
@JsonProperty("amount")
private String amount;
@JsonProperty("fee")
private String fee;
@JsonProperty("vat")
private String vat;
@JsonProperty("addInfo")
private Object addInfo;
@JsonProperty("preseve1")
private String preseve1;
@JsonProperty("preseve2")
private String preseve2;
@JsonProperty("preseve3")
private String preseve3;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("transId")
public String getTransId() {
return transId;
}

@JsonProperty("transId")
public void setTransId(String transId) {
this.transId = transId;
}

@JsonProperty("originalId")
public String getOriginalId() {
return originalId;
}

@JsonProperty("originalId")
public void setOriginalId(String originalId) {
this.originalId = originalId;
}

@JsonProperty("channelId")
public String getChannelId() {
return channelId;
}

@JsonProperty("channelId")
public void setChannelId(String channelId) {
this.channelId = channelId;
}

@JsonProperty("transTime")
public String getTransTime() {
return transTime;
}

@JsonProperty("transTime")
public void setTransTime(String transTime) {
this.transTime = transTime;
}

@JsonProperty("transType")
public String getTransType() {
return transType;
}

@JsonProperty("transType")
public void setTransType(String transType) {
this.transType = transType;
}

@JsonProperty("serviceType")
public String getServiceType() {
return serviceType;
}

@JsonProperty("serviceType")
public void setServiceType(String serviceType) {
this.serviceType = serviceType;
}

@JsonProperty("sendBankId")
public String getSendBankId() {
return sendBankId;
}

@JsonProperty("sendBankId")
public void setSendBankId(String sendBankId) {
this.sendBankId = sendBankId;
}

@JsonProperty("sendBranchId")
public String getSendBranchId() {
return sendBranchId;
}

@JsonProperty("sendBranchId")
public void setSendBranchId(String sendBranchId) {
this.sendBranchId = sendBranchId;
}

@JsonProperty("sendAcctId")
public String getSendAcctId() {
return sendAcctId;
}

@JsonProperty("sendAcctId")
public void setSendAcctId(String sendAcctId) {
this.sendAcctId = sendAcctId;
}

@JsonProperty("sendAcctName")
public String getSendAcctName() {
return sendAcctName;
}

@JsonProperty("sendAcctName")
public void setSendAcctName(String sendAcctName) {
this.sendAcctName = sendAcctName;
}

@JsonProperty("recvBankId")
public String getRecvBankId() {
return recvBankId;
}

@JsonProperty("recvBankId")
public void setRecvBankId(String recvBankId) {
this.recvBankId = recvBankId;
}

@JsonProperty("recvBranchId")
public String getRecvBranchId() {
return recvBranchId;
}

@JsonProperty("recvBranchId")
public void setRecvBranchId(String recvBranchId) {
this.recvBranchId = recvBranchId;
}

@JsonProperty("recvAcctId")
public String getRecvAcctId() {
return recvAcctId;
}

@JsonProperty("recvAcctId")
public void setRecvAcctId(String recvAcctId) {
this.recvAcctId = recvAcctId;
}

@JsonProperty("recvAcctName")
public String getRecvAcctName() {
return recvAcctName;
}

@JsonProperty("recvAcctName")
public void setRecvAcctName(String recvAcctName) {
this.recvAcctName = recvAcctName;
}

@JsonProperty("status")
public PrvStatus getStatus() {
return status;
}

@JsonProperty("status")
public void setStatus(PrvStatus status) {
this.status = status;
}

@JsonProperty("maker")
public PrvMaker getMaker() {
return maker;
}

@JsonProperty("maker")
public void setMaker(PrvMaker maker) {
this.maker = maker;
}

@JsonProperty("checker")
public PrvChecker getChecker() {
return checker;
}

@JsonProperty("checker")
public void setChecker(PrvChecker checker) {
this.checker = checker;
}

@JsonProperty("custCode")
public String getCustCode() {
return custCode;
}

@JsonProperty("custCode")
public void setCustCode(String custCode) {
this.custCode = custCode;
}

@JsonProperty("custName")
public String getCustName() {
return custName;
}

@JsonProperty("custName")
public void setCustName(String custName) {
this.custName = custName;
}

@JsonProperty("custAcct")
public String getCustAcct() {
return custAcct;
}

@JsonProperty("custAcct")
public void setCustAcct(String custAcct) {
this.custAcct = custAcct;
}

@JsonProperty("idCard")
public String getIdCard() {
return idCard;
}

@JsonProperty("idCard")
public void setIdCard(String idCard) {
this.idCard = idCard;
}

@JsonProperty("phoneNo")
public String getPhoneNo() {
return phoneNo;
}

@JsonProperty("phoneNo")
public void setPhoneNo(String phoneNo) {
this.phoneNo = phoneNo;
}

@JsonProperty("email")
public String getEmail() {
return email;
}

@JsonProperty("email")
public void setEmail(String email) {
this.email = email;
}

@JsonProperty("term")
public String getTerm() {
return term;
}

@JsonProperty("term")
public void setTerm(String term) {
this.term = term;
}

@JsonProperty("interest")
public String getInterest() {
return interest;
}

@JsonProperty("interest")
public void setInterest(String interest) {
this.interest = interest;
}

@JsonProperty("amount")
public String getAmount() {
return amount;
}

@JsonProperty("amount")
public void setAmount(String amount) {
this.amount = amount;
}

@JsonProperty("fee")
public String getFee() {
return fee;
}

@JsonProperty("fee")
public void setFee(String fee) {
this.fee = fee;
}

@JsonProperty("vat")
public String getVat() {
return vat;
}

@JsonProperty("vat")
public void setVat(String vat) {
this.vat = vat;
}

@JsonProperty("addInfo")
public Object getAddInfo() {
return addInfo;
}

@JsonProperty("addInfo")
public void setAddInfo(Object addInfo) {
this.addInfo = addInfo;
}

@JsonProperty("preseve1")
public String getPreseve1() {
return preseve1;
}

@JsonProperty("preseve1")
public void setPreseve1(String preseve1) {
this.preseve1 = preseve1;
}

@JsonProperty("preseve2")
public String getPreseve2() {
return preseve2;
}

@JsonProperty("preseve2")
public void setPreseve2(String preseve2) {
this.preseve2 = preseve2;
}

@JsonProperty("preseve3")
public String getPreseve3() {
return preseve3;
}

@JsonProperty("preseve3")
public void setPreseve3(String preseve3) {
this.preseve3 = preseve3;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
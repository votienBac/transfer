package vn.vietinbank.vpg.security;

import vn.vietinbank.vpg.service.VpgMessageAbstractFactory;
import vn.vietinbank.vpg.util.Constants.MESSAGE_TYPE;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;
import vn.vietinbank.vpg.util.Constants.VPG_SECURE_TYPE;



public class HsmSecureFactory implements SecureAbstractFactory<SecureInterface>  {

	
	public SecureInterface create(String providerId) {
		try {
			switch(providerId) {
			case PROVIDER_ID.PRV_001:{
				return new HsmSecureImpl();
				
			}
			
			default:{
				return new HsmSecureImpl();
				
			}
			
			}
		}catch(Exception e) {
			return null;
		}
	
	}

	
	
}

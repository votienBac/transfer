package vn.vietinbank.vpg.security;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Dictionary;

import org.apache.axis2.client.Options;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.vietinbank.hsm.HSMServiceStub;
import vn.vietinbank.hsm.HSMServiceStub.SignString;
import vn.vietinbank.hsm.HSMServiceStub.SignString256;
import vn.vietinbank.hsm.HSMServiceStub.SignString256Response;
import vn.vietinbank.hsm.HSMServiceStub.SignStringResponse;
import vn.vietinbank.hsm.HSMServiceStub.VerifyString;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.VPG_SECURE_ALGORITHM;
import vn.vietinbank.vpg.util.ResourceUtils;

public class HsmSecureImpl implements SecureInterface <VpgMicroServiceParamsEntity, Dictionary> {

	private static final Logger logger = LoggerFactory.getLogger(HsmSecureImpl.class);

	private static String url = "";
	private static String username = "";
	private static String password ="";
	private static String appId = "";
	private static String signAlias = "";
	private static String signMethod = "";
	
	private static String verifyAlias = "";
	private static String verifyMethod = "";
	
	 
	
	private HSMServiceStub stub = null;
	private String signature = "";
	private VerifyString verStr = null;
	private SignString signString = null;
	
	private SimpleDateFormat sdf = null;
	
	Long startTime;
	Long endTime;
	Long processTime;
	
	public HsmSecureImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public HSMServiceStub getHSMServiceStub(String url, String username, String password) throws Exception {
		
		try {
			
			stub = new HSMServiceStub(url);
			
			Options options = stub._getServiceClient().getOptions();
			HttpTransportProperties.Authenticator auth = new HttpTransportProperties.Authenticator();
			auth.setPreemptiveAuthentication(true);
			auth.setPassword(password);
			auth.setUsername(username);
			options.setProperty(HTTPConstants.AUTHENTICATE,auth);
			stub._getServiceClient().setOptions(options);
			
			

		} catch (Exception e) {
			return null;
		}
		return stub;
	}
	

	@Override
	public String signString(VpgMicroServiceParamsEntity config1,  String msg) {
		try {
			this.startTime = System.currentTimeMillis();
			
			switch (CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign.algorithm")) {
			case VPG_SECURE_ALGORITHM.SHA1:{

				
				stub = getHSMServiceStub(config1.getHSM_URL(), 
						config1.getHSM_USR(), 
						config1.getHSM_PWD()
						);
				
				
				signString = new SignString();
				
				
				signString.setAppId(config1.getHSM_APPID());
				signString.setAlias(config1.getHSM_SIGN_ALIAS());
				signString.setMethod(config1.getHSM_SIGN_METHOD());
				
				sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				
				signString.setRefId(sdf.format(new Date()));
				
				signString.setInputString(msg);
				
				SignStringResponse signStringResp = stub.signString(signString);//12 OK
				
				signature = signStringResp.get_return();
				
				break;
				}
			case VPG_SECURE_ALGORITHM.SHA256:{
				
				
				stub = getHSMServiceStub(config1.getHSM_URL(), 
						config1.getHSM_USR(), 
						config1.getHSM_PWD()
						);
				
				
				SignString256 signString = new SignString256();
				
				signString.setAppId(config1.getHSM_APPID());
				signString.setAlias(config1.getHSM_SIGN_ALIAS());
				signString.setMethod(config1.getHSM_SIGN_METHOD());
				
				sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				
				signString.setRefId(sdf.format(new Date()));
				
				signString.setInputString(msg);
				
				SignString256Response signStringResp = stub.signString256(signString);//
				
				signature = signStringResp.get_return();
				
				break;
				
			}
				
				
			}
		
			return signature;
			
		} catch (Exception ex) {
			
			return "";
		}
		finally{
			sdf = null;
			signString = null;
			this.endTime = System.currentTimeMillis();
			CommonUtils.logFilesByThreshold(startTime, endTime, 
					Long.parseLong(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.threshold.secure")),//ResourceUtils.getThresHoldSecure(), 
					Constants.PROCESS_TIME.SECURE);
		}
	}

	@Override
	public boolean verifyString(VpgMicroServiceParamsEntity config1,  String msg, String signed) {
		try {
			this.startTime = System.currentTimeMillis();
			
			switch (CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify.algorithm")) {
			case VPG_SECURE_ALGORITHM.SHA1:{
				
				stub = getHSMServiceStub(config1.getHSM_URL(), 
						config1.getHSM_USR(), 
						config1.getHSM_PWD()
						);
				
				verStr = new VerifyString();
				
				verStr.setAppId(config1.getHSM_APPID());
				verStr.setAlias(config1.getHSM_VERIFY_ALIAS());
				verStr.setMethod(config1.getHSM_VERIFY_METHOD());
				
				sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				
				verStr.setRefId(sdf.format(new Date()));
				
				verStr.setInputString(msg);
				
				verStr.setSignedString(signed);
				
				stub.verifyString(verStr);
			}
			case VPG_SECURE_ALGORITHM.SHA256:{ 
				
				stub = getHSMServiceStub(config1.getHSM_URL(), 
						config1.getHSM_USR(), 
						config1.getHSM_PWD()
						);
				
				verStr = new VerifyString();
				
				verStr.setAppId(config1.getHSM_APPID());
				verStr.setAlias(config1.getHSM_VERIFY_ALIAS());
				verStr.setMethod(config1.getHSM_VERIFY_METHOD());
				
				sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				
				verStr.setRefId(sdf.format(new Date()));
				
				verStr.setInputString(msg);
				
				verStr.setSignedString(signed);
				
				stub.verifyString(verStr);
			}
			}
			
			return true;
						
		} catch (Exception ex) {  
			return false;
		}
		finally{
			sdf = null;
			verStr = null;
			this.endTime = System.currentTimeMillis();
			CommonUtils.logFilesByThreshold(startTime, endTime,
					Long.parseLong(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.threshold.secure")),//ResourceUtils.getThresHoldSecure(), 
					Constants.PROCESS_TIME.SECURE);
		}
	}
	

	
	

}

package vn.vietinbank.vpg.security;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;



public interface SecureAbstractFactory<T> {

	public T create(String providerId);
			
}

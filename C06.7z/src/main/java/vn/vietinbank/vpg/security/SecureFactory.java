package vn.vietinbank.vpg.security;

import vn.vietinbank.vpg.util.Constants;

public class SecureFactory {

	public static SecureAbstractFactory getFactory(String secureType) {
		try {
		switch (secureType)
		{
			case Constants.VPG_SECURE_TYPE.HSM:
				return new HsmSecureFactory();
		
			case Constants.VPG_SECURE_TYPE.VPG:
				return new VpgSecureFactory();
				
			default:
				throw new IllegalArgumentException("The secure type " + secureType + " is not support!");
		
		}//end switch
		}catch(Exception e) {
			return null;
		}
		
	}
	
	
}

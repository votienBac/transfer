package vn.vietinbank.vpg.security;

public interface SecureInterface <T1,T2> {

	
	String signString(T1 config1, String msg);
	
	boolean verifyString(T1 config1, String msg, String signed);
	
}

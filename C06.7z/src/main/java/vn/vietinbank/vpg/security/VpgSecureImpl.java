package vn.vietinbank.vpg.security;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Dictionary;

import org.apache.axis2.client.Options;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.vietinbank.hsm.HSMServiceStub;
import vn.vietinbank.hsm.HSMServiceStub.SignString;
import vn.vietinbank.hsm.HSMServiceStub.SignStringResponse;
import vn.vietinbank.hsm.HSMServiceStub.VerifyString;
import vn.vietinbank.vpg.crypto.VpgCryptoImpl;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.ResourceUtils;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.util.Enumeration;
import java.security.Signature;
import java.util.Base64;

public class VpgSecureImpl implements SecureInterface<VpgMicroServiceParamsEntity, Dictionary> {

	private static final Logger logger = LoggerFactory.getLogger(VpgSecureImpl.class);

	private String signature = "";
	private VerifyString verStr = null;
	private SignString signString = null;
	
	private SimpleDateFormat sdf = null;
	
	VpgCryptoImpl vpgCrypto = null;
	
	Long startTime;
	Long endTime;
	Long processTime;
	
	public VpgSecureImpl() {
		super();
	}
	
	
	@Override
	public String signString(VpgMicroServiceParamsEntity config1, String msg) {

try {
			
			this.startTime = System.currentTimeMillis();
			
		
			String dataSign = msg;
			
			String signed = "";
		
			vpgCrypto = VpgCryptoImpl.getInstance();
			
			signed = vpgCrypto.signString(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_instance"), 
							CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_private"), 
							CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_private_type"),
							CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_pass"), 
					"",
					dataSign,
					CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign.encoding")
					);
			
			
			
			return signed;
			
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("signString() is failed! Exception = " + ex.getMessage()); 
			return "";
		}
		finally {
			this.endTime = System.currentTimeMillis();
			CommonUtils.logFilesByThreshold(startTime, endTime, Long.parseLong(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.threshold.secure"))
					, Constants.PROCESS_TIME.SECURE);
			
		}
	}



	@Override
	public boolean verifyString(VpgMicroServiceParamsEntity config1, String msg, String signed) {
		try {
			this.startTime = System.currentTimeMillis();
			
			boolean res = false;
			
						
			vpgCrypto = VpgCryptoImpl.getInstance();
			
			
			if(!CommonUtils.isNullOrEmpty(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify_alias")))
			{
				res = vpgCrypto.verifyString(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify_instance"),  
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_private"),  
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_private_type"), 
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_pass"), 
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify_alias"), 
						msg, 
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify.encoding"),
						signed);
						
			}else
			{
				res = vpgCrypto.verifyString(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify_instance"),
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.sign_public"), 
						"", 
						"",
						"",
						msg, 
						CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.secure.verify.encoding"), 
						signed);
						
			}
			
			
			return res;
			
						
		} catch (Exception ex) {  
			ex.printStackTrace();
			logger.error("verifyString() is failed! Exception = " + ex.getMessage()); 
			return false;
		}
		finally {
			this.endTime = System.currentTimeMillis();
			CommonUtils.logFilesByThreshold(startTime, endTime, Long.parseLong(CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),"vpg.threshold.secure")) 
					, Constants.PROCESS_TIME.SECURE);
			
		}
	}
	

}


package vn.vietinbank.vpg.service;


public interface PkgMsgAbstractFactory<T> {

	public T create(String provider);
	public T create(String formatType, String provider);
			
}

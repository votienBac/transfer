package vn.vietinbank.vpg.service;

import vn.vietinbank.vpg.service.account.PkgMsg1301Factory;
import vn.vietinbank.vpg.service.account.PkgMsg1302Factory;
import vn.vietinbank.vpg.service.account.PkgMsg1311Factory;
import vn.vietinbank.vpg.service.account.PkgMsg1312Factory;
import vn.vietinbank.vpg.service.inqcust.PkgMsg1300Factory;
import vn.vietinbank.vpg.service.inqcust.PkgMsg1310Factory;
import vn.vietinbank.vpg.service.notifystatus.PkgMsg1202Factory;
import vn.vietinbank.vpg.service.notifystatus.PkgMsg1212Factory;
import vn.vietinbank.vpg.util.Constants;

public class PkgMsgFactory {

	public static PkgMsgAbstractFactory getFactory(String messageType) {
		try {
		switch (messageType)
		{
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1300:
				return new PkgMsg1300Factory();
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1310:
				return new PkgMsg1310Factory();
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1202:
				return new PkgMsg1202Factory();
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1212:
				return new PkgMsg1212Factory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1301:
				return new PkgMsg1301Factory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1302:
				return new PkgMsg1302Factory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1311:
				return new PkgMsg1311Factory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1312:
				return new PkgMsg1312Factory();
				
			default:
				throw new IllegalArgumentException("The message type " + messageType + " is not support!");
		
		}
		}catch(Exception e) {
			return null;
		}
		
	}
	
	
}

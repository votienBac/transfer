package vn.vietinbank.vpg.service;

import java.util.Dictionary;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;

public interface PkgMsgInterface<T1,T2,T3,T4> {

	public T4 packageMessage(T1 beMessageRq, T2 prvMessageRs, T3 result, VpgMicroServiceParamsEntity config1);
			
}

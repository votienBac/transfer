package vn.vietinbank.vpg.service;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;



public interface VpgMessageAbstractFactory<T> {

	public T create(String provider);

	public T create(String formatType, String provider);
}

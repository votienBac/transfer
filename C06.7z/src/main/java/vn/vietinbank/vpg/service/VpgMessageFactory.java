package vn.vietinbank.vpg.service;

import vn.vietinbank.vpg.service.account.VpgCreateAccountFactory;
import vn.vietinbank.vpg.service.inqcust.VpgInqCustFactory;
import vn.vietinbank.vpg.service.notifystatus.VpgNotifyStatusFactory;
import vn.vietinbank.vpg.util.Constants;

public class VpgMessageFactory {

	public static VpgMessageAbstractFactory getFactory(String messageType) {
		try {
		switch (messageType)
		{
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1100:
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1300:
				return new VpgInqCustFactory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1301:
				return new VpgCreateAccountFactory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1302:
				return new VpgCreateAccountFactory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1400:
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1500:
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1600:
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1700:
				
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1800:
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1202:
				return new VpgNotifyStatusFactory();
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1105:
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1106:
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1107:
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1108:
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1109:
			case Constants.VPG_MSG_TYPE.MSG_TYPE_1104:
				
				
			default:
				throw new IllegalArgumentException("The message type " + messageType + " is not support!");
		
		}
		}catch(Exception e) {
			return null;
		}
		
	}
	
	
}

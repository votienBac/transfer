package vn.vietinbank.vpg.service;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;



public interface VpgPackageMessageAbstractFactory<T> {

	public T create(String messageType);
			
}

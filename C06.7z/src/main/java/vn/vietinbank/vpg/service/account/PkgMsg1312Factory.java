package vn.vietinbank.vpg.service.account;

import vn.vietinbank.vpg.service.PkgMsgAbstractFactory;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;


public class PkgMsg1312Factory implements PkgMsgAbstractFactory<PkgMsgInterface> {

	
	@Override
	public PkgMsgInterface create(String provider) {
	
		try {
			switch(provider) {
			
			case PROVIDER_ID.BCA_C06:{
				return new PrvPkgMsg1312Impl();
				
			}
			default:{
				return new PrvPkgMsg1312Impl();
			}
			
			}

			
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	public PkgMsgInterface create(String formatType, String provider) {
		return null;
	}

	
	
}

package vn.vietinbank.vpg.service.account;

import java.net.URI;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.vietinbank.vpg.dao.VpgTransDetailsInqCustInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransDetailsInqCustInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;
import vn.vietinbank.vpg.model.ConfigParams;
import vn.vietinbank.vpg.model.Errors;
import vn.vietinbank.vpg.model.Header;
import vn.vietinbank.vpg.model.Status;
import vn.vietinbank.vpg.model.account.C06CreateAccountRq;
import vn.vietinbank.vpg.model.account.C06CreateAccountRqBackend;
import vn.vietinbank.vpg.model.account.C06CreateAccountRs;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARq;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARs;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanRsBackend;
import vn.vietinbank.vpg.model.error.MessageErrorPrv;
import vn.vietinbank.vpg.model.inqcust.BeData1310;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.BeMessage1310;
import vn.vietinbank.vpg.model.inqcust.BeRecord1310;
import vn.vietinbank.vpg.model.inqcust.PrvData1300;
import vn.vietinbank.vpg.model.inqcust.PrvHeader1300;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1300;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1310;
import vn.vietinbank.vpg.model.inqcust.PrvRecord1300;
import vn.vietinbank.vpg.security.SecureAbstractFactory;
import vn.vietinbank.vpg.security.SecureFactory;
import vn.vietinbank.vpg.security.SecureInterface;
import vn.vietinbank.vpg.service.PkgMsgAbstractFactory;
import vn.vietinbank.vpg.service.PkgMsgFactory;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.service.callapi.VpgCallApiFactory;
import vn.vietinbank.vpg.service.callapi.VpgCallApiInterface;
import vn.vietinbank.vpg.service.error.VpgMessageErrorFactory;
import vn.vietinbank.vpg.service.error.VpgMessageErrorInterface;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;
import vn.vietinbank.vpg.dao.*;


public class PrvCreateAccountImpl implements VpgCreateAccountInterface {

	private static final Logger logger = LoggerFactory.getLogger(PrvCreateAccountImpl.class);
	
	private BeMessage1300 messageRQ = null;
	private VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity;
	
	VpgTransLogOutDaoInterface vpgTransLogOutDAO 	= null;
	VpgTransLogOutEntity vpgTransLogOutEntity = null;
	
	VpgTransLogInDaoInterface vpgTransLogInDAO 	= null;
	VpgTransLogInEntity vpgTransLogInEntity = null;
	
	C06CreateAccountRs messageRS = null;
	C06KetQuaXacNhanARs messageKQXNRS = null;
	BeData1310 data = null;
	vn.vietinbank.vpg.model.Header header  = null;
	
	String msgRq = "";
	String msgRs = "";
	
	String dataSign = "";
	String signed = "";
	boolean bVerify = false;
	
	
	vn.vietinbank.vpg.model.Errors errors = null;
	String jsonRs = "";
	
	Long processTimeStart;
	Long processTimeEnd;
	Long processTime;
	
	Long processTimePartnerStart;
	Long processTimePartnerEnd;
	Long processTimePartner;
	
	Long processTimeDBStart;
	Long processTimeDBEnd;
	Long processTimeDB;
	
	C06CreateAccountRqBackend message1301Prv = null;
	C06KetQuaXacNhanARq message1302Prv = null;
	PrvHeader1300 header1300Prv = null;
	PrvData1300 data1300Prv = null;
	
	C06CreateAccountRs message1311Prv = null;
	C06KetQuaXacNhanRsBackend message1312Prv = null;
	List<PrvRecord1300>  lstRecord1300Prv = null;
	PrvRecord1300  record1300Prv = null;
	
	List<BeRecord1310>  lstRecord1310 = null;
	BeRecord1310  record1310 = null;
	
	JsonNode rootNode = null;
	JsonNode type = null;
	
	
	VpgMessageErrorFactory vpgMessageErrorFactory = null;
	VpgMessageErrorInterface vpgMessageErrorInterface;
	
	int httpStatus = 200;
	MessageErrorPrv messageErrorPrv = null;
	
	SecureAbstractFactory secureAbstractFactory = null;
	SecureInterface secureInterface = null;
	
	PkgMsgAbstractFactory pkgMsgAbstractFactory = null;
	PkgMsgInterface pkgMsgInterface = null;
	

	
	VpgTransDetailsInqCustInDaoInterface vpgTransDetailsInqCustInDAO 	= null;
	ResponseEntity<String> result = null;
	
	
	public PrvCreateAccountImpl() {
		
	}
	

	@Override
	public C06CreateAccountRs processMessage(C06CreateAccountRq message1301,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try
		{
			this.processTimeStart = System.currentTimeMillis(); 
			
			
			switch(vpgMicroServiceParamsEntity.getCHANGE_FORMAT().trim()) {
			
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_0:{
					
					
					break;
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_1:{
					
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1301);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					message1301Prv = (C06CreateAccountRqBackend) pkgMsgInterface.packageMessage(message1301, null, null, vpgMicroServiceParamsEntity);
					
					
					if(message1301Prv == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PKG.CODE,
								Constants.VPG_STATUS_ERR_PKG.DESC);
					}
					
					if(vpgMicroServiceParamsEntity.getHSM_ENABLE().equals(VPG_STATUS.ENABLE)){
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.HSM);
						
					}else
					{
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.VPG);
					}
					
					secureInterface = (SecureInterface) secureAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID().trim());//
					
					
					
					
					
					msgRq = ConvertJsonToObject.objectToJson(message1301Prv,true);
			        
			        this.processTimeDBStart = System.currentTimeMillis();
			        
			        try {
			        	logOut(message1301,ConvertJsonToObject.objectToJson(message1301),msgRq,vpgMicroServiceParamsEntity);
			        }catch(Exception e) {
			        	
			        	logger.error("logOut() is failed. Message request: " + msgRq + "; Exception: " + e.getMessage());
			        	
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_DB.CODE,
								Constants.VPG_STATUS_ERR_DB.DESC);
			        }
			        
			        this.processTimeDBEnd = System.currentTimeMillis();
			        
			        this.processTimeDB = this.processTimeDBEnd - this.processTimeDBStart;
			        
			        
			        this.processTimePartnerStart = System.currentTimeMillis();
					
					ResponseEntity<String> result = callApi(msgRq,vpgMicroServiceParamsEntity);
					
					this.processTimePartnerEnd = System.currentTimeMillis();
					
					this.processTimePartner = this.processTimePartnerEnd - this.processTimePartnerStart;
					
					if(result == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.CODE,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.DESC);
					}
					
					msgRs = result.getBody();
					logger.info("Respose from Partner : " + msgRs);
					
					httpStatus = result.getStatusCodeValue();
					
					if(httpStatus != 200) {
						switch (httpStatus)
						{
							case 400:
							{
								messageErrorPrv = ConvertJsonToObject.jsonToObject(msgRs, MessageErrorPrv.class);
								
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
								
								return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
										messageErrorPrv.getCode(),
										messageErrorPrv.getMessage(),
										Constants.VPG_STATUS_ERR_PARSE.CODE,
										Constants.VPG_STATUS_ERR_PARSE.DESC);
								
							}
							case 500:
							{
								
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
								
								return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
										String.valueOf(result.getStatusCodeValue()),
										result.getBody(),
										Constants.VPG_STATUS_ERR_GENERAL.CODE,
										Constants.VPG_STATUS_ERR_GENERAL.DESC);
							}
							default: {
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
								
								return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
										String.valueOf(result.getStatusCodeValue()),
										result.getBody(),
										Constants.VPG_STATUS_ERR_GENERAL.CODE,
										Constants.VPG_STATUS_ERR_GENERAL.DESC);
							}
							
						}
					}
					

					message1311Prv = ConvertJsonToObject.jsonToObject(msgRs, C06CreateAccountRs.class, true);
					
					if(message1311Prv == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PARSE.CODE,
								Constants.VPG_STATUS_ERR_PARSE.DESC);
					}
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1311);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					messageRS = (C06CreateAccountRs) pkgMsgInterface.packageMessage(message1301, message1311Prv, null, vpgMicroServiceParamsEntity);
					
					
					jsonRs = ConvertJsonToObject.objectToJson(messageRS);
					
					this.processTimeEnd = System.currentTimeMillis();
					this.processTime = this.processTimeEnd - this.processTimeStart;
					
					logIn(message1301,messageRS,result.getBody(),jsonRs,vpgMicroServiceParamsEntity);
					
					break;
					
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_2:{
					break;
				}
				
				default:{
					break;
				}
				
			}
		
			return messageRS;
			
		}catch(Exception e) {
			logger.error("notifyTrans() is failed. SOA request: " + msgRq
					+ "; Message response origin: " +  msgRs
					+ "; Message response: " +  jsonRs 
					+ "; Exception: " + e.getMessage());
			
			
			vpgMessageErrorFactory = new VpgMessageErrorFactory();
			
			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
			
			return (C06CreateAccountRs) vpgMessageErrorInterface.getMessageError(message1301,
					Constants.PRV_STATUS_ERR_GENERAL.CODE,
					Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE,
					Constants.VPG_STATUS_ERR_GENERAL.DESC);
			
		}
		finally {
			messageRQ = null;
			vpgTransLogOutDAO 	= null;
			vpgTransLogOutEntity = null;
			vpgTransLogInDAO 	= null;
			vpgTransLogInEntity = null;
			messageRS = null;
			data = null;
			header  = null;
			
			
			
			errors = null;
			message1301 = null;
			header1300Prv = null;
			data1300Prv = null;
			
			lstRecord1300Prv = null;
			record1300Prv = null;
			lstRecord1310 = null;
			record1310 = null;
			
			rootNode = null;
			type = null;
			vpgMessageErrorFactory = null;
			vpgMessageErrorInterface = null;
			messageErrorPrv = null;
			secureAbstractFactory = null;
			secureInterface = null;
		}
		
	}
	
	
	private void logOut(C06CreateAccountRq messageRQ,String originMsg, String convertMsg, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try {
			vpgTransLogOutEntity = new VpgTransLogOutEntity();
			
			vpgTransLogOutEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogOutEntity.setMsg_id(messageRQ.getSoCMND());
			vpgTransLogOutEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1300);
			vpgTransLogOutEntity.setPayment_channel(Constants.CHANNEL.INTERNET);
			
			vpgTransLogOutEntity.setGateway_id(vpgMicroServiceParamsEntity.getGATEWAY_ID());
			vpgTransLogOutEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogOutEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			
			vpgTransLogOutEntity.setTrans_direct(Constants.LOG_OUT.TRANS_DIRECT);
			vpgTransLogOutEntity.setTrans_type(Constants.LOG_OUT.TRANS_TYPE);
			vpgTransLogOutEntity.setService_code(Constants.SERVICE_CODE);
			
			
			vpgTransLogOutEntity.setMsg_origin(originMsg);
			vpgTransLogOutEntity.setMsg_convert(convertMsg);
			
			vpgTransLogOutEntity.setYear(CommonUtils.getYear());
			vpgTransLogOutEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogOutEntity.setDay(CommonUtils.getDayOfMonth());
			
			vpgTransLogOutDAO = new VpgTransLogOutDaoImpl();
			
			vpgTransLogOutDAO.save(vpgTransLogOutEntity);
		}catch(Exception e) {
			logger.error("logOut() is failed: " + e.getMessage());
		}
	}
	
	private void logIn(C06CreateAccountRq messageRQ,C06CreateAccountRs messageRS, String originMsg, String convertMsg,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try {
			vpgTransLogInEntity = new VpgTransLogInEntity();
			
			vpgTransLogInEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogInEntity.setMsg_id(messageRQ.getSoCMND());
			vpgTransLogInEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1310);
			vpgTransLogInEntity.setPayment_channel(Constants.CHANNEL.INTERNET);
			
			
			vpgTransLogInEntity.setGateway_id(vpgMicroServiceParamsEntity.getGATEWAY_ID());
			vpgTransLogInEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogInEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			vpgTransLogInEntity.setTrans_direct(Constants.LOG_IN.TRANS_DIRECT);
			vpgTransLogInEntity.setTrans_type(Constants.LOG_IN.TRANS_TYPE);
			vpgTransLogInEntity.setService_code(Constants.SERVICE_CODE);
			
			
			vpgTransLogInEntity.setMsg_origin(originMsg);
			vpgTransLogInEntity.setMsg_convert(convertMsg);
			
			vpgTransLogInEntity.setError_code(messageRS.getTrangThai());
			vpgTransLogInEntity.setError_desc(messageRS.getMoTaLoi());
			
			
			vpgTransLogInEntity.setYear(CommonUtils.getYear());
			vpgTransLogInEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogInEntity.setDay(CommonUtils.getDayOfMonth());
			
			vpgTransLogInEntity.setPROCESS_TIME(this.processTime);
			vpgTransLogInEntity.setPROCESS_TIME_PRV(this.processTimePartner);
			vpgTransLogInEntity.setPROCESS_TIME_DB(processTimeDB);
			
			
			vpgTransLogInDAO = new VpgTransLogInDaoImpl();
			
			vpgTransLogInDAO.save(vpgTransLogInEntity);
		}catch(Exception e) {
			logger.error("logIn() is failed: " + e.getMessage());
		}
	}

	private void logInDetails(BeMessage1300 messageRQ,BeMessage1310 messageRS, String originMsg, String convertMsg,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity, String caching) {
		try {
			VpgTransDetailsInqCustInEntity vpgTransLogInEntity = new VpgTransDetailsInqCustInEntity();
			
			vpgTransLogInEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogInEntity.setMsg_id(messageRQ.getHeader().getMsgId());
			vpgTransLogInEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1310);
			vpgTransLogInEntity.setPayment_channel(messageRQ.getHeader().getChannelId());
			
			vpgTransLogInEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogInEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			vpgTransLogInEntity.setTrans_direct(Constants.LOG_IN.TRANS_DIRECT);
			vpgTransLogInEntity.setTrans_type(Constants.LOG_IN.TRANS_TYPE);
			vpgTransLogInEntity.setService_code(Constants.SERVICE_CODE);
			
			vpgTransLogInEntity.setTrans_id(messageRS.getData().getRecords().get(0).getTransId());
			vpgTransLogInEntity.setTrans_time(messageRS.getData().getRecords().get(0).getTransTime());
			
			vpgTransLogInEntity.setCustomer_code(messageRS.getData().getRecords().get(0).getCustCode());
			vpgTransLogInEntity.setCustomer_name(messageRS.getData().getRecords().get(0).getCustName());
			vpgTransLogInEntity.setEmail(messageRS.getData().getRecords().get(0).getEmail());
			vpgTransLogInEntity.setCustomer_phone(messageRS.getData().getRecords().get(0).getPhoneNo());
			
			vpgTransLogInEntity.setId_card_type(messageRS.getData().getRecords().get(0).getIdCardType());
			vpgTransLogInEntity.setId_card(messageRS.getData().getRecords().get(0).getIdCard());
			
			vpgTransLogInEntity.setStatus_code(messageRS.getData().getRecords().get(0).getStatus().getCode());
			vpgTransLogInEntity.setStatus_message(messageRS.getData().getRecords().get(0).getStatus().getMessage());
			
			
			vpgTransLogInEntity.setIs_caching(caching);
			
			vpgTransLogInEntity.setMsg_origin(originMsg);
			vpgTransLogInEntity.setMsg_convert(convertMsg);
			
			vpgTransLogInEntity.setError_code(messageRS.getData().getErrors().getErrorCode());
			vpgTransLogInEntity.setError_desc(messageRS.getData().getErrors().getErrorDesc());
			
			vpgTransLogInEntity.setAmount(messageRS.getData().getRecords().get(0).getAmount());
			
			vpgTransLogInEntity.setYear(CommonUtils.getYear());
			vpgTransLogInEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogInEntity.setDay(CommonUtils.getDayOfMonth());
			
			vpgTransLogInEntity.setPROCESS_TIME(this.processTime);
			vpgTransLogInEntity.setPROCESS_TIME_PRV(this.processTimePartner);
			vpgTransLogInEntity.setPROCESS_TIME_DB(processTimeDB);//Time db for msg request
			
			
			vpgTransDetailsInqCustInDAO = new VpgTransDetailsInqCustInDaoImpl();
			
			vpgTransLogInDAO.save(vpgTransLogInEntity);
			
			
		}catch(Exception e) {
			logger.error("logInDetails() is failed: " + e.getMessage());
		}
	}
	
	private ResponseEntity<String> callApi(String msg, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity ){
		try {
			
			VpgCallApiInterface vpgApi = VpgCallApiFactory.getApi(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			
			
			return (ResponseEntity<String>)vpgApi.callApi(msg,
					vpgMicroServiceParamsEntity.getURL_PARTNER(),
					Integer.parseInt(vpgMicroServiceParamsEntity.getURL_TIMEOUT()),
					vpgMicroServiceParamsEntity.getURL_HEADER(),
					vpgMicroServiceParamsEntity.getURL_ACTION(), 
					Integer.parseInt(vpgMicroServiceParamsEntity.getURL_TIMEOUT_SOCKET()), 
					vpgMicroServiceParamsEntity.getURL_METHOD());
		
		}catch(Exception e) {
			
			logger.error("callApi() is failed: " + e.getMessage());
			return null;
		}
		
	}
	
	private String signString(VpgMicroServiceParamsEntity config1, String dataSign, SecureInterface secure) {

		try {
			String signed = secure.signString(config1,dataSign);
	        
	        if(CommonUtils.isNullOrEmpty(signed)) {
	        	for(int i = 0; i < vpgMicroServiceParamsEntity.getHSM_SIGN_RETRY(); i++) {
	        		
	        		signed = secure.signString(config1,dataSign);
	        		
	        		if(!CommonUtils.isNullOrEmpty(signed)) {
	        			logger.info("Number of retry sign: "); 
	        			break;
	        		}else {
	        			try {
	        			Thread.sleep(vpgMicroServiceParamsEntity.getHSM_SIGN_RETRY_TIME());
	        			}catch(Exception e) {
	        				
	        			}
	        		}
	        	}
	        }
	        
	        return signed;
        
		}catch(Exception e) {
			
			logger.error("signString() is failed: " + e.getMessage());
			return "";
		}
	}
	
	public boolean verifyString(VpgMicroServiceParamsEntity config1, PrvMessage1310 message1310Prv, SecureInterface secure) {
		if(config1.getHSM_VERIFY_ENABLE().equalsIgnoreCase("1")) {
			try {
	    
	        
	        
	        bVerify = false;
	        
	        signed = message1310Prv.getHeader().getSignature();
	        dataSign = "";
	        dataSign += message1310Prv.getData().getErrors().getErrorCode();
	        
	        if( (message1310Prv.getData().getRecords() != null) &&  (message1310Prv.getData().getRecords().size()>0)) {
				for(int i = 0; i < message1310Prv.getData().getRecords().size(); i++) {
					dataSign += message1310Prv.getData().getRecords().get(i).getTransId()== null ? "" : message1310Prv.getData().getRecords().get(i).getTransId();
					dataSign += message1310Prv.getData().getRecords().get(i).getTransTime()== null ? "" : message1310Prv.getData().getRecords().get(i).getTransTime();
					dataSign += message1310Prv.getData().getRecords().get(i).getCustCode()== null ? "" : message1310Prv.getData().getRecords().get(i).getCustCode();
					dataSign += message1310Prv.getData().getRecords().get(i).getCustName()== null ? "" : message1310Prv.getData().getRecords().get(i).getCustName();
					dataSign += (message1310Prv.getData().getRecords().get(i).getStatus() == null ? "" : message1310Prv.getData().getRecords().get(i).getStatus().getCode());
				}
	        }
	        
	        bVerify = secure.verifyString(config1,dataSign, signed);
	        
	        
	        if(!bVerify) {
	        	for(int i = 0; i < config1.getHSM_VERIFY_RETRY(); i++) {
	        		
	        		
	        		bVerify = secure.verifyString(config1, dataSign, signed);
	        		
	        		if(bVerify) {
	        			logger.info("Number of retry verify: " + (i+1));
	        			break;
	        		}else {
	        			Thread.sleep(config1.getHSM_VERIFY_RETRY_TIME());
	        		}
	        	}
	        }
	        	
	        
	        return bVerify;
	        
			}catch (Exception e) {
				logger.error("Verify is failed! Exception = " + e.getMessage());
				return false;
			}
	        
	        
		}else {
			return true;
		}
	}

	@Override
	public C06KetQuaXacNhanARs ketquaxacnhananh(C06KetQuaXacNhanARq message1302,
			VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		
		try
		{
			this.processTimeStart = System.currentTimeMillis(); 
			
			switch(vpgMicroServiceParamsEntity.getCHANGE_FORMAT().trim()) {
			
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_0:{
					
					
					break;
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_1:{
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1302);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					message1302Prv = (C06KetQuaXacNhanARq) pkgMsgInterface.packageMessage(message1302, null, null, vpgMicroServiceParamsEntity);
					
					
					if(message1302Prv == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PKG.CODE,
								Constants.VPG_STATUS_ERR_PKG.DESC);
					}
					
					
					if(vpgMicroServiceParamsEntity.getHSM_ENABLE().equals(VPG_STATUS.ENABLE)){
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.HSM);
						
					}else
					{
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.VPG);
					}
					
					secureInterface = (SecureInterface) secureAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID().trim());//
					
					
					
					msgRq = ConvertJsonToObject.objectToJson(message1302Prv,true);
			        
			        this.processTimeDBStart = System.currentTimeMillis();
			        try {
			        	msgRq = ConvertJsonToObject.objectToJson(message1302Prv,true);
			        }catch(Exception e) {
			        	
			        	logger.error("logOut() is failed. Message request: " + msgRq + "; Exception: " + e.getMessage());
			        	
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);
						
						return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_DB.CODE,
								Constants.VPG_STATUS_ERR_DB.DESC);
			        }
			        
			        this.processTimeDBEnd = System.currentTimeMillis();
			        
			        this.processTimeDB = this.processTimeDBEnd - this.processTimeDBStart;
			        
			         
			      			        
			        this.processTimePartnerStart = System.currentTimeMillis();
					
					ResponseEntity<String> result = callApi(msgRq,vpgMicroServiceParamsEntity);
					
					this.processTimePartnerEnd = System.currentTimeMillis();
					
					this.processTimePartner = this.processTimePartnerEnd - this.processTimePartnerStart;
					
					if(result == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);
						
						return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.CODE,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.DESC);
					}
					
					msgRs = result.getBody();
					logger.info("Respose from Partner : " + msgRs);
					
					httpStatus = result.getStatusCodeValue();
					
					if(httpStatus != 200) {
						switch (httpStatus)
						{
							case 400:
							{
								messageErrorPrv = ConvertJsonToObject.jsonToObject(msgRs, MessageErrorPrv.class);
								
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);
								
								return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
										messageErrorPrv.getCode(),
										messageErrorPrv.getMessage(),
										Constants.VPG_STATUS_ERR_PARSE.CODE,
										Constants.VPG_STATUS_ERR_PARSE.DESC);
								
								
							}
							case 500:
							{
								
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);
								
								return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
										String.valueOf(result.getStatusCodeValue()),
										result.getBody(),
										Constants.VPG_STATUS_ERR_GENERAL.CODE,
										Constants.VPG_STATUS_ERR_GENERAL.DESC);
							}
							default: {
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);
								
								return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
										String.valueOf(result.getStatusCodeValue()),
										result.getBody(),
										Constants.VPG_STATUS_ERR_GENERAL.CODE,
										Constants.VPG_STATUS_ERR_GENERAL.DESC);
							}
							
						}
					}
					
					
					message1312Prv = ConvertJsonToObject.jsonToObject(msgRs, C06KetQuaXacNhanRsBackend.class, true);
					
					if(message1312Prv == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1312);
						
						return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PARSE.CODE,
								Constants.VPG_STATUS_ERR_PARSE.DESC);
					}
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1312);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					messageKQXNRS = (C06KetQuaXacNhanARs) pkgMsgInterface.packageMessage(message1302, message1312Prv, null, vpgMicroServiceParamsEntity);
					
					
					jsonRs = ConvertJsonToObject.objectToJson(messageKQXNRS);
					
					this.processTimeEnd = System.currentTimeMillis();
					this.processTime = this.processTimeEnd - this.processTimeStart;
					
					
					break;
					
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_2:{
					break;
				}
				
				default:{
					break;
				}
				
			}
		
			return messageKQXNRS;
			
		}catch(Exception e) {
			logger.error("notifyTrans() is failed. SOA request: " + msgRq
					+ "; Message response origin: " +  msgRs
					+ "; Message response: " +  jsonRs 
					+ "; Exception: " + e.getMessage());
			
			
			vpgMessageErrorFactory = new VpgMessageErrorFactory();
			
			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
			
			return (C06KetQuaXacNhanARs) vpgMessageErrorInterface.getMessageError(message1302,
					Constants.PRV_STATUS_ERR_GENERAL.CODE,
					Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE,
					Constants.VPG_STATUS_ERR_GENERAL.DESC);
			
		}
		finally {
			messageRQ = null;
			vpgTransLogOutDAO 	= null;
			vpgTransLogOutEntity = null;
			vpgTransLogInDAO 	= null;
			vpgTransLogInEntity = null;
			messageRS = null;
			data = null;
			header  = null;
			
			
			
			errors = null;
			message1302 = null;
			header1300Prv = null;
			data1300Prv = null;
			
			lstRecord1300Prv = null;
			record1300Prv = null;
			lstRecord1310 = null;
			record1310 = null;
			
			rootNode = null;
			type = null;
			vpgMessageErrorFactory = null;
			vpgMessageErrorInterface = null;
			messageErrorPrv = null;
			secureAbstractFactory = null;
			secureInterface = null;
		}
	}

	
	
}

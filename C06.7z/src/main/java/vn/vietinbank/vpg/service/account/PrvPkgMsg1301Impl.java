package vn.vietinbank.vpg.service.account;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.account.C06CreateAccountRq;
import vn.vietinbank.vpg.model.account.C06CreateAccountRqBackend;
import vn.vietinbank.vpg.model.account.C06CreateAccountRs;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.PrvData1300;
import vn.vietinbank.vpg.model.inqcust.PrvHeader1300;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1300;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1310;
import vn.vietinbank.vpg.model.inqcust.PrvRecord1300;
import vn.vietinbank.vpg.service.PkgMsgInterface;

public class PrvPkgMsg1301Impl implements PkgMsgInterface<C06CreateAccountRq,C06CreateAccountRs,ResponseEntity<String>,C06CreateAccountRqBackend> {

	private static final Logger logger = LoggerFactory.getLogger(PrvPkgMsg1301Impl.class);
	
	C06CreateAccountRqBackend msg1300 = null;
	PrvHeader1300 header1300 = null;
	PrvData1300 data1300 = null;
	List<PrvRecord1300> lstRecord1300 = null;
	PrvRecord1300 record1300 = null;
	
	
	@Override
	public C06CreateAccountRqBackend packageMessage(C06CreateAccountRq beMessageRq, C06CreateAccountRs tcbsMessageRs,
			ResponseEntity<String> result, VpgMicroServiceParamsEntity config1) {
		try {
			msg1300 = new C06CreateAccountRqBackend();
			
			msg1300.setMaGiaoDich("EID"+System.currentTimeMillis() ); 
			msg1300.setProviderId("C06");
			msg1300.setMerchantId("GTEL");
			msg1300.setChannel("WEB");
			msg1300.setVersion("");
			SimpleDateFormat formatter= new SimpleDateFormat("yyyyMMddHHmmss");
			Date date = new Date(System.currentTimeMillis());
			msg1300.setNgaygioGiaoDich(formatter.format(date));
			msg1300.setHoTenCongDan(beMessageRq.getHoTenCongDan());
			msg1300.setNgayThangNamSinh(beMessageRq.getNgayThangNamSinh());
			msg1300.setNoiSinh(beMessageRq.getNoiSinh());
			msg1300.setGioiTinh(beMessageRq.getGioiTinh());
			msg1300.setQuocTich(beMessageRq.getQuocTich());
			msg1300.setSoDinhDanh(beMessageRq.getSoDinhDanh());
			msg1300.setNgayCap(beMessageRq.getNgayCap());
			msg1300.setNoiCap(beMessageRq.getNoiCap());
			msg1300.setSoDienThoai(beMessageRq.getSoDienThoai());
			msg1300.setDiaChiThuongTru(beMessageRq.getDiaChiThuongTru());
			msg1300.setMaThuongTruTinh(beMessageRq.getMaThuongTruTinh());
			msg1300.setNoiOHienTai(beMessageRq.getNoiOHienTai()) ;
			msg1300.setMaNoiOHienTaiTinh(beMessageRq.getNoiOHienTai());
			msg1300.setMaNoiOHienTaiHuyen(beMessageRq.getMaNoiOHienTaiHuyen());
			msg1300.setSoCMND(beMessageRq.getSoCMND());
			msg1300.setDiaChiGiaoDich(beMessageRq.getDiaChiGiaoDich());
			msg1300.setMaDiaDiem(beMessageRq.getMaDiaDiem());
			msg1300.setAnhChanDung(beMessageRq.getAnhChanDung());
			msg1300.setNgayHetHan(beMessageRq.getNgayCap());
			msg1300.setEmail("");
			return msg1300;
			}catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}finally {
				msg1300 = null;
				header1300 = null;
				data1300 = null;
				lstRecord1300 = null;
				record1300 = null;
				
			}
	}
}

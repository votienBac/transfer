package vn.vietinbank.vpg.service.account;

import java.net.URI;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import javax.wsdl.Message;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import org.springframework.web.client.RestTemplate;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;

import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.account.C06CreateAccountRq;
import vn.vietinbank.vpg.model.account.C06CreateAccountRs;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARq;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARs;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanRsBackend;
import vn.vietinbank.vpg.model.inqcust.BeData1310;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.BeMessage1310;
import vn.vietinbank.vpg.model.inqcust.BeRecord1310;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1310;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.LOG_OUT;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;


public class PrvPkgMsg1312Impl implements PkgMsgInterface<C06KetQuaXacNhanARq,C06KetQuaXacNhanRsBackend,ResponseEntity<String>,C06KetQuaXacNhanARs> {

	private static final Logger logger = LoggerFactory.getLogger(PrvPkgMsg1312Impl.class);
	
	C06KetQuaXacNhanARs msg1312 = null;
	Header header1310 = null;
	BeData1310 data1310 = null;
	List<BeRecord1310> lstRecord1310 = null;
	BeRecord1310 record1310 = null;
	Status status1310 = null;
	String errCode = "";
	
	@Override
	public C06KetQuaXacNhanARs packageMessage(C06KetQuaXacNhanARq beMessageRq, C06KetQuaXacNhanRsBackend tcbsMessageRs,
			ResponseEntity<String> result,  VpgMicroServiceParamsEntity config1) {
		try {
			
			msg1312= new C06KetQuaXacNhanARs() ;
			msg1312.setMoTaLoi( tcbsMessageRs.getStatus().getMessage()); 
			msg1312.setTrangThai(tcbsMessageRs.getStatus().getCode());
			return msg1312;
		
			}catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}finally {
				msg1312 = null;
				header1310 = null;
				data1310 = null;
				lstRecord1310 = null;
				record1310 = null;
				status1310 = null;
			}
	}
}

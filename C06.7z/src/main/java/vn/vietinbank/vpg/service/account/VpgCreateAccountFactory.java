package vn.vietinbank.vpg.service.account;

import vn.vietinbank.vpg.service.VpgMessageAbstractFactory;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;


public class VpgCreateAccountFactory implements VpgMessageAbstractFactory<VpgCreateAccountInterface> {

	@Override
	public VpgCreateAccountInterface create(String provider) {
	
		try {
			switch(provider) {
			
			case PROVIDER_ID.BCA_C06:{
				return new PrvCreateAccountImpl();
			}
			default:{
				return new PrvCreateAccountImpl();
			}
			
			}
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	public VpgCreateAccountInterface create(String formatType, String provider) {
		return null;
	}

	
}

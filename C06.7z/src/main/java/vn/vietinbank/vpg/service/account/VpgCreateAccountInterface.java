package vn.vietinbank.vpg.service.account;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.account.C06CreateAccountRq;
import vn.vietinbank.vpg.model.account.C06CreateAccountRs;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARq;
import vn.vietinbank.vpg.model.account.C06KetQuaXacNhanARs;
import vn.vietinbank.vpg.model.inqcust.*;


public interface VpgCreateAccountInterface {

	C06CreateAccountRs processMessage(C06CreateAccountRq message1301,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity);
	C06KetQuaXacNhanARs ketquaxacnhananh(C06KetQuaXacNhanARq message1302,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity);
				
}

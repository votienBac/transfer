package vn.vietinbank.vpg.service.callapi;

import vn.vietinbank.vpg.util.Constants.EKYC_PROVIDER;
import vn.vietinbank.vpg.util.Constants.MESSAGE_TYPE;


public interface VpgCallApiAbstractFactory {
	
	public VpgCallApiInterface create();
	
}

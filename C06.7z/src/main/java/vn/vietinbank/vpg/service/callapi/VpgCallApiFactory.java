package vn.vietinbank.vpg.service.callapi;

import vn.vietinbank.vpg.util.Constants.EKYC_PROVIDER;
import vn.vietinbank.vpg.util.Constants.MESSAGE_TYPE;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;


public class VpgCallApiFactory {

	public static VpgCallApiInterface getApi(String provider) {
		try {
		switch (provider)
		{
		
			
			default:{
				return new VpgCallApiPrvImpl();
			}
		
		}
		}catch(Exception e) {
			return null;
		}
		
	}
	
	
}

package vn.vietinbank.vpg.service.callapi;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public interface VpgCallApiInterface <T> {

	T callApi(
			String msg,
			String baseUrl,			
			int timeout,
			String headers,
			String action,
			int timeoutSocket,
			String method);
			
}

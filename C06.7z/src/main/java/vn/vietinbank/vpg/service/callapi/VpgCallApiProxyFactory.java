package vn.vietinbank.vpg.service.callapi;

import vn.vietinbank.vpg.util.Constants.EKYC_PROVIDER;
import vn.vietinbank.vpg.util.Constants.MESSAGE_TYPE;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;


public class VpgCallApiProxyFactory {

	@SuppressWarnings("rawtypes")
	public static VpgCallApiProxyInterface getApi(String provider) {
		try {
		switch (provider)
		{

			case PROVIDER_ID.PRV_001:{
				return new VpgCallApiProxyImpl();
			}
			

			default:{
				return new VpgCallApiProxyImpl();
			}
		
		}
		}catch(Exception e) {
			return null;
		}
		
	}
	
	
}

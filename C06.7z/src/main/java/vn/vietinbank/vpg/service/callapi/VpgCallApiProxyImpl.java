package vn.vietinbank.vpg.service.callapi;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.HttpHeader;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.Constants.HTTP_METHOD;

public class VpgCallApiProxyImpl implements VpgCallApiProxyInterface<ResponseEntity<String>> {

	private static final Logger logger = LoggerFactory.getLogger(VpgCallApiProxyImpl.class);

	RestTemplate restTemplate = null;
	HttpHeaders httpHeaders = null;
	HttpMethod httpMethod = null;
	HttpEntity<String> request = null;
	URI uri = null;

	HttpHeader httpHeader = null;

	public VpgCallApiProxyImpl() {
		super();
		
	}

	private static class ServiceHelper {

		private static final VpgCallApiProxyImpl INSTANCE = new VpgCallApiProxyImpl();
	}

	public static VpgCallApiProxyImpl getInstance() {
		return ServiceHelper.INSTANCE;
	}

	StringBuilder URL = null;

	@Override
	public ResponseEntity<String> callApi(String msg, String baseUrl, int timeout, String headers, String action,
			int timeoutSocket, String method, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		
		try {
			if (CommonUtils.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(), "is_proxy")
					.equals("1")) {
				
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
						CommonUtils.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(), "proxy_ip"),
						Integer.parseInt(CommonUtils
								.getConfigParamsByKey(vpgMicroServiceParamsEntity.getCONFIG_PARAMS(), "proxy_port"))));
				restTemplate = new RestTemplate(getClientHttpRequestFactory(timeout, proxy));
			} else {
				restTemplate = new RestTemplate(getClientHttpRequestFactory(timeout));
			}

			URL = new StringBuilder();
			URL.append(baseUrl.trim());

			logger.info("URL: " + URL);

			uri = new URI(URL.toString());

			if (!CommonUtils.isNullOrEmpty(headers)) {

				httpHeaders = new HttpHeaders();

				httpHeader = ConvertJsonToObject.jsonToObject(headers, HttpHeader.class);

				httpHeader.getPropertiesHeader().forEach((e) -> {
					httpHeaders.add(e.getTagName(), e.getValue());
				});
			}


			request = new HttpEntity<>(msg, httpHeaders);

			switch (method.toUpperCase()) {
			case HTTP_METHOD.HTTP_POST: {
				httpMethod = HttpMethod.POST;
				break;
			}
			case HTTP_METHOD.HTTP_GET: {
				httpMethod = HttpMethod.GET;
				break;
			}
			case HTTP_METHOD.HTTP_PUT: {
				httpMethod = HttpMethod.PUT;
				break;
			}
			case HTTP_METHOD.HTTP_PATCH: {
				httpMethod = HttpMethod.PATCH;
				break;
			}
			default: {
				httpMethod = HttpMethod.POST;
				break;
			}

			}

			return restTemplate.exchange(uri, httpMethod, request, String.class);

		} catch (HttpClientErrorException e)
		{
			e.printStackTrace();
			logger.error("URL is failed: " + URL);
			logger.error("Call api is failed: " + e.getMessage());
			logger.error("Message is failed: " + msg);

			return ResponseEntity.status(e.getStatusCode()).body(e.getResponseBodyAsString());

		} catch (Exception e)
		{
			e.printStackTrace();
			logger.error("URL is failed: " + URL);
			logger.error("Call api is failed: " + e.getMessage());
			logger.error("Message is failed: " + msg);

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());

		}

	}

	
	private SimpleClientHttpRequestFactory getClientHttpRequestFactory(int timeout) {
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();

	
		clientHttpRequestFactory.setConnectTimeout(timeout);

	
		clientHttpRequestFactory.setReadTimeout(timeout);
		return clientHttpRequestFactory;
	}

	
	private SimpleClientHttpRequestFactory getClientHttpRequestFactory(int timeout, Proxy proxy) {
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();

	
		clientHttpRequestFactory.setProxy(proxy);

	
		clientHttpRequestFactory.setConnectTimeout(timeout);

	
		clientHttpRequestFactory.setReadTimeout(timeout);
		return clientHttpRequestFactory;
	}

}

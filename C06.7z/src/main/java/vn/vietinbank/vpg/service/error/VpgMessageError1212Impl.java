package vn.vietinbank.vpg.service.error;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;

import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.Errors;
import vn.vietinbank.vpg.model.notifystatus.BeData1212;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;




public class VpgMessageError1212Impl implements VpgMessageErrorInterface <BeMessage1212, BeMessage1202> {

	private static final Logger logger = LoggerFactory.getLogger(VpgMessageError1212Impl.class);	
	
	public VpgMessageError1212Impl() {
		
	}

	private static class ServiceHelper{
		
		private static final VpgMessageError1212Impl INSTANCE = new VpgMessageError1212Impl();
	}
	
	public static VpgMessageError1212Impl getInstance()
	{
		return ServiceHelper.INSTANCE;
	}
	
	@Override
	public BeMessage1212 getMessageError(BeMessage1202 messageRQ, String errorCode, String errorDesc,String errorCodeVPG, String errorDescVPG) {
		
		try
		{
			BeMessage1212 messageRS = new BeMessage1212();
						
			messageRS.setHeader(messageRQ.getHeader());
			
			messageRS.getHeader().setMsgType(VPG_MSG_TYPE.MSG_TYPE_1212);
			
			BeData1212 data = new BeData1212();
			
			vn.vietinbank.vpg.model.Errors errors = new vn.vietinbank.vpg.model.Errors();
			
			errors.setErrorCode(errorCode);
			
			errors.setErrorDesc(errorDesc);
			
			errors.setErrorCodeVPG(errorCodeVPG);
			
			errors.setErrorDescVPG(errorDescVPG);
			
			data.setErrors(errors);
			
			messageRS.setData(data);
			
			return messageRS;
			
		}catch(Exception e) {
			logger.error("getMessageError() is failed! ERR: " + e.getMessage());
			return null;
		}
	}

	
	
}

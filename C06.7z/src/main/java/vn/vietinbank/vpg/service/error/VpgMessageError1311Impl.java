package vn.vietinbank.vpg.service.error;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;

import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.Errors;
import vn.vietinbank.vpg.model.account.C06CreateAccountRq;
import vn.vietinbank.vpg.model.account.C06CreateAccountRs;
import vn.vietinbank.vpg.model.notifystatus.BeData1212;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;




public class VpgMessageError1311Impl implements VpgMessageErrorInterface <C06CreateAccountRs, C06CreateAccountRq> {

	private static final Logger logger = LoggerFactory.getLogger(VpgMessageError1311Impl.class);	
	
	public VpgMessageError1311Impl() {
		
	}

	private static class ServiceHelper{
		
		private static final VpgMessageError1311Impl INSTANCE = new VpgMessageError1311Impl();
	}
	
	public static VpgMessageError1311Impl getInstance()
	{
		return ServiceHelper.INSTANCE;
	}
	
	@Override
	public C06CreateAccountRs getMessageError(C06CreateAccountRq messageRQ, String errorCode, String errorDesc,String errorCodeVPG, String errorDescVPG) {
		
		try
		{
			C06CreateAccountRs messageRS = new C06CreateAccountRs();
			messageRS.setMoTaLoi("Khong truyen gia tri Header");	
			messageRS.setTrangThai("01");
			
			return messageRS;
			
		}catch(Exception e) {
			logger.error("getMessageError() is failed! ERR: " + e.getMessage());
			return null;
		}
	}

	
	
}

package vn.vietinbank.vpg.service.error;


import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.service.VpgMessageAbstractFactory;
import vn.vietinbank.vpg.service.inqcust.VpgInqCustFactory;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.EKYC_PROVIDER;
import vn.vietinbank.vpg.util.Constants.MESSAGE_TYPE;


public class VpgMessageErrorFactory implements VpgMessageAbstractFactory<VpgMessageErrorInterface> {

	
	@Override
	public VpgMessageErrorInterface create(String messageType) {
		
		try {
			switch (messageType)
			{
				case Constants.VPG_MSG_TYPE.MSG_TYPE_1116:
					return new VpgMessageError1212Impl();
				case Constants.VPG_MSG_TYPE.MSG_TYPE_1117:
					return new VpgMessageError1212Impl();
				case Constants.VPG_MSG_TYPE.MSG_TYPE_1118:
					return new VpgMessageError1212Impl();
				case Constants.VPG_MSG_TYPE.MSG_TYPE_1119:
					return new VpgMessageError1212Impl();
					
				case Constants.VPG_MSG_TYPE.MSG_TYPE_1311:
					return new VpgMessageError1311Impl();
				default:
					throw new IllegalArgumentException("The message type " + messageType + " is not support!");
			
			}
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	public VpgMessageErrorInterface create(String formatType, String provider) {
		
		return null;
	}

	
	
}

package vn.vietinbank.vpg.service.error;

public interface VpgMessageErrorInterface <T1,T2> {

	T1 getMessageError(T2 messageRQ, String errorCode, String errorDesc, String errorCodeVPG, String errorDescVPG);
	
}

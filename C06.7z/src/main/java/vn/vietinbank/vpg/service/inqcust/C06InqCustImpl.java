package vn.vietinbank.vpg.service.inqcust;

import java.util.ArrayList;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoImpl;
import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;
import vn.vietinbank.vpg.model.Errors;
import vn.vietinbank.vpg.model.Header;
import vn.vietinbank.vpg.model.HttpHeader;
import vn.vietinbank.vpg.model.PropertiesHeader;
import vn.vietinbank.vpg.model.Status;
import vn.vietinbank.vpg.model.inqcust.BeData1310;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.BeMessage1310;
import vn.vietinbank.vpg.model.inqcust.BeRecord1310;
import vn.vietinbank.vpg.model.inqcust.C06Message1300;
import vn.vietinbank.vpg.model.inqcust.C06Message1310;
import vn.vietinbank.vpg.security.SecureAbstractFactory;
import vn.vietinbank.vpg.security.SecureFactory;
import vn.vietinbank.vpg.security.SecureInterface;
import vn.vietinbank.vpg.service.PkgMsgAbstractFactory;
import vn.vietinbank.vpg.service.PkgMsgFactory;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.service.callapi.VpgCallApiFactory;
import vn.vietinbank.vpg.service.callapi.VpgCallApiInterface;
import vn.vietinbank.vpg.service.error.VpgMessageErrorFactory;
import vn.vietinbank.vpg.service.error.VpgMessageErrorInterface;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.dao.*;


public class C06InqCustImpl implements VpgInqCustInterface {

	private static final Logger logger = LoggerFactory.getLogger(C06InqCustImpl.class);
	
	private BeMessage1300 messageRQ = null;
	private VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity;
	
	VpgTransLogOutDaoInterface vpgTransLogOutDAO 	= null;
	VpgTransLogOutEntity vpgTransLogOutEntity = null;
	
	VpgTransLogInDaoInterface vpgTransLogInDAO 	= null;
	VpgTransLogInEntity vpgTransLogInEntity = null;
	
	BeMessage1310 messageRS = null;
	BeData1310 data = null;
	vn.vietinbank.vpg.model.Header header  = null;
	
	String msgRq = "";
	String msgRs = "";
	
	String dataSign = "";
	String signed = "";
	boolean bVerify = false;	
	
	vn.vietinbank.vpg.model.Errors errors = null;
	String jsonRs = "";
	
	Long processTimeStart;
	Long processTimeEnd;
	Long processTime;
	
	Long processTimePartnerStart;
	Long processTimePartnerEnd;
	Long processTimePartner;
	
	Long processTimeDBStart;
	Long processTimeDBEnd;
	Long processTimeDB;
	
	C06Message1300 message1300CTS = null;
	
	C06Message1310 message1310CTS = null;
	
	List<BeRecord1310>  lstRecord1310 = null;
	BeRecord1310  record1310 = null;
	
	JsonNode rootNode = null;
	JsonNode type = null;
	
	
	VpgMessageErrorFactory vpgMessageErrorFactory = null;
	VpgMessageErrorInterface vpgMessageErrorInterface;
	
	int httpStatus = 200;
	
	SecureAbstractFactory secureAbstractFactory = null;
	SecureInterface secureInterface = null;
	String errCode = "";
	
	PkgMsgAbstractFactory pkgMsgAbstractFactory = null;
	PkgMsgInterface pkgMsgInterface = null;
	
	
	public C06InqCustImpl() {
		
	}
	
	@Override
	public BeMessage1310 processMessage(BeMessage1300 message1300,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try
		{
			this.processTimeStart = System.currentTimeMillis(); 
			
			
			switch(vpgMicroServiceParamsEntity.getCHANGE_FORMAT().trim()) {
			
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_0:{
					
					
					break;
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_1:{
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1300);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					message1300CTS = (C06Message1300) pkgMsgInterface.packageMessage(message1300, null, null,vpgMicroServiceParamsEntity);
					
					
					if(message1300CTS == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (BeMessage1310) vpgMessageErrorInterface.getMessageError(message1300,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PKG.CODE,
								Constants.VPG_STATUS_ERR_PKG.DESC);
					}
					
					if(vpgMicroServiceParamsEntity.getHSM_ENABLE().equals(VPG_STATUS.ENABLE)){
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.HSM);
						
					}else
					{
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.VPG);
					}
					
					secureInterface = (SecureInterface) secureAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID().trim());//
					
					
					
					msgRq = ConvertJsonToObject.objectToJson(message1300CTS);
					logger.error("Input: " +msgRq);
			        
			        this.processTimeDBStart = System.currentTimeMillis();
			        
			        try {
			        	logOut(message1300,ConvertJsonToObject.objectToJson(message1300),msgRq,vpgMicroServiceParamsEntity);
			        }catch(Exception e) {
			        	
			        	logger.error("logOut() is failed. Message request: " + msgRq + "; Exception: " + e.getMessage());
			        	
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (BeMessage1310) vpgMessageErrorInterface.getMessageError(message1300,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_DB.CODE,
								Constants.VPG_STATUS_ERR_DB.DESC);
			        }
			        
			        this.processTimeDBEnd = System.currentTimeMillis();
			        
			        this.processTimeDB = this.processTimeDBEnd - this.processTimeDBStart;
			        
			        
			        this.processTimePartnerStart = System.currentTimeMillis();
					
					ResponseEntity<String> result = callApi(msgRq,vpgMicroServiceParamsEntity);
					
					this.processTimePartnerEnd = System.currentTimeMillis();
					
					this.processTimePartner = this.processTimePartnerEnd - this.processTimePartnerStart;
					
					if(result == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (BeMessage1310) vpgMessageErrorInterface.getMessageError(message1300,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.CODE,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.DESC);
					}
					
					msgRs = result.getBody();
					logger.error("Ouput: " +msgRs);
					
					httpStatus = result.getStatusCodeValue();
				
					message1310CTS = ConvertJsonToObject.jsonToObject(msgRs, C06Message1310.class);
					
					if(message1310CTS == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
						
						return (BeMessage1310) vpgMessageErrorInterface.getMessageError(message1300,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PARSE.CODE,
								Constants.VPG_STATUS_ERR_PARSE.DESC);
					}
						if(vpgMicroServiceParamsEntity.getHSM_VERIFY_ENABLE().equals(VPG_STATUS.ENABLE)) {
						
						
						bVerify = this.verifyString(vpgMicroServiceParamsEntity,msgRs, secureInterface);
						
						if(bVerify == false) {
							
							logger.error("Verify message is failed! Message = " + msgRs);
							
							vpgMessageErrorFactory = new VpgMessageErrorFactory();
							
							vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
							
							return (BeMessage1310) vpgMessageErrorInterface.getMessageError(message1300,
									Constants.PRV_STATUS_ERR_GENERAL.CODE,
									Constants.PRV_STATUS_ERR_GENERAL.DESC,
									Constants.VPG_STATUS_ERR_VERIFY.CODE,
									Constants.VPG_STATUS_ERR_VERIFY.DESC);
						}
					}
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1310);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					messageRS = (BeMessage1310) pkgMsgInterface.packageMessage(message1300, message1310CTS, null,vpgMicroServiceParamsEntity);
					
					
					jsonRs = ConvertJsonToObject.objectToJson(messageRS);
					
					this.processTimeEnd = System.currentTimeMillis();
					this.processTime = this.processTimeEnd - this.processTimeStart;
					
					logIn(message1300,messageRS,result.getBody(),jsonRs,vpgMicroServiceParamsEntity);
					
					break;
					
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_2:{
					break;
				}
				
				default:{
					break;
				}
				
			}
		
			return messageRS;
			
		}catch(Exception e) {
			logger.error("notifyTrans() is failed. SOA request: " + msgRq
					+ "; Message response origin: " +  msgRs
					+ "; Message response: " +  jsonRs 
					+ "; Exception: " + e.getMessage());
			
			vpgMessageErrorFactory = new VpgMessageErrorFactory();
			
			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1310);
			
			return (BeMessage1310) vpgMessageErrorInterface.getMessageError(message1300,
					Constants.PRV_STATUS_ERR_GENERAL.CODE,
					Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE,
					Constants.VPG_STATUS_ERR_GENERAL.DESC);
			
		}
		finally {
			messageRQ = null;
			
			vpgTransLogOutDAO 	= null;
			vpgTransLogOutEntity = null;
			vpgTransLogInDAO 	= null;
			vpgTransLogInEntity = null;
			messageRS = null;
			data = null;
			header  = null;
			
			
			errors = null;
			message1300CTS = null;
			
			message1310CTS = null;
			lstRecord1310 = null;
			record1310 = null;
			
			rootNode = null;
			type = null;
			vpgMessageErrorFactory = null;
			vpgMessageErrorInterface = null;
			secureAbstractFactory = null;
			secureInterface = null;
		}
		
	}
	
	
	
	
	
	
	private void logOut(BeMessage1300 messageRQ,String originMsg, String convertMsg, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try {
			vpgTransLogOutEntity = new VpgTransLogOutEntity();
			
			vpgTransLogOutEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogOutEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1300);
			
			
			vpgTransLogOutEntity.setGateway_id(vpgMicroServiceParamsEntity.getGATEWAY_ID());
			vpgTransLogOutEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogOutEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			
			vpgTransLogOutEntity.setTrans_direct(Constants.LOG_OUT.TRANS_DIRECT);
			vpgTransLogOutEntity.setTrans_type(Constants.LOG_OUT.TRANS_TYPE);
			vpgTransLogOutEntity.setService_code(Constants.SERVICE_CODE);
			
			
			vpgTransLogOutEntity.setMsg_origin(originMsg);
			vpgTransLogOutEntity.setMsg_convert(convertMsg);
			
			vpgTransLogOutEntity.setYear(CommonUtils.getYear());
			vpgTransLogOutEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogOutEntity.setDay(CommonUtils.getDayOfMonth());
			
			
			vpgTransLogOutDAO = new VpgTransLogOutDaoImpl();
			
			vpgTransLogOutDAO.save(vpgTransLogOutEntity);
		}catch(Exception e) {
			logger.error("logOut() is failed: " + e.getMessage());
		}
	}
	
	private void logIn(BeMessage1300 messageRQ,BeMessage1310 messageRS, String originMsg, String convertMsg,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try {
			vpgTransLogInEntity = new VpgTransLogInEntity();
			
			vpgTransLogInEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogInEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1310);
			
			vpgTransLogInEntity.setGateway_id(vpgMicroServiceParamsEntity.getGATEWAY_ID());
			vpgTransLogInEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogInEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			vpgTransLogInEntity.setTrans_direct(Constants.LOG_IN.TRANS_DIRECT);
			vpgTransLogInEntity.setTrans_type(Constants.LOG_IN.TRANS_TYPE);
			vpgTransLogInEntity.setService_code(Constants.SERVICE_CODE);
			
			vpgTransLogInEntity.setMsg_origin(originMsg);
			vpgTransLogInEntity.setMsg_convert(convertMsg);
			
			vpgTransLogInEntity.setError_code(messageRS.getData().getErrors().getErrorCode());
			vpgTransLogInEntity.setError_desc(messageRS.getData().getErrors().getErrorDesc());
			
			vpgTransLogInEntity.setYear(CommonUtils.getYear());
			vpgTransLogInEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogInEntity.setDay(CommonUtils.getDayOfMonth());
			
			vpgTransLogInEntity.setPROCESS_TIME(this.processTime);
			vpgTransLogInEntity.setPROCESS_TIME_PRV(this.processTimePartner);
			vpgTransLogInEntity.setPROCESS_TIME_DB(processTimeDB);
			
			
			
			vpgTransLogInDAO = new VpgTransLogInDaoImpl();
			
			vpgTransLogInDAO.save(vpgTransLogInEntity);
		}catch(Exception e) {
			logger.error("logIn() is failed: " + e.getMessage());
		}
	}

	private ResponseEntity<String> callApi(String msg, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity ){
		try {
			
			VpgCallApiInterface vpgApi = VpgCallApiFactory.getApi(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			
			
			return (ResponseEntity<String>)vpgApi.callApi(msg,
					vpgMicroServiceParamsEntity.getURL_PARTNER(),
					Integer.parseInt(vpgMicroServiceParamsEntity.getURL_TIMEOUT()),
					vpgMicroServiceParamsEntity.getURL_HEADER(),
					vpgMicroServiceParamsEntity.getURL_ACTION(), 
					Integer.parseInt(vpgMicroServiceParamsEntity.getURL_TIMEOUT_SOCKET()), 
					vpgMicroServiceParamsEntity.getURL_METHOD());
			
			
		}catch(Exception e) {
			
			logger.error("callApi() is failed: " + e.getMessage());
			return null;
		}
		
	}
	
	private String signString(VpgMicroServiceParamsEntity config1, String dataSign, SecureInterface secure) {

		try {
		    
	        
			String signed = secure.signString(config1,dataSign);
	        
	        if(CommonUtils.isNullOrEmpty(signed)) {//neu ky loi thi thuc hien lai theo so lan cau hinh
	        	for(int i = 0; i < vpgMicroServiceParamsEntity.getHSM_SIGN_RETRY(); i++) {
	        		
	        		signed = secure.signString(config1,dataSign);
	        		
	        		if(!CommonUtils.isNullOrEmpty(signed)) {
	        			logger.info("Number of retry sign: "); //+ (i+1));
	        			break;
	        		}else {
	        			try {
	        			Thread.sleep(vpgMicroServiceParamsEntity.getHSM_SIGN_RETRY_TIME());
	        			}catch(Exception e) {
	        				
	        			}
	        		}
	        	}
	        }
	        
	        return signed;
        
		}catch(Exception e) {
			
			logger.error("signString() is failed: " + e.getMessage());
			return "";
		}
	}
	
	public boolean verifyString(VpgMicroServiceParamsEntity config1, String msg, SecureInterface secure) {
		if(config1.getHSM_VERIFY_ENABLE().equalsIgnoreCase("1")) {
			try {
	        
			rootNode = new ObjectMapper().readTree(msg);
			
			type = rootNode.path("data");
	 		
			dataSign = type.toString();
			
	        logger.info("Data for sign: " + dataSign);
	        
	        type = rootNode.path("header").path("signature");
	        
	        signed = type.asText();
	        
	        
	        
	        bVerify = false;
	        
	        
	        bVerify = secure.verifyString(config1,dataSign, signed);
	        
	        
	        if(!bVerify) {
	        	for(int i = 0; i < config1.getHSM_VERIFY_RETRY(); i++) {
	        		
	        		
	        		bVerify = secure.verifyString(config1, dataSign, signed);
	        		
	        		if(bVerify) {
	        			logger.info("Number of retry verify: " + (i+1));
	        			break;
	        		}else {
	        			Thread.sleep(config1.getHSM_VERIFY_RETRY_TIME());
	        		}
	        	}
	        }
	        	
	        
	        return bVerify;
	        
			}catch (Exception e) {
				logger.error("Verify is failed! Exception = " + e.getMessage());
				return false;
			}
	        
	        
		}else {
			return true;
		}
	}

	
	
}

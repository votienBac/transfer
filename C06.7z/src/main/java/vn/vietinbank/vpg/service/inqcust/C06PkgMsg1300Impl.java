package vn.vietinbank.vpg.service.inqcust;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.C06Message1300;
import vn.vietinbank.vpg.model.inqcust.C06Message1310;
import vn.vietinbank.vpg.service.PkgMsgInterface;

public class C06PkgMsg1300Impl implements PkgMsgInterface<BeMessage1300,C06Message1310,ResponseEntity<String>,C06Message1300> {

	private static final Logger logger = LoggerFactory.getLogger(C06PkgMsg1300Impl.class);
	
	C06Message1300 msg1300 = null;

	
	@Override
	public C06Message1300 packageMessage(BeMessage1300 beMessageRq, C06Message1310 CtsMessageRs,
			ResponseEntity<String> result,VpgMicroServiceParamsEntity config1) {
		
		try {
			msg1300 = new C06Message1300();
			
			msg1300.setMaGiaoDich(beMessageRq.getHeader().getMsgId());
			msg1300.setSoDinhDanh(beMessageRq.getData().getRecords().get(0).getCustCode());
			msg1300.setAnhChanDungBase64(beMessageRq.getData().getRecords().get(0).getPreseve1());
			msg1300.setNgayGioGiaoDich(beMessageRq.getData().getRecords().get(0).getTransTime());
			return msg1300;
			}catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}finally {
				msg1300 = null;
			}
	}
}

package vn.vietinbank.vpg.service.inqcust;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.PrvData1300;
import vn.vietinbank.vpg.model.inqcust.PrvHeader1300;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1300;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1310;
import vn.vietinbank.vpg.model.inqcust.PrvRecord1300;
import vn.vietinbank.vpg.service.PkgMsgInterface;

public class PrvPkgMsg1300Impl implements PkgMsgInterface<BeMessage1300,PrvMessage1310,ResponseEntity<String>,PrvMessage1300> {

	private static final Logger logger = LoggerFactory.getLogger(PrvPkgMsg1300Impl.class);
	
	PrvMessage1300 msg1300 = null;
	PrvHeader1300 header1300 = null;
	PrvData1300 data1300 = null;
	List<PrvRecord1300> lstRecord1300 = null;
	PrvRecord1300 record1300 = null;
	
	
	@Override
	public PrvMessage1300 packageMessage(BeMessage1300 beMessageRq, PrvMessage1310 tcbsMessageRs,
			ResponseEntity<String> result, VpgMicroServiceParamsEntity config1) {
		
		try {
			msg1300 = new PrvMessage1300();
			
		
			header1300 = new PrvHeader1300();
			
			header1300.setChannelId(beMessageRq.getHeader().getChannelId());
			header1300.setMerchantId(beMessageRq.getHeader().getMerchantId());
			header1300.setMsgId(beMessageRq.getHeader().getMsgId());
			header1300.setMsgType(beMessageRq.getHeader().getMsgType());
			header1300.setProductId(beMessageRq.getHeader().getProductId());
			header1300.setProviderId(beMessageRq.getHeader().getProviderId());
			
			header1300.setRecordNum(beMessageRq.getHeader().getRecordNum());
			header1300.setTimestamp(beMessageRq.getHeader().getTimestamp());
			
			msg1300.setHeader(header1300);
			
			
			data1300 = new PrvData1300();
			
			lstRecord1300 = new ArrayList<PrvRecord1300>();
			
			for(int i=0; i < beMessageRq.getData().getRecords().size(); i++) {
				record1300 = new PrvRecord1300();
				
				record1300.setChannelId(beMessageRq.getData().getRecords().get(i).getChannelId());
				
				record1300.setCustAcct(beMessageRq.getData().getRecords().get(i).getCustAcct());
				
				record1300.setCustCode(beMessageRq.getData().getRecords().get(i).getCustCode());
				record1300.setCustName(beMessageRq.getData().getRecords().get(i).getCustName());
				record1300.setEmail(beMessageRq.getData().getRecords().get(i).getEmail());
				record1300.setIdCard(beMessageRq.getData().getRecords().get(i).getIdCard());
				
				record1300.setPaymentMethod(beMessageRq.getData().getRecords().get(i).getPaymentMethod());
				record1300.setPaymentType(beMessageRq.getData().getRecords().get(i).getPaymentType());
				record1300.setPhoneNo(beMessageRq.getData().getRecords().get(i).getPhoneNo());
				
				record1300.setServiceType(beMessageRq.getData().getRecords().get(i).getServiceType() == null ? "" : 
					beMessageRq.getData().getRecords().get(i).getServiceType());
				
				record1300.setTransId(beMessageRq.getData().getRecords().get(i).getTransId());
				record1300.setTransTime(beMessageRq.getData().getRecords().get(i).getTransTime());
				record1300.setTransType(beMessageRq.getData().getRecords().get(i).getTransType());
				
				lstRecord1300.add(record1300);
			}
			
			
			data1300.setRecords(lstRecord1300);
			
			msg1300.setData(data1300);
			
			return msg1300;
			}catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}finally {
				msg1300 = null;
				header1300 = null;
				data1300 = null;
				lstRecord1300 = null;
				record1300 = null;
				
			}
	}
}

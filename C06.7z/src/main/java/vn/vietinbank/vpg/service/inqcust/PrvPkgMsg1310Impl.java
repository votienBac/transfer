package vn.vietinbank.vpg.service.inqcust;

import java.net.URI;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import javax.wsdl.Message;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import org.springframework.web.client.RestTemplate;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;

import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.inqcust.BeData1310;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.model.inqcust.BeMessage1310;
import vn.vietinbank.vpg.model.inqcust.BeRecord1310;
import vn.vietinbank.vpg.model.inqcust.PrvMessage1310;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.LOG_OUT;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;


public class PrvPkgMsg1310Impl implements PkgMsgInterface<BeMessage1300,PrvMessage1310,ResponseEntity<String>,BeMessage1310> {

	private static final Logger logger = LoggerFactory.getLogger(PrvPkgMsg1310Impl.class);
	
	BeMessage1310 msg1310 = null;
	Header header1310 = null;
	BeData1310 data1310 = null;
	List<BeRecord1310> lstRecord1310 = null;
	BeRecord1310 record1310 = null;
	Status status1310 = null;
	String errCode = "";
	
	@Override
	public BeMessage1310 packageMessage(BeMessage1300 beMessageRq, PrvMessage1310 tcbsMessageRs,
			ResponseEntity<String> result,  VpgMicroServiceParamsEntity config1) {
		
		try {
			header1310 = new Header();
			
			header1310 = beMessageRq.getHeader();
			
			header1310.setMsgType(VPG_MSG_TYPE.MSG_TYPE_1310);
			
			header1310.setTimestamp(tcbsMessageRs.getHeader().getTimestamp());
			
			msg1310 = new BeMessage1310();
			
			msg1310.setHeader(header1310);
			
			data1310 = new BeData1310();
			
			Errors errors = new Errors();
			
			errors.setErrorDesc(tcbsMessageRs.getData().getErrors().getErrorDesc());
			
			
			errCode = "";
			
			try {
				errCode = CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),tcbsMessageRs.getData().getErrors().getErrorCode());
				
				}catch (Exception ex){
					errCode = "";
				}
			
			if(CommonUtils.isNullOrEmpty(errCode)) {
				errCode = (tcbsMessageRs.getData().getErrors() == null ? "" : tcbsMessageRs.getData().getErrors().getErrorCode());
			}
			
			errors.setErrorCode(errCode);
			
			errors.setErrorCodeVPG(tcbsMessageRs.getData().getErrors().getErrorCode());
			errors.setErrorDescVPG(tcbsMessageRs.getData().getErrors().getErrorDesc());
			
			data1310.setErrors(errors);
			
			lstRecord1310 = new ArrayList<BeRecord1310>();
			
			for(int i=0; i < tcbsMessageRs.getData().getRecords().size(); i++) {
				record1310 = new BeRecord1310();
				
				record1310.setTransId(tcbsMessageRs.getData().getRecords().get(i).getTransId());
				record1310.setChannelId(tcbsMessageRs.getData().getRecords().get(i).getChannelId());
				record1310.setTransTime(tcbsMessageRs.getData().getRecords().get(i).getTransTime());
				
				record1310.setCustCode(tcbsMessageRs.getData().getRecords().get(i).getCustCode());
				record1310.setCustName(tcbsMessageRs.getData().getRecords().get(i).getCustName());
				record1310.setCustAcct(beMessageRq.getData().getRecords().get(i).getCustAcct());
				record1310.setIdCard(beMessageRq.getData().getRecords().get(i).getIdCard());
				
				record1310.setPhoneNo(beMessageRq.getData().getRecords().get(i).getPhoneNo());
				record1310.setEmail(beMessageRq.getData().getRecords().get(i).getEmail());
				
				
				record1310.setUrl(tcbsMessageRs.getData().getRecords().get(i).getUrl());
				
				Status status = new  Status();
				
				
				errCode = "";
				
				try {
					
					errCode = CommonUtils.getConfigParamsByKey(config1.getCONFIG_PARAMS(),tcbsMessageRs.getData().getRecords().get(i).getStatus().getCode());
					
					}catch (Exception ex){
						errCode = "";
					}
				
				if(CommonUtils.isNullOrEmpty(errCode)) {
					errCode = (tcbsMessageRs.getData().getRecords().get(i).getStatus() == null ? "" : tcbsMessageRs.getData().getRecords().get(i).getStatus().getCode());
				}
				
				status.setCode(errCode);
				
				status.setMessage(tcbsMessageRs.getData().getRecords().get(i).getStatus().getMessage());
				
				
				record1310.setStatus(status);
				
				
				lstRecord1310.add(record1310);
			}
			
			
			data1310.setRecords(lstRecord1310);
			
			msg1310.setData(data1310);
			
			return msg1310;
		
			}catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}finally {
				msg1310 = null;
				header1310 = null;
				data1310 = null;
				lstRecord1310 = null;
				record1310 = null;
				status1310 = null;
			}
	}
}

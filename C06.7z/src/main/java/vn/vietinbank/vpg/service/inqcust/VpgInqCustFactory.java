package vn.vietinbank.vpg.service.inqcust;

import vn.vietinbank.vpg.service.VpgMessageAbstractFactory;
import vn.vietinbank.vpg.service.notifystatus.C06NotifyStatusImpl;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;


public class VpgInqCustFactory implements VpgMessageAbstractFactory<VpgInqCustInterface> {

	@Override
	public VpgInqCustInterface create(String provider) {
		
		try {
			switch(provider) {
			
			case PROVIDER_ID.BCA_C06:{
				return new C06InqCustImpl();
			}
			default:{
				return new C06InqCustImpl();
			}
			
			}
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	public VpgInqCustInterface create(String formatType, String provider) {
	
		return null;
	}

	
}

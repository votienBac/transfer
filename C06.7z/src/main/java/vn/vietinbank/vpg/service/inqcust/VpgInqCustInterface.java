package vn.vietinbank.vpg.service.inqcust;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.inqcust.*;


public interface VpgInqCustInterface {
    
	BeMessage1310 processMessage(BeMessage1300 message1300,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity);
			
}

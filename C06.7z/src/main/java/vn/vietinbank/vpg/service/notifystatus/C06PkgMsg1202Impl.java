package vn.vietinbank.vpg.service.notifystatus;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.C06Message1202;
import vn.vietinbank.vpg.model.notifystatus.PrvData1202;
import vn.vietinbank.vpg.model.notifystatus.PrvHeader;
import vn.vietinbank.vpg.model.notifystatus.PrvRecord1202;
import vn.vietinbank.vpg.model.notifystatus.PrvStatus;
import vn.vietinbank.vpg.model.notifystatus.Data;
import vn.vietinbank.vpg.model.notifystatus.C06Message1212;
import vn.vietinbank.vpg.service.PkgMsgInterface;


public class C06PkgMsg1202Impl implements PkgMsgInterface<BeMessage1202,C06Message1212,ResponseEntity<String>,C06Message1202> {

	private static final Logger logger = LoggerFactory.getLogger(C06PkgMsg1202Impl.class);
	
	C06Message1202 msg1202 = null;
	Data msg1202Data = null;
	PrvHeader header1202 = null;
	PrvData1202 data1202 = null;
	List<PrvRecord1202> lstPrvRecord1202 = null;
	PrvRecord1202 record1202 = null;
	PrvStatus status1202 = null;
	

	@Override
	public C06Message1202 packageMessage(BeMessage1202 beMessageRq, C06Message1212 prvMessageRs,
			ResponseEntity<String> result, VpgMicroServiceParamsEntity config1) {
		
		try {
		msg1202 =  new C06Message1202();
		msg1202Data = new Data() ;
		
		msg1202Data.setSoDinhDanh(beMessageRq.getData().getRecords().get(0).getIdCard());
		msg1202Data.setSoTaiKhoan(beMessageRq.getData().getRecords().get(0).getSendAcctId());
		msg1202Data.setMaNganHang(beMessageRq.getData().getRecords().get(0).getSendBankId());		
		msg1202Data.setMaAlias(beMessageRq.getData().getRecords().get(0).getCustCode());
		msg1202Data.setSoThe(beMessageRq.getData().getRecords().get(0).getCustAcct());
		Date date1=new SimpleDateFormat("yyyyMMddHHmmss").parse(beMessageRq.getData().getRecords().get(0).getTransTime());  
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");  
		String strDate = dateFormat.format(date1);  
		msg1202.setNgayGioGiaoDich(strDate);
		msg1202.setMaGiaoDich(beMessageRq.getData().getRecords().get(0).getOriginalId());
		msg1202.setTrangThai("0");
		msg1202.setMoTaLoi("Thanh cong");
		msg1202.setData(msg1202Data);
		return msg1202;
		}catch(Exception ex) {
			
			logger.error("Package message request is failed! Exception = " + ex.getMessage());
			return null;
		}finally {
			msg1202 = null;
			
		}
	}
}

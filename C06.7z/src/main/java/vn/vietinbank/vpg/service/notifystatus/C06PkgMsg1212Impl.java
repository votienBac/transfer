package vn.vietinbank.vpg.service.notifystatus;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;
import vn.vietinbank.vpg.model.notifystatus.C06Message1212;
import vn.vietinbank.vpg.model.notifystatus.BeData1212;
import vn.vietinbank.vpg.model.notifystatus.BeRecord1212;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;


public class C06PkgMsg1212Impl implements PkgMsgInterface<BeMessage1202,C06Message1212,ResponseEntity<String>,BeMessage1212> {

	private static final Logger logger = LoggerFactory.getLogger(C06PkgMsg1212Impl.class);
	
	BeMessage1212 message1212 = null;
	Header header1212 = null;
	BeData1212 data1212 = null;
	List<BeRecord1212> lstRecord1212 = null;
	BeRecord1212 record1212 = null;
	Status status1212 = null;
	
	
	@Override
	public BeMessage1212 packageMessage(BeMessage1202 beMessageRq, C06Message1212 prvMessageRs,
			ResponseEntity<String> result, VpgMicroServiceParamsEntity config1) {
		
		try {
			header1212 = new Header();
			
			header1212 = beMessageRq.getHeader();
			
			header1212.setMsgType(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
			
			header1212.setTimestamp(CommonUtils.getCurrentDateFormat(Constants.PATTERN_DATETIME));
			
			message1212 = new BeMessage1212();
			
			message1212.setHeader(header1212);
			
			data1212 = new BeData1212();
			
			Errors errors = new Errors();
			
			if(prvMessageRs.getTrangThai().equals("0")) {
				errors.setErrorCode("00");
				errors.setErrorDesc(prvMessageRs.getMoTaLoi());
				errors.setErrorCodeVPG(Constants.VPG_STATUS_SUCCESS.CODE);
				errors.setErrorDescVPG(Constants.VPG_STATUS_SUCCESS.DESC);
			}
			else {
				errors.setErrorCode(prvMessageRs.getTrangThai());
				errors.setErrorDesc(prvMessageRs.getMoTaLoi());
				errors.setErrorCodeVPG(Constants.VPG_STATUS_ERR_GENERAL.CODE);
				errors.setErrorDescVPG(Constants.VPG_STATUS_ERR_GENERAL.DESC);
			}
			
			data1212.setErrors(errors);
			
			
			lstRecord1212 = new ArrayList<BeRecord1212>();
			
			for(int i=0; i < 1; i++) {
				record1212 = new BeRecord1212();
				
				record1212.setTransId(beMessageRq.getData().getRecords().get(i).getTransId());
				record1212.setOriginalId(beMessageRq.getData().getRecords().get(i).getOriginalId());
				record1212.setTransType(beMessageRq.getData().getRecords().get(i).getTransType());
				record1212.setServiceType(beMessageRq.getData().getRecords().get(i).getServiceType());
				
				record1212.setAmount(beMessageRq.getData().getRecords().get(i).getAmount());
				record1212.setChannelId(beMessageRq.getData().getRecords().get(i).getChannelId());
				record1212.setCustAcct(beMessageRq.getData().getRecords().get(i).getCustAcct());
				record1212.setCustCode(beMessageRq.getData().getRecords().get(i).getCustCode());
				record1212.setCustName(beMessageRq.getData().getRecords().get(i).getCustName());
				record1212.setEmail(beMessageRq.getData().getRecords().get(i).getEmail());
				record1212.setFee(beMessageRq.getData().getRecords().get(i).getFee());
				record1212.setIdCard(beMessageRq.getData().getRecords().get(i).getIdCard());
				record1212.setOriginalId(beMessageRq.getData().getRecords().get(i).getOriginalId());
				
				record1212.setPhoneNo(beMessageRq.getData().getRecords().get(i).getPhoneNo());
				record1212.setRecvAcctId(beMessageRq.getData().getRecords().get(i).getRecvAcctId());
				record1212.setRecvAcctName(beMessageRq.getData().getRecords().get(i).getRecvAcctName());
				record1212.setRecvBankId(beMessageRq.getData().getRecords().get(i).getRecvBankId());
				
				record1212.setRecvBranchId(beMessageRq.getData().getRecords().get(i).getRecvBranchId());
				record1212.setSendAcctId(beMessageRq.getData().getRecords().get(i).getSendAcctId());
				record1212.setSendBankId(beMessageRq.getData().getRecords().get(i).getSendBankId());
				record1212.setSendBranchId(beMessageRq.getData().getRecords().get(i).getSendBranchId());
				
				record1212.setSendAcctName(beMessageRq.getData().getRecords().get(i).getSendAcctName());
				record1212.setServiceType(beMessageRq.getData().getRecords().get(i).getServiceType());
				
				Status status = new  Status();
				
			
				
				
				
				if(prvMessageRs.getTrangThai().equals("0")) {//0: thanh cong; 1: khong thanh cong
					status.setCode("00");
					status.setMessage(prvMessageRs.getMoTaLoi());
				}
				else {
					status.setCode(prvMessageRs.getTrangThai());
					status.setMessage(prvMessageRs.getMoTaLoi());
				}
				
				
				record1212.setStatus(status);
				
				record1212.setTransId(beMessageRq.getData().getRecords().get(i).getTransId());
				record1212.setTransTime(CommonUtils.getCurrentDateFormat(Constants.PATTERN_DATETIME));
				record1212.setTransType(beMessageRq.getData().getRecords().get(i).getTransType());
				record1212.setVat(beMessageRq.getData().getRecords().get(i).getVat());
				
				lstRecord1212.add(record1212);
			}
			
			
			data1212.setRecords(lstRecord1212);
			
			
			message1212.setData(data1212);
			
			
			
			
			return message1212;
		
			}catch(Exception ex) {
				logger.error("BeMessage1212 Exception : " + ex.getStackTrace().toString());
				return null;
			}finally {
				message1212 = null;
				header1212 = null;
				data1212 = null;
				lstRecord1212 = null;
				record1212 = null;
				status1212 = null;
			}
	}


}

package vn.vietinbank.vpg.service.notifystatus;

import java.net.URI;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.ResponseEntity;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;
import vn.vietinbank.vpg.model.ConfigParams;
import vn.vietinbank.vpg.model.error.MessageErrorPrv;
import vn.vietinbank.vpg.model.notifystatus.BeData1212;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;
import vn.vietinbank.vpg.model.notifystatus.BeRecord1212;
import vn.vietinbank.vpg.model.notifystatus.PrvData1202;
import vn.vietinbank.vpg.model.notifystatus.PrvHeader;
import vn.vietinbank.vpg.model.notifystatus.PrvMessage1202;
import vn.vietinbank.vpg.model.notifystatus.PrvMessage1212;
import vn.vietinbank.vpg.model.notifystatus.PrvRecord1202;
import vn.vietinbank.vpg.model.notifystatus.PrvStatus;
import vn.vietinbank.vpg.security.SecureAbstractFactory;
import vn.vietinbank.vpg.security.SecureFactory;
import vn.vietinbank.vpg.security.SecureInterface;
import vn.vietinbank.vpg.service.PkgMsgAbstractFactory;
import vn.vietinbank.vpg.service.PkgMsgFactory;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.service.callapi.VpgCallApiFactory;
import vn.vietinbank.vpg.service.callapi.VpgCallApiInterface;
import vn.vietinbank.vpg.service.error.VpgMessageErrorFactory;
import vn.vietinbank.vpg.service.error.VpgMessageErrorInterface;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;
import vn.vietinbank.vpg.dao.*;


public class PrvNotifyStatusImpl implements VpgNotifyStatusInterface {

	private static final Logger logger = LoggerFactory.getLogger(PrvNotifyStatusImpl.class);
	
	private BeMessage1202 messageRQ = null;
	private VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity;
	
	VpgTransLogOutDaoInterface vpgTransLogOutDAO 	= null;
	VpgTransLogOutEntity vpgTransLogOutEntity = null;
	
	VpgTransLogInDaoInterface vpgTransLogInDAO 	= null;
	VpgTransLogInEntity vpgTransLogInEntity = null;
	
	BeMessage1212 messageRS = null;
	BeData1212 data = null;
	vn.vietinbank.vpg.model.Header header  = null;
	
	String msgRq = "";
	String msgRs = "";
	
	String dataSign = "";
	String signed = "";
	boolean bVerify = false;
	
	
	
	vn.vietinbank.vpg.model.Errors errors = null;
	String jsonRs = "";
	
	Long processTimeStart;
	Long processTimeEnd;
	Long processTime;
	
	Long processTimePartnerStart;
	Long processTimePartnerEnd;
	Long processTimePartner;
	
	Long processTimeDBStart;
	Long processTimeDBEnd;
	Long processTimeDB;
	
	PrvMessage1202 message1202Prv = null;
	PrvHeader header1202Prv = null;
	PrvData1202 data1202Prv = null;
	
	PrvMessage1212 message1212Prv = null;
	List<PrvRecord1202>  lstRecord1202Prv = null;
	PrvRecord1202  record1202Prv = null;
	
	PrvStatus status1202Prv = null;
	
	List<BeRecord1212>  lstRecord1212 = null;
	BeRecord1212  record1212 = null;
	
	JsonNode rootNode = null;
	JsonNode type = null;
	
	
	VpgMessageErrorFactory vpgMessageErrorFactory = null;
	VpgMessageErrorInterface vpgMessageErrorInterface;
	
	int httpStatus = 200;
	MessageErrorPrv messageErrorPrv = null;
	
	SecureAbstractFactory secureAbstractFactory = null;
	SecureInterface secureInterface = null;
	
	PkgMsgAbstractFactory pkgMsgAbstractFactory = null;
	PkgMsgInterface pkgMsgInterface = null;
	
	
	public PrvNotifyStatusImpl() {
		
	}
	

	@Override
	public BeMessage1212 processMessage(BeMessage1202 message1202,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		
		try
		{
			this.processTimeStart = System.currentTimeMillis(); 
			
			switch(vpgMicroServiceParamsEntity.getCHANGE_FORMAT().trim()) {
			
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_0:{
					
					
					break;
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_1:{
					
					
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1202);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					message1202Prv = (PrvMessage1202) pkgMsgInterface.packageMessage(message1202, null, null,vpgMicroServiceParamsEntity);
					
					
					if(message1202Prv == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
						
						return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PKG.CODE,
								Constants.VPG_STATUS_ERR_PKG.DESC);
					}
					
					
					if(vpgMicroServiceParamsEntity.getHSM_ENABLE().equals(VPG_STATUS.ENABLE)){
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.HSM);
						
					}else
					{
						secureAbstractFactory = SecureFactory.getFactory(Constants.VPG_SECURE_TYPE.VPG);
					}
					
					secureInterface = (SecureInterface) secureAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID().trim());//
					
					if(vpgMicroServiceParamsEntity.getHSM_SIGN_ENABLE().equals(VPG_STATUS.ENABLE)) {
						
						

						dataSign = "";
						
						if( (message1202Prv.getData().getRecords() != null) &&  (message1202Prv.getData().getRecords().size()>0)) {
							for(int i = 0; i < message1202Prv.getData().getRecords().size(); i++) {
								dataSign += message1202Prv.getData().getRecords().get(i).getTransId() == null ? "" : message1202Prv.getData().getRecords().get(i).getTransId();
								dataSign += message1202Prv.getData().getRecords().get(i).getOriginalId() == null ? "" : message1202Prv.getData().getRecords().get(i).getOriginalId();
								dataSign += message1202Prv.getData().getRecords().get(i).getTransTime() == null ? "" : message1202Prv.getData().getRecords().get(i).getTransTime();
								dataSign += message1202Prv.getData().getRecords().get(i).getCustCode() == null ? "" : message1202Prv.getData().getRecords().get(i).getCustCode();
								dataSign += message1202Prv.getData().getRecords().get(i).getCustName() == null ? "" : message1202Prv.getData().getRecords().get(i).getCustName();
								dataSign += message1202Prv.getData().getRecords().get(i).getCustAcct() == null ? "" : message1202Prv.getData().getRecords().get(i).getCustAcct();
								dataSign += message1202Prv.getData().getRecords().get(i).getAmount() == null ? "" : message1202Prv.getData().getRecords().get(i).getAmount();
								
								dataSign += (message1202Prv.getData().getRecords().get(i).getStatus() == null ? "" : message1202Prv.getData().getRecords().get(i).getStatus().getCode());
							}
						}
						
						logger.info("Data for signing: " + dataSign);
						
						signed = signString(vpgMicroServiceParamsEntity,
								dataSign,
								secureInterface);
						message1202Prv.getHeader().setSignature(signed);
						
						logger.info("Signed: " + signed);
						
					
						if(CommonUtils.isNullOrEmpty(signed)) {
							vpgMessageErrorFactory = new VpgMessageErrorFactory();
							
							vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1202);
							
							return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
									Constants.PRV_STATUS_ERR_GENERAL.CODE,
									Constants.PRV_STATUS_ERR_GENERAL.DESC,
									Constants.VPG_STATUS_ERR_SIGN.CODE,
									Constants.VPG_STATUS_ERR_SIGN.DESC);
						}
					}
					
					msgRq = ConvertJsonToObject.objectToJson(message1202Prv);
			        
			        this.processTimeDBStart = System.currentTimeMillis();
			        
			      
			        try {
			        	logOut(message1202,ConvertJsonToObject.objectToJson(message1202),msgRq,vpgMicroServiceParamsEntity);
			        }catch(Exception e) {
			        	
			        	logger.error("logOut() is failed. Message request: " + msgRq + "; Exception: " + e.getMessage());
			        	
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
						
						return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_DB.CODE,
								Constants.VPG_STATUS_ERR_DB.DESC);
			        }
			        
			        this.processTimeDBEnd = System.currentTimeMillis();
			        
			        this.processTimeDB = this.processTimeDBEnd - this.processTimeDBStart;
			        
			     
			        this.processTimePartnerStart = System.currentTimeMillis();
					
					ResponseEntity<String> result = callApi(msgRq,vpgMicroServiceParamsEntity);
					
					this.processTimePartnerEnd = System.currentTimeMillis();
					
					this.processTimePartner = this.processTimePartnerEnd - this.processTimePartnerStart;
					
					if(result == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
						
						return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.CODE,
								Constants.VPG_STATUS_ERR_TIMEOUT_PROVIDER.DESC);
					}
					
					msgRs = result.getBody();
					
					logger.info("Message response from partner: {}", msgRs);
					
					httpStatus = result.getStatusCodeValue();
					
					if(httpStatus != 200) {
						switch (httpStatus)
						{
							case 400:
							{
								messageErrorPrv = ConvertJsonToObject.jsonToObject(msgRs, MessageErrorPrv.class);
								
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
								
								return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
										messageErrorPrv.getCode(),
										messageErrorPrv.getMessage(),
										Constants.VPG_STATUS_ERR_PARSE.CODE,
										Constants.VPG_STATUS_ERR_PARSE.DESC);
								
							
							}
							case 500:
							{
								
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
								
								return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
										String.valueOf(result.getStatusCodeValue()),
										result.getBody(),
										Constants.VPG_STATUS_ERR_GENERAL.CODE,
										Constants.VPG_STATUS_ERR_GENERAL.DESC);
							}
							default: {
								vpgMessageErrorFactory = new VpgMessageErrorFactory();
								
								vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
								
								return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
										String.valueOf(result.getStatusCodeValue()),
										result.getBody(),
										Constants.VPG_STATUS_ERR_GENERAL.CODE,
										Constants.VPG_STATUS_ERR_GENERAL.DESC);
							}
							
						}
					}
					
					message1212Prv = ConvertJsonToObject.jsonToObject(msgRs, PrvMessage1212.class);
					
					if(message1212Prv == null) {
						vpgMessageErrorFactory = new VpgMessageErrorFactory();
						
						vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
						
						return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
								Constants.PRV_STATUS_ERR_GENERAL.CODE,
								Constants.PRV_STATUS_ERR_GENERAL.DESC,
								Constants.VPG_STATUS_ERR_PARSE.CODE,
								Constants.VPG_STATUS_ERR_PARSE.DESC);
					}
					
					
					
					if(vpgMicroServiceParamsEntity.getHSM_VERIFY_ENABLE().equals(VPG_STATUS.ENABLE)) {
						
						
						bVerify = this.verifyString(vpgMicroServiceParamsEntity,message1212Prv, secureInterface);
						
						if(bVerify == false) {
							
							logger.error("Verify message is failed! Message = " + msgRs);
							
							vpgMessageErrorFactory = new VpgMessageErrorFactory();
							
							vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
							
							return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
									Constants.PRV_STATUS_ERR_GENERAL.CODE,
									Constants.PRV_STATUS_ERR_GENERAL.DESC,
									Constants.VPG_STATUS_ERR_VERIFY.CODE,
									Constants.VPG_STATUS_ERR_VERIFY.DESC);
						}
					}
				
					
					pkgMsgAbstractFactory = PkgMsgFactory.getFactory(VPG_MSG_TYPE.MSG_TYPE_1212);
					
					pkgMsgInterface = (PkgMsgInterface) pkgMsgAbstractFactory.create(vpgMicroServiceParamsEntity.getPROVIDER_ID());
					
					messageRS = (BeMessage1212) pkgMsgInterface.packageMessage(message1202, message1212Prv, null,vpgMicroServiceParamsEntity);
					
					jsonRs = ConvertJsonToObject.objectToJson(messageRS);
					
					this.processTimeEnd = System.currentTimeMillis();
					this.processTime = this.processTimeEnd - this.processTimeStart;
					
					logIn(message1202,messageRS,result.getBody(),jsonRs,vpgMicroServiceParamsEntity);
					
					break;
					
				}
				case VPG_CHANGE_FORMAT.CHANGE_FORMAT_2:{
					break;
				}
				
				default:{
					break;
				}
				
			}
		
			
			return messageRS;
			
		}catch(Exception e) {
			logger.error("notifyTrans() is failed. SOA request: " + msgRq
					+ "; Message response origin: " +  msgRs
					+ "; Message response: " +  jsonRs 
					+ "; Exception: " + e.getMessage());
			
			vpgMessageErrorFactory = new VpgMessageErrorFactory();
			
			vpgMessageErrorInterface = vpgMessageErrorFactory.create(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
			
			return (BeMessage1212) vpgMessageErrorInterface.getMessageError(message1202,
					Constants.PRV_STATUS_ERR_GENERAL.CODE,
					Constants.PRV_STATUS_ERR_GENERAL.DESC,
					Constants.VPG_STATUS_ERR_GENERAL.CODE,
					Constants.VPG_STATUS_ERR_GENERAL.DESC);
			
		}
		finally {
			messageRQ = null;
			vpgTransLogOutDAO 	= null;
			vpgTransLogOutEntity = null;
			vpgTransLogInDAO 	= null;
			vpgTransLogInEntity = null;
			messageRS = null;
			data = null;
			header  = null;
			
			errors = null;
			message1202Prv = null;
			header1202Prv = null;
			data1202Prv = null;
			message1212Prv = null;
			lstRecord1202Prv = null;
			record1202Prv = null;
			status1202Prv = null;
			lstRecord1212 = null;
			record1212 = null;
			rootNode = null;
			type = null;
			vpgMessageErrorFactory = null;
			vpgMessageErrorInterface = null;
			messageErrorPrv = null;
			secureAbstractFactory = null;
			secureInterface = null;
		}
	
	}
	
	
	private void logOut(BeMessage1202 messageRQ,String originMsg, String convertMsg, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try {
			vpgTransLogOutEntity = new VpgTransLogOutEntity();
			
			vpgTransLogOutEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogOutEntity.setMsg_id(messageRQ.getHeader().getMsgId());
			vpgTransLogOutEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1202);
			vpgTransLogOutEntity.setPayment_channel(messageRQ.getHeader().getChannelId());
			
			
			vpgTransLogOutEntity.setGateway_id(vpgMicroServiceParamsEntity.getGATEWAY_ID());
			vpgTransLogOutEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogOutEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			
			vpgTransLogOutEntity.setTrans_direct(Constants.LOG_OUT.TRANS_DIRECT);
			vpgTransLogOutEntity.setTrans_type(Constants.LOG_OUT.TRANS_TYPE);
			vpgTransLogOutEntity.setService_code(Constants.SERVICE_CODE);
			
			
			vpgTransLogOutEntity.setMsg_origin(originMsg);
			vpgTransLogOutEntity.setMsg_convert(convertMsg);
			
			vpgTransLogOutEntity.setYear(CommonUtils.getYear());
			vpgTransLogOutEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogOutEntity.setDay(CommonUtils.getDayOfMonth());
			
			
			vpgTransLogOutDAO = new VpgTransLogOutDaoImpl();
			
			vpgTransLogOutDAO.save(vpgTransLogOutEntity);
		}catch(Exception e) {
			logger.error("logOut() is failed: " + e.getMessage());
		}
	}
	
	private void logIn(BeMessage1202 messageRQ,BeMessage1212 messageRS, String originMsg, String convertMsg,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity) {
		try {
			vpgTransLogInEntity = new VpgTransLogInEntity();
			
			vpgTransLogInEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogInEntity.setMsg_id(messageRQ.getHeader().getMsgId());
			vpgTransLogInEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1212);
			vpgTransLogInEntity.setPayment_channel(messageRQ.getHeader().getChannelId());
			
			
			vpgTransLogInEntity.setGateway_id(vpgMicroServiceParamsEntity.getGATEWAY_ID());
			vpgTransLogInEntity.setProvider_id(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			vpgTransLogInEntity.setProduct_code(vpgMicroServiceParamsEntity.getPRODUCT_CODE());
			
			
			vpgTransLogInEntity.setTrans_direct(Constants.LOG_IN.TRANS_DIRECT);
			vpgTransLogInEntity.setTrans_type(Constants.LOG_IN.TRANS_TYPE);
			vpgTransLogInEntity.setService_code(Constants.SERVICE_CODE);
			
			
			vpgTransLogInEntity.setMsg_origin(originMsg);
			vpgTransLogInEntity.setMsg_convert(convertMsg);
			
			vpgTransLogInEntity.setError_code(messageRS.getData().getErrors().getErrorCode());
			vpgTransLogInEntity.setError_desc(messageRS.getData().getErrors().getErrorDesc());
			
			
			vpgTransLogInEntity.setYear(CommonUtils.getYear());
			vpgTransLogInEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogInEntity.setDay(CommonUtils.getDayOfMonth());
			
			vpgTransLogInEntity.setPROCESS_TIME(this.processTime);
			vpgTransLogInEntity.setPROCESS_TIME_PRV(this.processTimePartner);
			vpgTransLogInEntity.setPROCESS_TIME_DB(processTimeDB);
			
			
		
			vpgTransLogInDAO = new VpgTransLogInDaoImpl();
			
			vpgTransLogInDAO.save(vpgTransLogInEntity);
		}catch(Exception e) {
			logger.error("logIn() is failed: " + e.getMessage());
		}
	}

	private ResponseEntity<String> callApi(String msg, VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity ){
		try {
			
			VpgCallApiInterface vpgApi = VpgCallApiFactory.getApi(vpgMicroServiceParamsEntity.getPROVIDER_ID());
			
				return (ResponseEntity<String>)vpgApi.callApi(msg,
					vpgMicroServiceParamsEntity.getURL_PARTNER(),
					Integer.parseInt(vpgMicroServiceParamsEntity.getURL_TIMEOUT()),
					vpgMicroServiceParamsEntity.getURL_HEADER(),
					vpgMicroServiceParamsEntity.getURL_ACTION(), 
					Integer.parseInt(vpgMicroServiceParamsEntity.getURL_TIMEOUT_SOCKET()), 
					vpgMicroServiceParamsEntity.getURL_METHOD());
			
		}catch(Exception e) {
			
			logger.error("callApi() is failed: " + e.getMessage());
			return null;
		}
		
	}
	
	private String signString(VpgMicroServiceParamsEntity config1,String dataSign, SecureInterface secure) {

		try {
		    
	    	String signed = secure.signString(config1,dataSign);
	        
	        if(CommonUtils.isNullOrEmpty(signed)) {
	        	for(int i = 0; i < vpgMicroServiceParamsEntity.getHSM_SIGN_RETRY(); i++) {
	        		
	        		signed = secure.signString(config1,dataSign);
	        		
	        		if(!CommonUtils.isNullOrEmpty(signed)) {
	        			logger.info("Number of retry sign: ");
	        			break;
	        		}else {
	        			try {
	        			Thread.sleep(vpgMicroServiceParamsEntity.getHSM_SIGN_RETRY_TIME());
	        			}catch(Exception e) {
	        				
	        			}
	        		}
	        	}
	        }
	        
	        return signed;
        
		}catch(Exception e) {
			
			logger.error("signString() is failed: " + e.getMessage());
			return "";
		}
	}
	
	public boolean verifyString(VpgMicroServiceParamsEntity config1, PrvMessage1212 message1212Prv, SecureInterface secure) {
		if(config1.getHSM_VERIFY_ENABLE().equalsIgnoreCase("1")) {
			try {
	          
	        bVerify = false;
	        
	        signed = message1212Prv.getHeader().getSignature();
	        
	        dataSign = "";
	     

	        dataSign += message1212Prv.getData().getErrors().getErrorCode();
	        
	        if( (message1212Prv.getData().getRecords() != null) &&  (message1212Prv.getData().getRecords().size()>0)) {
				for(int i = 0; i < message1212Prv.getData().getRecords().size(); i++) {
					dataSign += message1212Prv.getData().getRecords().get(i).getTransId() == null ? "" : message1212Prv.getData().getRecords().get(i).getTransId();
					dataSign += message1212Prv.getData().getRecords().get(i).getOriginalId() == null ? "" : message1212Prv.getData().getRecords().get(i).getOriginalId();
					dataSign += message1212Prv.getData().getRecords().get(i).getTransTime() == null ? "" : message1212Prv.getData().getRecords().get(i).getTransTime();
					dataSign += message1212Prv.getData().getRecords().get(i).getCustCode() == null ? "" : message1212Prv.getData().getRecords().get(i).getCustCode();
					dataSign += message1212Prv.getData().getRecords().get(i).getCustName() == null ? "" : message1212Prv.getData().getRecords().get(i).getCustName();
					dataSign += message1212Prv.getData().getRecords().get(i).getCustAcct() == null ? "" : message1212Prv.getData().getRecords().get(i).getCustAcct();
					dataSign += message1212Prv.getData().getRecords().get(i).getAmount() == null ? "" : message1212Prv.getData().getRecords().get(i).getAmount();
					dataSign += (message1212Prv.getData().getRecords().get(i).getStatus() == null ? "" : message1212Prv.getData().getRecords().get(i).getStatus().getCode());
				}
	        }
	        
	        logger.info("Data for verifying: " + dataSign);
	        
	        bVerify = secure.verifyString(config1,dataSign, signed);
	        
	        
	        if(!bVerify) {
	        	for(int i = 0; i < config1.getHSM_VERIFY_RETRY(); i++) {
	        		
	        		bVerify = secure.verifyString(config1, dataSign, signed);
	        		
	        		if(bVerify) {
	        			logger.info("Number of retry verify: " + (i+1));
	        			break;
	        		}else {
	        			Thread.sleep(config1.getHSM_VERIFY_RETRY_TIME());
	        		}
	        	}
	        }
	        	
	        
	        return bVerify;
	        
			}catch (Exception e) {
				logger.error("Verify is failed! Exception = " + e.getMessage());
				return false;
			}
	        
	        
		}else {
			return true;
		}
	}
	
	
}

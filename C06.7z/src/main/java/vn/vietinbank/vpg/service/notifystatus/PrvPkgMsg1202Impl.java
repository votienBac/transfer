package vn.vietinbank.vpg.service.notifystatus;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.PrvMessage1202;
import vn.vietinbank.vpg.model.notifystatus.PrvMessage1212;
import vn.vietinbank.vpg.model.notifystatus.PrvData1202;
import vn.vietinbank.vpg.model.notifystatus.PrvHeader;
import vn.vietinbank.vpg.model.notifystatus.PrvRecord1202;
import vn.vietinbank.vpg.model.notifystatus.PrvStatus;
import vn.vietinbank.vpg.service.PkgMsgInterface;

public class PrvPkgMsg1202Impl implements PkgMsgInterface<BeMessage1202,PrvMessage1212,ResponseEntity<String>,PrvMessage1202> {

	private static final Logger logger = LoggerFactory.getLogger(PrvPkgMsg1202Impl.class);
	
	PrvMessage1202 msg1202 = null;
	PrvHeader header1202 = null;
	PrvData1202 data1202 = null;
	List<PrvRecord1202> lstPrvRecord1202 = null;
	PrvRecord1202 record1202 = null;
	PrvStatus status1202 = null;
	
	@Override
	public PrvMessage1202 packageMessage(BeMessage1202 beMessageRq, PrvMessage1212 prvMessageRs,
			ResponseEntity<String> result, VpgMicroServiceParamsEntity config1) {
		
		try {
			msg1202 = new PrvMessage1202();
			
			header1202 = new PrvHeader();
			
			header1202.setChannelId(beMessageRq.getHeader().getChannelId());
			header1202.setMerchantId(beMessageRq.getHeader().getMerchantId());
			header1202.setMsgId(beMessageRq.getHeader().getMsgId());
			header1202.setMsgType(beMessageRq.getHeader().getMsgType());
			header1202.setProductId(beMessageRq.getHeader().getProductId());
			header1202.setProviderId(beMessageRq.getHeader().getProviderId());
			
			header1202.setRecordNum(beMessageRq.getHeader().getRecordNum());
			header1202.setTimestamp(beMessageRq.getHeader().getTimestamp());
			
			msg1202.setHeader(header1202);
			
			data1202 = new PrvData1202();
			
			lstPrvRecord1202 = new ArrayList<PrvRecord1202>();
			
			for(int i=0; i < beMessageRq.getData().getRecords().size(); i++) {
				record1202 = new PrvRecord1202();
				
				record1202.setTransId(beMessageRq.getData().getRecords().get(i).getTransId());
				record1202.setOriginalId(beMessageRq.getData().getRecords().get(i).getOriginalId());
				record1202.setChannelId(beMessageRq.getData().getRecords().get(i).getChannelId());
				
				record1202.setTransTime(beMessageRq.getData().getRecords().get(i).getTransTime());
				record1202.setTransType(beMessageRq.getData().getRecords().get(i).getTransType());
				record1202.setServiceType(beMessageRq.getData().getRecords().get(i).getServiceType() == null ? "" : 
					beMessageRq.getData().getRecords().get(i).getServiceType());
				
				
				record1202.setSendBankId(beMessageRq.getData().getRecords().get(i).getSendBankId());
				record1202.setSendBranchId(beMessageRq.getData().getRecords().get(i).getSendBranchId());
				record1202.setSendAcctId(beMessageRq.getData().getRecords().get(i).getSendAcctId());
				record1202.setSendAcctName(beMessageRq.getData().getRecords().get(i).getSendAcctName());
				
				record1202.setRecvBankId(beMessageRq.getData().getRecords().get(i).getRecvBankId());
				record1202.setRecvBranchId(beMessageRq.getData().getRecords().get(i).getRecvBranchId());
				record1202.setRecvAcctId(beMessageRq.getData().getRecords().get(i).getRecvAcctId());
				record1202.setRecvAcctName(beMessageRq.getData().getRecords().get(i).getRecvAcctName());
				
				status1202 = new  PrvStatus();
				
				status1202.setCode(beMessageRq.getData().getRecords().get(i).getStatus().getCode());
				
				status1202.setMessage(beMessageRq.getData().getRecords().get(i).getStatus().getMessage());
				
				record1202.setStatus(status1202);
				
				record1202.setCustCode(beMessageRq.getData().getRecords().get(i).getCustCode());
				record1202.setCustName(beMessageRq.getData().getRecords().get(i).getCustName());
				record1202.setCustAcct(beMessageRq.getData().getRecords().get(i).getCustAcct());
				
				record1202.setIdCard(beMessageRq.getData().getRecords().get(i).getIdCard());
				record1202.setPhoneNo(beMessageRq.getData().getRecords().get(i).getPhoneNo());
				record1202.setEmail(beMessageRq.getData().getRecords().get(i).getEmail());
				
				record1202.setTerm(beMessageRq.getData().getRecords().get(i).getTerm());
				record1202.setInterest(beMessageRq.getData().getRecords().get(i).getInterest());
				
				record1202.setAmount(beMessageRq.getData().getRecords().get(i).getAmount());
				record1202.setFee(beMessageRq.getData().getRecords().get(i).getFee());
				record1202.setVat(beMessageRq.getData().getRecords().get(i).getVat());
				
				record1202.setAddInfo(null);
				record1202.setPreseve1("");
				record1202.setPreseve2("");
				record1202.setPreseve3("");
				
				lstPrvRecord1202.add(record1202);
			}
			
			
			data1202.setRecords(lstPrvRecord1202);
			
			msg1202.setData(data1202);
			
			return msg1202;
			}catch(Exception ex) {
				logger.error("Package message request is failed! Exception = " + ex.getMessage());
				return null;
			}finally {
				msg1202 = null;
				header1202 = null;
				data1202 = null;
				lstPrvRecord1202 = null;
				record1202 = null;
				status1202 = null;
			}
	}
}

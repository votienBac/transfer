package vn.vietinbank.vpg.service.notifystatus;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;
import vn.vietinbank.vpg.model.notifystatus.PrvMessage1212;
import vn.vietinbank.vpg.model.notifystatus.BeData1212;
import vn.vietinbank.vpg.model.notifystatus.BeRecord1212;
import vn.vietinbank.vpg.service.PkgMsgInterface;
import vn.vietinbank.vpg.util.Constants;


public class PrvPkgMsg1212Impl implements PkgMsgInterface<BeMessage1202,PrvMessage1212,ResponseEntity<String>,BeMessage1212> {

	private static final Logger logger = LoggerFactory.getLogger(PrvPkgMsg1212Impl.class);
	
	BeMessage1212 message1212 = null;
	Header header1212 = null;
	BeData1212 data1212 = null;
	List<BeRecord1212> lstRecord1212 = null;
	BeRecord1212 record1212 = null;
	Status status1212 = null;
	
	
	@Override
	public BeMessage1212 packageMessage(BeMessage1202 beMessageRq, PrvMessage1212 prvMessageRs,
			ResponseEntity<String> result, VpgMicroServiceParamsEntity config1) {
		try {
			header1212 = new Header();
			
			header1212 = beMessageRq.getHeader();//
			
			header1212.setMsgType(Constants.VPG_MSG_TYPE.MSG_TYPE_1212);
			
			header1212.setTimestamp(prvMessageRs.getHeader().getTimestamp());
			
			message1212 = new BeMessage1212();
			
			message1212.setHeader(header1212);
			
			data1212 = new BeData1212();
			
			Errors errors = new Errors();
			
			errors.setErrorCode(prvMessageRs.getData().getErrors().getErrorCode());
			errors.setErrorDesc(prvMessageRs.getData().getErrors().getErrorDesc());
			
			errors.setErrorCodeVPG(prvMessageRs.getData().getErrors().getErrorCode());
			errors.setErrorDescVPG(prvMessageRs.getData().getErrors().getErrorDesc());
			
			data1212.setErrors(errors);
			
			lstRecord1212 = new ArrayList<BeRecord1212>();
			
			for(int i=0; i < prvMessageRs.getData().getRecords().size(); i++) {
				record1212 = new BeRecord1212();
				
				record1212.setTransId(prvMessageRs.getData().getRecords().get(i).getTransId());
				record1212.setOriginalId(prvMessageRs.getData().getRecords().get(i).getOriginalId());
				record1212.setChannelId(prvMessageRs.getData().getRecords().get(i).getChannelId());
				
				record1212.setTransTime(prvMessageRs.getData().getRecords().get(i).getTransTime());
				record1212.setTransType(prvMessageRs.getData().getRecords().get(i).getTransType());
				record1212.setServiceType(prvMessageRs.getData().getRecords().get(i).getServiceType());
				
				Status status = new  Status();
				
				status.setCode(prvMessageRs.getData().getRecords().get(i).getStatus().getCode());
				
				status.setMessage(prvMessageRs.getData().getRecords().get(i).getStatus().getMessage());
				
				record1212.setStatus(status);
				
				record1212.setCustCode(prvMessageRs.getData().getRecords().get(i).getCustCode());
				record1212.setCustName(prvMessageRs.getData().getRecords().get(i).getCustName());
				record1212.setCustAcct(prvMessageRs.getData().getRecords().get(i).getCustAcct());
				
				record1212.setIdCard(prvMessageRs.getData().getRecords().get(i).getIdCard());
				record1212.setPhoneNo(prvMessageRs.getData().getRecords().get(i).getPhoneNo());
				record1212.setEmail(prvMessageRs.getData().getRecords().get(i).getEmail());
				
				record1212.setTerm(beMessageRq.getData().getRecords().get(i).getTerm());
				record1212.setInterest(beMessageRq.getData().getRecords().get(i).getInterest());
				record1212.setAmount(prvMessageRs.getData().getRecords().get(i).getAmount());
				record1212.setFee(prvMessageRs.getData().getRecords().get(i).getFee());
				record1212.setVat(prvMessageRs.getData().getRecords().get(i).getVat());
				
				record1212.setAddInfo(null);
				record1212.setPreseve1("");
				record1212.setPreseve2("");
				record1212.setPreseve3("");
				
				lstRecord1212.add(record1212);
				
			}
			
			
			data1212.setRecords(lstRecord1212);
			
			message1212.setData(data1212);
			
			return message1212;
		
			}catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}finally {
				message1212 = null;
				header1212 = null;
				data1212 = null;
				lstRecord1212 = null;
				record1212 = null;
				status1212 = null;
			}
	}


}

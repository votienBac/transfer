package vn.vietinbank.vpg.service.notifystatus;

import vn.vietinbank.vpg.service.VpgMessageAbstractFactory;
import vn.vietinbank.vpg.util.Constants.EKYC_PROVIDER;
import vn.vietinbank.vpg.util.Constants.MESSAGE_TYPE;
import vn.vietinbank.vpg.util.Constants.PROVIDER_ID;


public class VpgNotifyStatusFactory implements VpgMessageAbstractFactory<VpgNotifyStatusInterface> {

	@Override
	public VpgNotifyStatusInterface create(String provider) {
		try {
			switch(provider) {
			
			
			case PROVIDER_ID.BCA_C06:{
				return new C06NotifyStatusImpl();
			}
			
			
			default:{
				return new PrvNotifyStatusImpl();
			}
			
			}
		}catch(Exception e) {
			return null;
		}
	
	}

	@Override
	public VpgNotifyStatusInterface create(String formatType, String provider) {
		return null;
	}

	
	
}

package vn.vietinbank.vpg.service.notifystatus;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;

import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1202;
import vn.vietinbank.vpg.model.notifystatus.BeMessage1212;


public interface VpgNotifyStatusInterface {

	BeMessage1212 processMessage(BeMessage1202 message1202,VpgMicroServiceParamsEntity vpgMicroServiceParamsEntity);
			
}

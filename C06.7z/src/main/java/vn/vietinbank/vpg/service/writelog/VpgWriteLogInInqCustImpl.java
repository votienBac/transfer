package vn.vietinbank.vpg.service.writelog;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import org.springframework.web.client.RestTemplate;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;
import vn.vietinbank.vpg.model.*;
import vn.vietinbank.vpg.model.inqcust.*;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.LOG_OUT;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;
import vn.vietinbank.vpg.dao.*;

public class VpgWriteLogInInqCustImpl implements VpgWriteLogInterface<VpgTransLogInEntity,BeMessage1300,PrvMessage1310> {

	private static final Logger logger = LoggerFactory.getLogger(VpgWriteLogInInqCustImpl.class);

	VpgTransLogInDaoInterface vpgTransLogInDAO 	= null;
	
	public VpgWriteLogInInqCustImpl() {
		
	}
	
	@Override
	public void writeLog(VpgTransLogInEntity vpgTransLogInEntity, BeMessage1300 messageRq, PrvMessage1310 messageRsPrv,String originMsg, 
			String convertMsg, 
			Long processTime, 
			Long processTimePartner, 
			Long processTimeDB) {
		
		try {
			
			vpgTransLogInEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogInEntity.setMsg_id(messageRq.getHeader().getMsgId());
			vpgTransLogInEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1310);
			vpgTransLogInEntity.setPayment_channel(messageRq.getHeader().getChannelId());
			
			vpgTransLogInEntity.setGateway_id(messageRq.getHeader().getGatewayId());
			vpgTransLogInEntity.setProvider_id(messageRq.getHeader().getProviderId());
			vpgTransLogInEntity.setProduct_code(messageRq.getHeader().getProductId());
			
			vpgTransLogInEntity.setTrans_direct(Constants.LOG_IN.TRANS_DIRECT);
			vpgTransLogInEntity.setTrans_type(Constants.LOG_IN.TRANS_TYPE);
			vpgTransLogInEntity.setService_code(Constants.SERVICE_CODE);
			
			
			vpgTransLogInEntity.setMsg_origin(originMsg);
			vpgTransLogInEntity.setMsg_convert(convertMsg);
			
			vpgTransLogInEntity.setError_code(messageRsPrv.getData().getErrors().getErrorCode());
			vpgTransLogInEntity.setError_desc(messageRsPrv.getData().getErrors().getErrorDesc());
			
			vpgTransLogInEntity.setYear(CommonUtils.getYear());
			vpgTransLogInEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogInEntity.setDay(CommonUtils.getDayOfMonth());
			
			vpgTransLogInEntity.setPROCESS_TIME(processTime);
			vpgTransLogInEntity.setPROCESS_TIME_PRV(processTimePartner);
			vpgTransLogInEntity.setPROCESS_TIME_DB(processTimeDB);//Time db for msg request
			
		
			
			vpgTransLogInDAO = new VpgTransLogInDaoImpl();
			
			vpgTransLogInDAO.save(vpgTransLogInEntity);
		}catch(Exception e) {
			logger.error("logIn() is failed: " + e.getMessage());
		}
	}

	
}

package vn.vietinbank.vpg.service.writelog;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public interface VpgWriteLogInterface<T1,T2,T3> {

	public void writeLog(T1 entityLog, 
							T2 messageRq,
							T3 messageRsPrv, 
							String originMsg, 
							String convertMsg, 
							Long processTime, 
							Long processTimePartner, 
							Long processTimeDB);
			
}

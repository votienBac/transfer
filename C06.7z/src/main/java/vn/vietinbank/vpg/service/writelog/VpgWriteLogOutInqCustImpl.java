package vn.vietinbank.vpg.service.writelog;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import org.springframework.web.client.RestTemplate;

import vn.vietinbank.vpg.dao.VpgTransLogInDaoInterface;
import vn.vietinbank.vpg.dao.VpgTransLogOutDaoInterface;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransLogInEntity;
import vn.vietinbank.vpg.entity.VpgTransLogOutEntity;
import vn.vietinbank.vpg.model.inqcust.BeMessage1300;
import vn.vietinbank.vpg.util.CommonUtils;
import vn.vietinbank.vpg.util.Constants;
import vn.vietinbank.vpg.util.Constants.LOG_OUT;
import vn.vietinbank.vpg.util.Constants.VPG_CHANGE_FORMAT;
import vn.vietinbank.vpg.util.Constants.VPG_MSG_TYPE;
import vn.vietinbank.vpg.util.Constants.VPG_STATUS;
import vn.vietinbank.vpg.util.ConvertJsonToObject;
import vn.vietinbank.vpg.util.ResourceUtils;
import vn.vietinbank.vpg.dao.*;

public class VpgWriteLogOutInqCustImpl implements VpgWriteLogInterface<VpgTransLogOutEntity,BeMessage1300,BeMessage1300> {

	private static final Logger logger = LoggerFactory.getLogger(VpgWriteLogOutInqCustImpl.class);

	VpgTransLogOutDaoInterface vpgTransLogOutDAO 	= null;
	
	public VpgWriteLogOutInqCustImpl() {
		
	}
	
	@Override
	public void writeLog(VpgTransLogOutEntity vpgTransLogOutEntity, BeMessage1300 messageRq, BeMessage1300 messageRsPrv,String originMsg, 
			String convertMsg, 
			Long processTime, 
			Long processTimePartner, 
			Long processTimeDB) {
		
		try {
			vpgTransLogOutEntity = new VpgTransLogOutEntity();
			
			vpgTransLogOutEntity.setHostinfo(CommonUtils.getHostName());
			vpgTransLogOutEntity.setMsg_id(messageRq.getHeader().getMsgId());
			vpgTransLogOutEntity.setMsg_type(VPG_MSG_TYPE.MSG_TYPE_1300);
			vpgTransLogOutEntity.setPayment_channel(messageRq.getHeader().getChannelId());
			
			
			vpgTransLogOutEntity.setGateway_id(messageRq.getHeader().getGatewayId());
			vpgTransLogOutEntity.setProvider_id(messageRq.getHeader().getProviderId());
			vpgTransLogOutEntity.setProduct_code(messageRq.getHeader().getProductId());
			
			vpgTransLogOutEntity.setTrans_direct(Constants.LOG_OUT.TRANS_DIRECT);
			vpgTransLogOutEntity.setTrans_type(Constants.LOG_OUT.TRANS_TYPE);
			vpgTransLogOutEntity.setService_code(Constants.SERVICE_CODE);
			vpgTransLogOutEntity.setMsg_origin(originMsg);
			vpgTransLogOutEntity.setMsg_convert(convertMsg);
			
			vpgTransLogOutEntity.setYear(CommonUtils.getYear());
			vpgTransLogOutEntity.setMonth(CommonUtils.getMonthOfYear());
			vpgTransLogOutEntity.setDay(CommonUtils.getDayOfMonth());
			
		
			
			vpgTransLogOutDAO = new VpgTransLogOutDaoImpl();
			
			vpgTransLogOutDAO.save(vpgTransLogOutEntity);
		}catch(Exception e) {
			logger.error("logOut() is failed: " + e.getMessage());
		}
	}

	
}

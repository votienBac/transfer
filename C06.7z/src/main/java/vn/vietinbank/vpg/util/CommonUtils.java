package vn.vietinbank.vpg.util;

import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.sql.DataSource;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.fasterxml.jackson.databind.ObjectMapper;

import sun.security.util.DerOutputStream;
import sun.security.util.DerValue;
import sun.security.x509.AlgIdDSA;
import sun.security.x509.AlgorithmId;
import vn.vietinbank.vpg.entity.VpgMicroServiceParamsEntity;
import vn.vietinbank.vpg.entity.VpgTransDetailsInqCustInEntity;
import vn.vietinbank.vpg.model.ConfigParams;
import vn.vietinbank.vpg.util.Constants.VPG_CHARACTERSET;

import vn.vietinbank.vpg.dao.*;

public class CommonUtils {
	public static final Logger logger = LoggerFactory.getLogger(CommonUtils.class);
	
		public static JdbcTemplate jdbcTemplate = null;
		public static DataSource dataSource = null;
	
	public static List<VpgMicroServiceParamsEntity> lstMicroServiceParamsEntity = null;

	
	static long processTime;
	
	
	public static void initDataSourceJDBCTemplate() {
		try {
			
			if(jdbcTemplate == null) {
			
				DriverManagerDataSource dataSource = new DriverManagerDataSource();
		        
		    	dataSource.setUrl(ResourceUtils.getVpgDataSourceUrl());
		        dataSource.setUsername(ResourceUtils.getVpgDataSourceUserName());
		        dataSource.setPassword(ResourceUtils.getVpgDataSourcePassword());
		        
		        jdbcTemplate = new JdbcTemplate(dataSource);
			}
		     
		}catch(Exception e) {
			logger.error("initDataSourceJDBCTemplate() is errored: " + e.getMessage());
		}
	}
	
	public static void initDataSourceJDBC() {
		try {
			
			if(dataSource == null) {
			
				DriverManagerDataSource driverMgDataSource = new DriverManagerDataSource();
		        
		    	driverMgDataSource.setUrl(ResourceUtils.getVpgDataSourceUrl());
				driverMgDataSource.setUsername(ResourceUtils.getVpgDataSourceUserName());
				driverMgDataSource.setPassword(ResourceUtils.getVpgDataSourcePassword());
		        
				dataSource = driverMgDataSource;
			}
		     
		}catch(Exception e) {
			logger.error("initDataSourceJDBC() is errored: " + e.getMessage());
		}
	}
	
	public static String getServiceReference(String subfield1, 
			String subfield2,
			String subfield3,
			String subfield4,
			String subfield5,
			String subfield6,
			String subfield7
			) {
		try 
		{
			StringBuilder serviceReference = new StringBuilder();
			serviceReference.append(subfield1);
			serviceReference.append(subfield2);
			serviceReference.append(subfield3);
			serviceReference.append(subfield4);
			serviceReference.append(subfield5);
			serviceReference.append(subfield6);
			serviceReference.append(subfield7);
			
			
			return serviceReference.toString();
		} catch (Exception ex) {
			
			ex.printStackTrace();
			return "";
		}
	}
	
	public static String getAchUri(String baseUrl, String systemName, String version, String kindOfMessage, String senderId,
			String service, String messageIdentify, String senderReference) {
		try 
		{
			StringBuilder uriAch = new StringBuilder();
			uriAch.append(baseUrl + "/");
			uriAch.append(systemName + "/" );
			uriAch.append(version+ "/");
			uriAch.append(kindOfMessage+ "/");
			uriAch.append(senderId+ "/");
			uriAch.append(service+ "/");
			uriAch.append(messageIdentify+ "/");
			uriAch.append(senderReference);
			
			
			return uriAch.toString();
		} catch (Exception ex) {
	
			ex.printStackTrace();
			return "";
		}
	}
	
	
	public static HttpURLConnection getHttpConnection(String url,String type, int connectTimeout, int readTimeout,
			String contentType, String acceptContent)
	{
        URL uri = null;
        HttpURLConnection conn = null;
        try{
            uri = new URL(url);
            conn = (HttpURLConnection) uri.openConnection();
            conn.setRequestMethod(type); 
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setConnectTimeout(connectTimeout);
            conn.setReadTimeout(readTimeout);
            conn.setRequestProperty("Accept", acceptContent);
            conn.setRequestProperty("Content-Type", contentType);
        }catch(Exception e){
            e.printStackTrace();
        }
        return conn;
	}
	
	public static boolean isStringOnlyAlphabet(String str) 
	{ 
	    return ((!str.equals("")) 
	            && (str != null) 
	            && (str.matches("^[a-zA-Z]*$"))); 
	}
	
	public static boolean isNullOrEmpty(String str) {
		return (str == null || str.toString().isEmpty());
	}
			
	public boolean isNullOrEmptyString(String str) {
		return (str == null || str.isEmpty());
	}
	
	public static String getHostName()
	{
		try {
			
				InetAddress ip = InetAddress.getLocalHost();
	            return ip.getHostName();
        } catch (Exception e) {
       
        	return "";
        }
	}
	
	public static List<VpgMicroServiceParamsEntity> getVpgMicroServiceParamsByServiceCode(String serviceCode) {
		 
		VpgMicroServiceParamsDaoInterface  vpgMicroServiceParamsDAO = VpgMicroServiceParamsDaoImpl.getInstance();
		
         return vpgMicroServiceParamsDAO.getByServiceCode(serviceCode);
	}
	
	
		public static Dictionary getParams() {
			 
			try {
				
				initDataSourceJDBCTemplate();
				initDataSourceJDBC();
				
				VpgSystemParamsDaoInterface  vpgAchParamsDAO =  new VpgSystemParamsDaoImpl();
		        
		      
		        return vpgAchParamsDAO.getByServiceCode("VPG-APIC06-IN-MICRO-SERVICE");
		        
			}catch(Exception ex) {
				return null;
			}
			
		}
			
		public static String getSHA256(String s) throws Exception{
	        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
	      messageDigest.update(s.getBytes());
	      byte[] outputDigest = messageDigest.digest(); 
	     
	      DerOutputStream out = new DerOutputStream();
	      new AlgorithmId(AlgIdDSA.SHA256_oid).encode(out);
	      out.putOctetString(outputDigest);
	      DerValue result = new DerValue(DerValue.tag_Sequence, out.toByteArray());
	      byte[] encoded = result.toByteArray(); 
	      
	      return Base64.encodeBase64String(encoded);
	      
		}
		
		public static String getSHA256Hmac(String key, String message, String utf) {
		    try {
		      Mac mac = Mac.getInstance("HmacSHA256");
		      SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(utf), "HmacSHA256");
		      mac.init(secretKeySpec);
		      
		      return Hex.encodeHexString(mac.doFinal(message.getBytes(utf)));
		      
		      
		    } catch (Exception e) {
		      throw new RuntimeException("Failed to calculate hmac-sha256", e);
		    }
		    
		  }
		
		
			public static int getRandom(int n) {
			Random rd = new Random();
			return rd.nextInt(n);
		}
		
		
		public static String getCheckSum(String agl, String data ) {
			MessageDigest md;
			try {
				md = MessageDigest.getInstance(agl);
				md.update(data.getBytes(StandardCharsets.UTF_8));
				byte[] digest = md.digest();
				return DatatypeConverter.printHexBinary(digest);
				
				
			} catch (NoSuchAlgorithmException e) {
				
				e.printStackTrace();
				return "";
			}
			
		}
		 public static String hashMD5(String agl,String data) {
		        String result = "";
		  try {
		        MessageDigest md = MessageDigest.getInstance(agl);
		       md.update(data.getBytes());
		       byte byteData[] = md.digest();
		      
		       StringBuffer sb = new StringBuffer();
		       for (int i = 0; i < byteData.length; i++) {
		        sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
		       }
		        result = sb.toString();
		        } catch (NoSuchAlgorithmException e) {
		               
		        }
		        return result;
		  }
		
		public static String getNumberFormat(Object n, String pattern ) {
			
			return	String.format(pattern,n);
		}
		public static String getDateFormat(Date date, String pattern) {
			
			SimpleDateFormat formatter = new SimpleDateFormat(pattern);
			return formatter.format(date);
		}
		
		public static String getCurrentDateFormat(String pattern) {
			SimpleDateFormat formatter = new SimpleDateFormat(pattern);
			Date date = new Date(System.currentTimeMillis());
			return formatter.format(date);
		}
		
		public static int getDayOfMonth() {
			Date date = new Date(System.currentTimeMillis());
			LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			return localDate.getDayOfMonth();
		}

	public static int getMonthOfYear() {
			Date date = new Date(System.currentTimeMillis());
			LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			return localDate.getMonthValue();
		}
		
		public static int getYear() {
			Date date = new Date(System.currentTimeMillis());
			LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			return localDate.getYear();
		}
		
		public static Date convertStringToDate(String strDate, String pattern) {
			try {
				SimpleDateFormat formatter = new SimpleDateFormat(pattern);
				return formatter.parse(strDate);
			}catch(Exception e) {				return null;
			}
		}

		public static String getStringDate(Date date, String pattern) {
			try {
				SimpleDateFormat formatter = new SimpleDateFormat(pattern);
				return formatter.format(date);
			}catch(Exception e) {
				return "";
			}
		}

		public static String generateId() {
			return getCheckSum("SHA-1", 
					CommonUtils.getCurrentDateFormat(Constants.VPG_DATE_PARTERN.PATTERN_DATETIME) + 
					CommonUtils.getRandom(999999)+ 
					CommonUtils.getRandom(999999) + 
					CommonUtils.getRandom(999999));
		}
		
		public static String getEncodeBase64String(byte[] encoded) {
			try {
				return Base64.encodeBase64String(encoded);
			}catch(Exception e) {
				return "";
			}
		}
		
		public static byte[] getDecodeBase64Bytes(String encoded) {
			try {
				return Base64.decodeBase64(encoded);
			}catch(Exception e) {
				return null;
			}
		}
		
		public static void logFilesByThreshold(long startTime, long endTime,long threshold, String msg) {
			try {
				processTime = 0;
				processTime = endTime - startTime;
				if(processTime >= threshold) {
					logger.info(msg + processTime);
				}
			}catch(Exception ex) {
				logger.error("logFilesByThreshold(): " + ex.getMessage());
			}
		}
		
		public static String getConfigParamsByKey(String strConfig, String key) {
			try {
				ConfigParams configParams = ConvertJsonToObject.jsonToObject(strConfig.trim(), ConfigParams.class);
				
				Dictionary dicParams = new Hashtable();
				
				configParams.getPropertiesConfig().forEach((e) -> {
					
					dicParams.put(e.getKey(),e.getValue());
					}
					);
				
				return dicParams.get(key).toString().trim();
				
				
			} catch (Exception e) {
				
				e.printStackTrace();
				return "";
			}
			
		}
			public static void updateTokenById(String id,String providerId, String msgType, String token, String tokenCreate, String tokenExpire, String tokenTime) {
			 
			try {
				
				VpgMicroServiceParamsDaoInterface  vpgMicroServiceParamsDAO = VpgMicroServiceParamsDaoImpl.getInstance();
		        
				vpgMicroServiceParamsDAO.updateToken(id, providerId, msgType, token, tokenCreate, tokenExpire, tokenTime);
		        
			}catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
		public static String get_SHA_512_SecurePassword(String passwordToHash){
	        String generatedPassword = null;
	            try {
	                 MessageDigest md = MessageDigest.getInstance("SHA-512");
	                 byte[] bytes = md.digest(passwordToHash.getBytes("UTF-8"));
	                 StringBuilder sb = new StringBuilder();
	                 for(int i=0; i< bytes.length ;i++){
	                    sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
	                 }
	                 generatedPassword = sb.toString();
	                } 
	               catch (Exception e){
	            	   e.printStackTrace();
	               } 
	            return generatedPassword;
		}
		
		
		
		public static List<VpgTransDetailsInqCustInEntity> getVpgTransDetailsInqCustByCustomerCode(String custCode) {
			 
			
			VpgTransDetailsInqCustInDaoInterface  vpgTransDetailsInqCustInDAO = new VpgTransDetailsInqCustInDaoImpl();
	        
	        
	        return vpgTransDetailsInqCustInDAO.get(custCode);
		}

}

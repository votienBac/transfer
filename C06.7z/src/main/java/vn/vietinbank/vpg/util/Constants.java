package vn.vietinbank.vpg.util;

public class Constants {
	
	public static final String SERVICE_NAME = "API06-MICRO-SERVICE";
	
	public static interface VPG_SCHEDULE_TASK_TIME {
		public int RELOAD_FLAG = 1000*60*3;
		
		public int RELOAD_PARAMS = 1000*60*5;
	}
	
	public static final String VPG_CURRENCY_CODE = "VND";
	public static final String VTB_BANKCODE = "VIETTIN";
	
	public interface PROVIDER_ID
	{

		public static final String PRV_001 = "001";
		public static final String BCA_C06 = "841";
		
	}
	
	public interface HTTP_METHOD
	{
		public static final String HTTP_PUT = "PUT";
		public static final String HTTP_GET = "GET";
		public static final String HTTP_POST = "POST";
		public static final String HTTP_DELETE = "DELETE";
		public static final String HTTP_PATCH = "PATCH";
		
	}
	
	public interface VPG_STATUS
	{
		public static final String ENABLE = "1"; 
		public static final String DISABLE = "0";
	}
	
	public interface VPG_CHANGE_FORMAT
	{
		public static final String CHANGE_FORMAT_0 = "0"; 
		public static final String CHANGE_FORMAT_1 = "1"; 
		public static final String CHANGE_FORMAT_2 = "2"; 
		public static final String CHANGE_FORMAT_3 = "3"; 
		public static final String CHANGE_FORMAT_4 = "4"; 
		public static final String CHANGE_FORMAT_5 = "5"; 
		public static final String CHANGE_FORMAT_6 = "6"; 
		public static final String CHANGE_FORMAT_7 = "7"; 
		public static final String CHANGE_FORMAT_8 = "8"; 
		public static final String CHANGE_FORMAT_9 = "9"; 
		
	}
	

	public enum MESSAGE_TYPE
	{
		MESSAGE_TYPE_TRANSFER, MESSAGE_TYPE_INVESTIGATE, MESSAGE_TYPE_COPY_TRANS,MESSAGE_TYPE_DISPUTE, MESSAGE_TYPE_LIMIT_INQUIRY
	};
	
	public interface VPG_SECURE_TYPE
	{
		public static final String HSM = "HSM";
		
		public static final String VPG = "VPG";
		
	}
	
	public interface VPG_SECURE_ALGORITHM
	{
		public static final String SHA1 = "SHA1";
		
		public static final String SHA256 = "SHA256";
		
	}
	
	
	public interface EKYC_TYPE
	{
		public static final String EKYC = "02";
		
		public static final String KYC = "01";
	}
	
	public enum EKYC_PROVIDER
	{
		GRAB,HUES
	};
	
	public static String SERVICE_CODE = "VPG-COLLECTION-MICRO-SERVICE";
	public static String SERVICE_CODE_ACC_INQ = "IF_INQ";
	public static String PATTERN_DATE = "yyyyMMdd";
	public static String PATTERN_DATETIME = "yyyyMMddHHmmss";
	public static String PATTERN_DATETIME_MILISECOND = "yyyy-MM-dd HH:mm:ss.SSS";
	
	public interface HTTP_CODE {

	}
	public interface CHANNEL {
		
		public static String BRANCH = "211501";
		public static String INTERNET = "211601"; 
		public static String POS = "211701";
		public static String SMS = "211801";
		public static String AUTO = "211901";
	}
	

	
	public static interface LOG_OUT {
		public static String TRANS_DIRECT = "O";
		public static String TRANS_TYPE = "RQ";
	}
	public static interface LOG_IN {
		public static String TRANS_DIRECT = "I";
		public static String TRANS_TYPE = "RS";
	}
	
	
	public static final String PACKAGE_ENTITIES_1 = "vn.vietinbank.vpg.entity";
    
    public static final String PACKAGE_ENTITIES_2 = "vn.vietinbank.vpg.entity2";
     
    public static final String JPA_UNIT_NAME_1 ="PERSITENCE_UNIT_NAME_1";
    public static final String JPA_UNIT_NAME_2 ="PERSITENCE_UNIT_NAME_2";
    
    public static final String SSC_CODE_TRAN_ALREADY ="Transaction_Transferred_Already";
    
    public static interface ACH_SENDER {
		public static String ID = "ICBVVNVN";
		public static String NAME = "VietinBank";
	}
    
	public static interface ACH_RECEIVER {
		public static String ID = "NAPASVNV";
		public static String NAME = "NAPAS";
	}
	
	public static interface VPG_DATE_PARTERN {
		public static final String PATTERN_DATETIME = "yyMMddHHmmssSSS";
		public static final String MMddHHmmss = "MMddHHmmss";
		
	}

	public static interface ACH_DATE_PARTERN {
		public static final String PATTERN_DATE = "yyyyMMdd";
		public static final String PATTERN_DATETIME = "yyyyMMddHHmmss";
		public static final String FULL_DATETIME_GMT0 = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	}
	
	
	public static interface VPG_MSG_TYPE {
		
		public static final String MSG_TYPE_1100 = "1100";
		public static final String MSG_TYPE_1110 = "1110";
		
		public static final String MSG_TYPE_1200 = "1200";
		public static final String MSG_TYPE_1210 = "1210";
		
		public static final String MSG_TYPE_1300 = "1300";
		public static final String MSG_TYPE_1310 = "1310";
		public static final String MSG_TYPE_1301 = "1301";
		public static final String MSG_TYPE_1302 = "1302";
		public static final String MSG_TYPE_1311 = "1311";
		public static final String MSG_TYPE_1312 = "1312";
		
		public static final String MSG_TYPE_1400 = "1400";
		public static final String MSG_TYPE_1410 = "1410";
		
		public static final String MSG_TYPE_1500 = "1500";
		public static final String MSG_TYPE_1510 = "1510";
		
		public static final String MSG_TYPE_1600 = "1600";
		public static final String MSG_TYPE_1610 = "1610";
		
		public static final String MSG_TYPE_1700 = "1700";
		public static final String MSG_TYPE_1710 = "1710";
		
		public static final String MSG_TYPE_1800 = "1800";
		public static final String MSG_TYPE_1810 = "1810";
		
		public static final String MSG_TYPE_1900 = "1900";
		public static final String MSG_TYPE_1910 = "1910";
		
		public static final String MSG_TYPE_1220 = "1220";
		public static final String MSG_TYPE_1221 = "1221";
		
		public static final String MSG_TYPE_1202 = "1202";
		public static final String MSG_TYPE_1212 = "1212";
		
		public static final String MSG_TYPE_1701 = "1701";
		public static final String MSG_TYPE_1711 = "1711";
		
		public static final String MSG_TYPE_1105 = "1105";
		public static final String MSG_TYPE_1115 = "1115";
		
		public static final String MSG_TYPE_1106 = "1106";
		public static final String MSG_TYPE_1116 = "1116";
		
		public static final String MSG_TYPE_1107 = "1107";
		public static final String MSG_TYPE_1117 = "1117";
		
		public static final String MSG_TYPE_1108 = "1108";
		public static final String MSG_TYPE_1118 = "1118";
		
		public static final String MSG_TYPE_1109 = "1109";
		public static final String MSG_TYPE_1119 = "1119";
		public static final String MSG_TYPE_1104 = "1104";
		public static final String MSG_TYPE_1114 = "1114";
		
			
	}
	
	public static interface MSG_SOURCE
	{
		public static final String VIETINBANK= "970415";
		public static final String NAPAS= "970418";
	}
	
	
	public static final String RESPONSE_SUCCESS = "0";
	public static final String RESPONSE_ERROR = "1";
	public static final String POINT_OF_SERVICE_ENTRY_CODE = "000";
	public static final String POINT_OF_SERVICE_CONDITION_CODE  = "00";
	public static final String CARD_ACCEPTOR_TERMINAL_ID = "00000001";
	public static final String CARD_ACCEPTOR_NAME_LOCATION = "VietinBank                           VNM";
	
	public static interface PRV_STATUS_SUCCESS {
		public static final String CODE = "00";
		public static final String DESC = "Successful";
	}
	
	public static interface PRV_STATUS_ERR_GENERAL {
		public static final String CODE = "99";
		public static final String DESC = "General error";
	}
	
	public static interface VPG_STATUS_SUCCESS {
		public static final String CODE = "V000";
		public static final String DESC = "Successful";
	}
	
	public static interface VPG_STATUS_ERR_PARSE {
		public static final String CODE = "V001";
		public static final String DESC = "Parse message is failed";
	}
	
	public static interface VPG_STATUS_ERR_DUP {
		public static final String CODE = "V002";
		public static final String DESC = "Transaction is duplicated";
	}
	
	public static interface VPG_STATUS_ERR_DB {
		public static final String CODE = "V003";
		public static final String DESC = "The database is failed";
	}
	
	public static interface VPG_STATUS_ERR_EXCEED {
		public static final String CODE = "V006";
		public static final String DESC = "Investigate exceed accept number";
	}
	
	public static interface VPG_STATUS_ERR_PKG {
		public static final String CODE = "V007";
		public static final String DESC = "Package message is failed";
	}
	
	public static interface VPG_STATUS_ERR_NOTFOUND {
		public static final String CODE = "V008";
		public static final String DESC = "Transaction cannot found";
	}
	
	public static interface VPG_STATUS_ERR_FLAG {
		public static final String CODE = "V009";
		public static final String DESC = "Flag is enabled";
	}
	
	public static interface VPG_STATUS_ERR_PROVIDER_ID {
		public static final String CODE = "V025";
		public static final String DESC = "The provider code does't exist";
	}
	
	public static interface VPG_STATUS_ERR_ATTACHFILE {
		public static final String CODE = "V011";
		public static final String DESC = "Attach file is failed";
	}
	
	public static interface VPG_STATUS_ERR_BEN {
		public static final String CODE = "V012";
		public static final String DESC = "The ben is failed";
	}
	
	public static interface VPG_STATUS_ERR_HTTP {
		public static final String CODE = "V013";
		public static final String DESC = "Http error";
	}
	
	public static interface VPG_STATUS_ERR_DUP_NAPAS {
		public static final String CODE = "V014";
		public static final String DESC = "Transaction is duplicated by Napas";
	}
	
	public static interface VPG_STATUS_ERR_HTTP_TYPE_FAILURE {
		public static final String CODE = "V015";
		public static final String DESC = "Http body type is failured";
	}
	
	public static interface VPG_STATUS_ERR_EXCEEDED {
		public static final String CODE = "V016";
		public static final String DESC = "Debit cap floor exceeded";
	}
	
	public static interface VPG_STATUS_ERR_NULL_ID {
		public static final String CODE = "V017";
		public static final String DESC = "The Id is null";
	}
	
	public static interface VPG_STATUS_ERR_CURRENCY_TYPE {
		public static final String CODE = "V018";
		public static final String DESC = "The currency type is not allow";
	}
	
	public static interface VPG_STATUS_ERR_EXCEEDED_AMOUNT {
		public static final String CODE = "V019";
		public static final String DESC = "The amount is exceeded";
	}
	
	public static interface VPG_STATUS_ERR_ACCT_CARD_NOT_ALLOW{
		public static final String CODE = "V020";
		public static final String DESC = "The account/card is not allow";
	}
	
	public static interface VPG_STATUS_ERR_TRANS_NOT_ALLOW{
		public static final String CODE = "V021";
		public static final String DESC = "The transaction is not allow";
	}
	
	public static interface VPG_STATUS_ERR_CALL_SOA{
		public static final String CODE = "V022";
		public static final String DESC = "Call SOA is failed";
	}
	
	public static interface VPG_STATUS_ERR_SIGN{
		public static final String CODE = "V023";
		public static final String DESC = "Sign message is failed";
	}
	
	public static interface VPG_STATUS_ERR_VERIFY{
		public static final String CODE = "V024";
		public static final String DESC = "Verify message is failed";
	}
	
	public static interface VPG_STATUS_ERR_TIMEOUT_PROVIDER {
		public static final String CODE = "V068";
		public static final String DESC = "Timeout by provider";
	}
	
	public static interface VPG_STATUS_ERR_TIMEOUT_BEN {
		public static final String CODE = "V069";
		public static final String DESC = "Timeout by merchant";
	}
	
	public static interface VPG_STATUS_ERR_LATE_RESPONSE {
		public static final String CODE = "V070";
		public static final String DESC = "Late response";
	}
	
	public static interface VPG_STATUS_ERR_COPY {
		public static final String CODE = "V071";
		public static final String DESC = "Copying is not allowed";
	}
	
	public static interface VPG_STATUS_ERR_GENERAL {
		public static final String CODE = "V099";
		public static final String DESC = "General error";
	}
	
		
	public interface VPG_MESSAGE_SOURCE
	{
		public static final String VIETINBANK = "970415";
		public static final String NAPAS = "970418";
	}
	
	public static interface VPG_CHARACTERSET {
		public static final String UTF_8 = "UTF-8";
		public static final String UTF_16 = "UTF-16";
		public static final String ASCII = "ASCII";
	}
	
	public interface PROCESS_TIME
	{
		public static final String DB 		= "PROCESS TIME DB_____: ";
		public static final String CALL_API = "PROCESS TIME API____: ";
		public static final String SECURE 	= "PROCESS TIME SECURE_: ";
		public static final String RQ 		= "PROCESS TIME RQ_____: ";
		public static final String RS		= "PROCESS TIME RS_____: ";
		public static final String TOTAL 	= "PROCESS TIME TOTAL__: ";
		
		
	}

	
	public interface VPG_SERVICE_TYPE
	{
		public static final String CREATEACCT = "CREATEACCT";
		public static final String CONNECT = "CONNECT";
		public static final String TOPUP = "TOPUP";

	}
	
	public interface VPS_CONFIG
	{
		public static final String CONSULTANT = "Consultant";
		public static final String PARNERID = "ParnerId";

	}
	
	public interface VPG_CHECKSUM_CODE
	{
		public static final String MD5 = "MD5";
		public static final String SHA_1 = "SHA-1";
		public static final String SHA_256 = "SHA-256";

	}
}

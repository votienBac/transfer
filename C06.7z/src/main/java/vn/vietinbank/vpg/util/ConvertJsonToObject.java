package vn.vietinbank.vpg.util;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;



public class ConvertJsonToObject {
	
	public static String objectToJson(Object obj, boolean ignoreNullField)
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
		
			if(ignoreNullField == true) {
				mapper.setSerializationInclusion(Include.NON_NULL);
			}
			
			return mapper.writeValueAsString(obj);
			
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
				
	}
	
	public static String objectToJson(Object obj)
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
		
			return mapper.writeValueAsString(obj);
			
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
				
	}
	public static <T> T  jsonToObject(String json, Class<T> jaxbClass)
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
		
			Object obj = mapper.readValue(json, jaxbClass);
			
			return jaxbClass.cast(obj);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
				
	}

	public static <T> T  jsonToObject(String json, Class<T> jaxbClass, boolean ignoreNullField )
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
		
			if(ignoreNullField == true) {
				mapper.setSerializationInclusion(Include.NON_NULL);
			}
			
			Object obj = mapper.readValue(json, jaxbClass);
			
			return jaxbClass.cast(obj);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
				
	}
	
}

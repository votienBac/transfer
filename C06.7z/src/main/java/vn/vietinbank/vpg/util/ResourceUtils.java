package vn.vietinbank.vpg.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.util.Map;
import java.util.Properties;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.xml.sax.InputSource;


public class ResourceUtils {

	public static Properties prop = null;
	static String ur1 = "";
	static String ur2 = "";
	static String pa1 = "";
	static String pa2 = "";
	static String db = "";
	static String pra = "";
	static {
		try (InputStream input = ResourceUtils.class.getClassLoader().getResourceAsStream("application.properties")) {

			prop = new Properties();

			if (input == null) {
				System.out.println("Sorry, unable to find application.properties");
			} else {
				prop.load(input);
			}
			Map<String, String> env = System.getenv();

			for (String envName : env.keySet()) {
				if (envName.equals("API06PARAM1"))
					db = env.get(envName);
				if (envName.equals("API06PARAM2"))
					ur1 = env.get(envName);
				if (envName.equals("API06PARAM3"))
					ur2 = env.get(envName);
				if (envName.equals("API06PARAM4"))
					pa1 = env.get(envName);
				if (envName.equals("API06PARAM5"))
					pa2 = env.get(envName);
				if (envName.equals("API06PARAM6"))
					pra = env.get(envName);
					}
		
		

	}
	catch(
	IOException ex)
	{
		ex.printStackTrace();
	}
	}

	

	public static String getVpgDataSourceUrl() {

		try {
			String result = db;

			if (getVpgDataSourceUrlEnc().equals("1")) {

				result = AESService.decryptAESCBC128(result, pra, "encryptionIntVec");

			} else {
				result = prop.getProperty("vpg.datasource.url");
			}

			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public static String getClientId() {

		try {
			String result = prop.getProperty("vpg.clientid");
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}

	}

	public static String getSecret() {

		try {
			String result = prop.getProperty("vpg.secret");
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}

	}

	public static String getVpgDataSourceUserName() {

		try {
			String result = ur1 + ur2 ;
			if (getVpgDataSourceUserEnc().equals("1")) {

				result = AESService.decryptAESCBC128(result, pra, "encryptionIntVec");

			} else {
				result = prop.getProperty("vpg.datasource.username");
			}

			return result;

		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public static String getVpgDataSourcePassword() {

		try {
			String result = pa1 + pa2 ;

			if (getVpgDataSourcePasswordEnc().equals("1")) {

				result = AESService.decryptAESCBC128(result, pra, "encryptionIntVec");

			} else {
				result = prop.getProperty("vpg.datasource.password");
			}

			return result;

		} catch (Exception e) {
			
			e.printStackTrace();
			return "";
		}

	}

	public static String getVpgDataSourcePasswordEnc() {
		try {
			String result = prop.getProperty("vpg.datasource.enc_pwd");
			return result;
		} catch (Exception e) {
			
			e.printStackTrace();
			return "";
		}
	}

	public static String getVpgDataSourceUserEnc() {
		try {
			String result = prop.getProperty("vpg.datasource.enc_usr");
			return result;
		} catch (Exception e) {
			
			e.printStackTrace();
			return "";
		}
	}

	public static String getVpgDataSourceUrlEnc() {
		try {
			String result = prop.getProperty("vpg.datasource.enc_url");
			return result;
		} catch (Exception e) {
			
			e.printStackTrace();
			return "";
		}
	}

	public static String getVpgDataSourceIsPool() {
		try {
			String result = prop.getProperty("vpg.datasource.isPool");
			return result;
		} catch (Exception e) {
		
			e.printStackTrace();
			return "";
		}
	}

	public static int getVpgDataSourceHikariMinIdle() {
		try {
			return Integer.parseInt(prop.getProperty("vpg.datasource.hikari.minimumIdle"));

		} catch (Exception e) {
		
			e.printStackTrace();
			return 1000;
		}
	}

	public static int getVpgDataSourceHikariMaxPoolSize() {
		try {
			return Integer.parseInt(prop.getProperty("vpg.datasource.hikari.maximumPoolSize"));
		} catch (Exception e) {
		
			e.printStackTrace();
			return 1;
		}
	}

	public static int getVpgDataSourceHikariIdleTimeout() {
		try {
			return Integer.parseInt(prop.getProperty("vpg.datasource.hikari.idleTimeout"));

		} catch (Exception e) {
		
			e.printStackTrace();
			return 1000;
		}
	}

	public static String getVpgDataSourceHikariPoolName() {
		try {
			String result = prop.getProperty("vpg.datasource.hikari.poolName");
			return result;
		} catch (Exception e) {
		
			e.printStackTrace();
			return "";
		}
	}

	public static long getVpgDataSourceHikariMaxLifeTime() {
		try {
			return Long.parseLong(prop.getProperty("vpg.datasource.hikari.maxLifetime"));

		} catch (Exception e) {
		
			e.printStackTrace();
			return 60000;
		}
	}

	public static long getVpgDataSourceHikariConnectionTimeout() {
		try {
			return Long.parseLong(prop.getProperty("vpg.datasource.hikari.connectionTimeout"));

		} catch (Exception e) {
		
			e.printStackTrace();
			return 30000;
		}
	}

	public static String getVpgDataSourceHikariCachePrepStmts() {
		try {
			String result = prop.getProperty("vpg.datasource.hikari.cachePrepStmts");
			return result;
		} catch (Exception e) {
		
			e.printStackTrace();
			return "";
		}
	}

	public static String getVpgDataSourceHikariPrepStmtCacheSize() {
		try {
			String result = prop.getProperty("vpg.datasource.hikari.prepStmtCacheSize");
			return result;
		} catch (Exception e) {
		
			e.printStackTrace();
			return "";
		}
	}

	public static String getVpgDataSourceHikariPrepStmtCacheSqlLimit() {
		try {
			String result = prop.getProperty("vpg.datasource.hikari.prepStmtCacheSqlLimit");
			return result;
		} catch (Exception e) {
			
			e.printStackTrace();
			return "";
		}
	}

}

package vn.vietinbank.vpg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VpgCollectionMicroServiceApplicationTests {

	@Test
	void contextLoads() {
		System.out.println();
	}

}
